local NAVI_TEXTURE = Engine.load_texture(_modpath.."attack.png")
local NAVI_ANIM_PATH = _modpath.."PrimaryAttack.animation"
local GS_CLAW_TEX = Engine.load_texture(_modpath.."claw.png")
local GS_CLAW_ANIM_PATH = _modpath.."claw.animation"
local IMPACT_TEX = Engine.load_texture(_modpath.."impact.png")
local IMPACT_ANIM_PATH = _modpath.."impact.animation"
local DARK_SWORD_TEX = Engine.load_texture(_modpath.."darksword.png")
local DARK_SWORD_ANIM_PATH = _modpath.."darksword.animation"
local MOVE_TEX = Engine.load_texture(_modpath.."move.png")
local MOVE_ANIM_PATH = _modpath.."move.animation"
local WHITEOUT_TEX = Engine.load_texture(_modpath.."white.png")
local WHITEOUT_ANIM_PATH = _modpath.."white.animation"

local CLAW_SFX = Engine.load_audio(_modpath.."claw.ogg")
local DARK_SWORD_SFX = Engine.load_audio(_modpath.."darksword.ogg")
local DARK_SFX = Engine.load_audio(_modpath.."dark_charge.ogg")
local APPEAR_SFX = Engine.load_audio(_modpath.."appear.ogg") 

function package_init(package) 
    package:declare_package_id("com.alrysc.card.BassDG")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes({'F'})
  
    local props = package:get_card_props()
    props.shortname = "BassDG"
    props.damage = 400
    props.time_freeze = true
    props.element = Element.None
    props.card_class = CardClass.Giga
    props.description = "DarkSword w/ Gospel!"
    props.limit = 1
end

--[[
    Returns a table containing Tiles pivoting from pivot_tile by 
    the X and Y offsets in tables inside ranges. 

    For example,
    tiles_from_pivot(Direction.Right, tile, {{1, 0}, {-1, 0}})
    
    will return a table containing the Tile 1 space along the 
    X axis to the Right of tile, and the Tile 1 spaces along the 
    X axis to the Left of tile.

    Tiles which are edges will not be included. Return table can 
    be empty if all targets were edges or nonexistent.
]]
function tiles_from_pivot(field, facing, pivot_tile, ranges)
    local facing_mod = facing == Direction.Right and 1 or -1
    local pivots = {x = pivot_tile:x(), y = pivot_tile:y()}

    local tiles = {}
    for k, v in ipairs(ranges)
    do
        local target_tile = field:tile_at(pivots.x + facing_mod * v[1], pivots.y + v[2])
        if target_tile and not target_tile:is_edge() then 
            table.insert(tiles, target_tile)
        end
    end

    return tiles
end

--[[
    actor is the Entity that is acting out these states, not the 
    one performing the CardAction. Here, it's the navi Spell.
]]
local function make_state_manager(actor, initial_state)
    local state_manager = {
        states = {},
        actor = actor,
        state = initial_state,
        parallel_state = nil,
        update = function(self)
            if self.state then
                self.state:on_update(self.actor, self)
            end

            if self.parallel_state then 
                self.parallel_state:on_update(self.actor, self)
            end
        end,

        next_state = function(self)
            if self.state then self.state:on_end(self.actor, self) end
            self.state = nil
            if not self.states[1] then return end
            self.state = self.states[1]
            table.remove(self.states, 1)
            if self.state then self.state:on_start(self.actor, self) end
        end,

        add_state = function(self, state)
            table.insert(self.states, state)
        end,

        set_parallel_state = function (self, state)
            self.parallel_state = state
            state:on_start(actor, self)
        end,

        -- TODO: It would be better if this wasn't a specific required call. 
        -- This means the ones added as parallel states can't also be added 
        -- as normal states. Should just do parallel lanes.
        finish_parallel_state = function (self)
            if self.parallel_state then 
                self.parallel_state:on_end(self.actor, self)
            end
            self.parallel_state = nil
        end,

        is_finished = function(self)
            return self.state == nil and self.parallel_state == nil
        end,
    }

    initial_state:on_start(actor, state_manager)

    return state_manager
end

--[[
    Targets the far two columns with falling Gospel claws. 
    They deal 100 damage and hit in a fixed pattern, cracking 
    tiles before dealing damage, or breaking them if they are 
    already cracked.

    state is passed in to set state.finished at a certain point. 
]]
function gospel_claws(user, state, damage)
    local context = user:get_context()
    local facing = user:get_facing()
    local field = user:get_field()
    local team = user:get_team()
    local start = nil
    local inc = nil

    local coords = {}
    if facing == Direction.Right then 
        inc = -1
        start = field:width()
    else
        inc = 1
        start = 1
    end

    local height = field:height()
    -- Do not change columns if the entire second column is our team. 
    -- This means being +2 area will get two claw hits.
    local all_team_tile = true
    for i = 1, height do
        if field:tile_at(start + inc, i):get_team() ~= team then 
            all_team_tile = false
            break
        end
    end

    if all_team_tile then 
        inc = 0
    end

    for i = 1, height do
        coords[i] = {x = start, y = i}
        coords[i + height] = {x = start + inc, y = i}
    end

    local total = #coords
    -- 3 instead of height for the interlocking pattern. In case field gets 
    -- taller, this more accurately describes it.
    for i = 2, #coords - 3, 3 do
        coords[i], coords[i+3] = coords[i+3], coords[i]
    end
    
    local controller = Battle.Spell.new(team)
    controller:set_facing(facing)

    --[[
        The BassGS fight has 20 for this, but I want faster
    ]]
    local delay = 10
    local t = 0
    local iter = 1
    controller.update_func = function(self)
        t = t + 1
        if t <= delay then 
            return 
        end

        t = 0
        drop_claw(self, field:tile_at(coords[iter].x, coords[iter].y), damage, context)
        iter = iter + 1

        if not coords[iter] then
            state.start_delay = true
            self:delete()
        end
    end

    field:spawn(controller, 0, 0)
end

function drop_claw(owner, tile, damage, context)
    if not tile or tile:is_edge() then return end
    -- Claw should move 10 (20 scaled) pixels square each frame
    local delta = 20
    local move_duration = 10
    local move_progress = 1
    local distance = delta * move_duration * -1

    local offset_mod = -1

    local movement_dir = owner:get_facing()

    if movement_dir == Direction.Left then
        offset_mod = 1
    end
 
    local spell = graphic_init("spell", distance, distance, GS_CLAW_TEX, GS_CLAW_ANIM_PATH, -1, "0", owner, movement_dir)

    spell:set_hit_props(HitProps.new()
        :dmg(damage)
        :impact()
        :flinch()
        :flash()
        :pierce_ground()
        :from(context)
    )

    local offset = spell:get_offset()

    --[[
        The BassGS fight has 21, 12, 10 for these values, 
        but I wanted faster.
    ]]
    local highlight_t = 21
    local hide_t = 12
    local delay = 10

    -- Time before delete after landing. It's on the ground for this + 1, 
    -- since I start counting down on the next frame.
    local end_delay = 9
    local first_offset = true
    local landed = false
    spell:hide()
    spell.update_func = function(self)
        if hide_t > 0 then 
            hide_t = hide_t - 1
            if hide_t == 0 then 
                local fx = graphic_init("artifact", distance, distance, MOVE_TEX, MOVE_ANIM_PATH, -2, "4", self, movement_dir, true)
                self:get_field():spawn(fx, tile)
                self:reveal()
            end
        end

        if highlight_t > 0 then 
            highlight_t = highlight_t - 1
            self:get_tile():highlight(Highlight.Flash)
            return
        end

        if delay > 0 then 
            delay = delay - 1
            return
        end

        if first_offset then 
            Engine.play_audio(CLAW_SFX, AudioPriority.Immediate)
            first_offset = false
        end

        if landed then 
            end_delay = end_delay - 1
            self:shake_camera(50, 0.016)
            if end_delay == 0 then 
                self:delete()
            end

            return
        end

        local t = self:get_current_tile()

        if move_progress > move_duration then
            self:shake_camera(50, 0.016)
            landed = true
            t:attack_entities(self)
                if t:get_state() == TileState.Cracked then 
                    t:set_state(TileState.Broken)
                else
                    t:set_state(TileState.Cracked) 
                end
                local r_y = math.random(2, 6) * 2
                local r_x = (10 - math.random(0, 20)) * 2

                local fx = graphic_init("artifact", r_x, r_y, IMPACT_TEX, IMPACT_ANIM_PATH, -2, "0", self, self:get_facing(), true)
                self:get_field():spawn(fx, t)
            return
        end

      --  local d_v = get_progress_vector(dist, move_duration, move_progress)

        local _distance = (math.floor(distance - distance * move_progress/move_duration)) >> 1 << 1
        self:set_offset(_distance, _distance) 

        move_progress = move_progress + 1
    end

    owner:get_field():spawn(spell, tile)
end

function create_point_state()
    return 
    {
        start_delay = false,
        delay = 10,
        on_start = function(self, actor, manager)
            actor:get_animation():set_state("POINT")
            gospel_claws(actor, self, 100)
        end,

        on_update = function(self, actor, manager)
            if not self.start_delay then 
                return
            end

            self.delay = self.delay - 1
            if self.delay >= 0 then 
                return
            end

            manager:add_state(create_sword_state())
            manager:next_state()
        end,
        on_end = function(self, actor, manager) end
    }
end

--[[
    I'd like to improve this so that it doesn't need to be 
    2000x2000.
    The texture is 2x2 for some reason. I don't remember why. 
    Surely it could be 1x1. I think maybe it was extending from the origin, 
    and by making it 2x2 with a 1,1 origin, it was able to extend both ways?
    But then I just have to offset it to the edge of the screen.
]]
function screen_flash(self, time)
    time = time or 3
    local field = self:get_field()
    local whiteout = graphic_init("artifact", 0, 0, WHITEOUT_TEX, WHITEOUT_ANIM_PATH, 99, "WHITEOUT", self, Direction.Right)
    local white = whiteout:sprite()
    white:set_width(2000)
    white:set_height(2000)
    
    -- Not sure what this offset is doing, but it's fine. 
    white:set_offset(90, 100)

    local lifetime = time
    whiteout.update_func = function(self)
        if lifetime == 0 then 
            self:delete()
            self:hide()
        end

        lifetime = lifetime - 1
    end

    field:spawn(whiteout, field:tile_at(0, 0))

    return whiteout
end

function create_sword_state()
    return 
    {
        finished = false,
        on_start = function(self, actor, manager)
            local anim = actor:get_animation()
            anim:set_state("SWORD")

            anim:on_frame(2, function()
                Engine.play_audio(DARK_SFX, AudioPriority.Immediate)
            end)

            local function make_attack(slash_data)
                local field = actor:get_field()
                local facing = actor:get_facing()
                local tiles = tiles_from_pivot(field, facing, actor:get_current_tile(), slash_data)
   
                for _, tile in ipairs(tiles)
                do
                    local spell = Battle.Spell.new(actor:get_team())
                    spell:set_hit_props(actor.generate_hit_props())
                    spell.update_func = function(self)
                        self:get_current_tile():attack_entities(self)
                        self:delete()
                    end

                    field:spawn(spell, tile)
                end
            end

            anim:on_frame(17, function()
                Engine.play_audio(DARK_SWORD_SFX, AudioPriority.Immediate)
            end)

            anim:on_frame(19, function()
                local shake_artifact = Battle.Artifact.new()
                local time = 0
                shake_artifact.update_func = function(self)
                    self:shake_camera(200, 0.016)
                    if time == 38 then 
                        self:delete()
                    end
                
                    time = time+1
                end

                local field = actor:get_field()
                field:spawn(shake_artifact, actor:get_current_tile())

                make_attack({
                    {1, 0}, {2, 0}, 
                    {1, 1}, {2, 1}, 
                    {1, -1}, {2, -1}
                })

                local fx = graphic_init("artifact", -6, -48, DARK_SWORD_TEX, DARK_SWORD_ANIM_PATH, -2, "0", actor, actor:get_facing(), true)
                actor:get_field():spawn(fx, actor:get_tile(actor:get_facing(), 1))

                local flashing = Battle.Artifact.new()
                local flashes = 4
                local flash_t = -1
                local first_flash = true
                flashing.update_func = function(self)
                    flash_t = flash_t+1
                    if flash_t % 8 ~= 0 then 
                        return
                    end

                    -- Effectively 3 and 4f, though, which is the goal.
                    -- And this is 3 and 4f because the first spawns on the same 
                    -- frame this spawns, I guess, but the rest are not like that.
                    screen_flash(self, first_flash and 2 or 4)
                    -- This has the 4f delay between each, yes. Not sure why. If I do 
                    -- 0 on the second flash, it's a 5f gap. 
                    if first_flash then 
                        flash_t = 1
                    else
                        flast_t = 0
                    end
                    first_flash = false
                    flashes = flashes - 1
                    if flashes == 0  then 
                        self:delete()
                    end
                end

                local field = actor:get_field()
                field:spawn(flashing, 0, 0)
            end)

            anim:on_complete(function()
                self.finished = true
            end)
        end,

        on_update = function(self, actor, manager)
           if self.finished then 
                manager:add_state(create_disappear_state())
                manager:next_state()
           end
        end,
        on_end = function(self, actor, manager) end
    }
end

function create_appear_state()
    return 
    {
        finished = false,
        color_done = false,
        color = Color.new(0, 0, 255, 0),
        a_time = 6,
        a_count = 0,
        b_time = 26,
        b_count = 26,
        wait_time = 14,
        wait_count = 0,
        on_start = function(self, actor, manager)
            actor:reveal()
            local anim = actor:get_animation()
            anim:set_state("DEFAULT")
            anim:on_complete(function()
                -- Assume update coloring finishes before this
                self.finished = true
            end)
            anim:refresh(actor:sprite())
        end,
        on_update = function(self, actor, manager) 
            if self.finished and self.color_done then 
                if actor:get_tile():is_walkable() then 
                    manager:add_state(create_point_state())
                else
                    manager:add_state(create_disappear_state())
                end

                manager:next_state()
                return
            end

            if self.color_done then return end
            local a_count = self.a_count
            if a_count ~= self.a_time+1 then
                self.color.a = math.floor(255 * (a_count / self.a_time))
                self.a_count = a_count+1
            else
                local wait_count = self.wait_count
                local b_count = self.b_count
                if wait_count == self.wait_time then 
                    if b_count ~= -1 then 
                        self.color.b = math.floor(255 * (b_count / self.b_time))
                        self.b_count = b_count-1
                    else
                        self.color_done = true
                    end
                else
                    self.wait_count = wait_count+1
                end
            end

            actor:set_color(self.color)
        end,
        on_end = function(self, actor, manager) end
    }
end

function create_disappear_state()
    return 
    {
        finished = false,
        color = Color.new(0, 0, 255, 255),
        a_time = 6,
        a_count = 6,
        b_time = 26,
        b_count = 0,
        wait_time = 14,
        wait_count = 0,
        on_start = function(self, actor, manager)
            local anim = actor:get_animation()
            anim:set_state("DISAPPEAR")
            anim:refresh(actor:sprite())
        end,
        on_update = function(self, actor, manager) 
            local b_count = self.b_count
            local a_count = self.a_count
            if b_count ~= self.b_time+1 then 
                self.color.b = math.floor(255 * (b_count / self.b_time))
                self.b_count = b_count+1
            else
                local wait_count = self.wait_count
                if wait_count == self.wait_time then 
                    if a_count ~= -1 then
                        self.color.a = math.floor(255 * (a_count / self.a_time))
                        self.a_count = a_count-1
                    else
                        manager:next_state()
                    end
                else
                    self.wait_count = wait_count+1
                end
            end

            actor:set_color(self.color)
        end,
        on_end = function(self, actor, manager) end
    }
end

function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())
   
    action.execute_func = function(self)
        local field = user:get_field()
        local actor = self:get_actor()
        local facing = user:get_facing()
        local team = user:get_team()
        local context = user:get_context()
        local tile = user:get_current_tile()

        local manager = nil
        local step = nil

        local realtime_controller = Battle.Spell.new(actor:get_team())
        local navi = graphic_init("spell", 0, 0, NAVI_TEXTURE, NAVI_ANIM_PATH, -1, "", actor, facing)
        navi:hide()
        navi:set_float_shoe(true)
        navi.can_move_to_func = function()
            return true
        end

        -- Because HitProps will be garbage collected even if Lua holds them.
        -- Also because the manager doesn't have props and I want to reuse 
        -- context without passing both into the already-long function signature.
        navi.generate_hit_props = function()
            return HitProps.new(
                props.damage,
                Hit.Impact | Hit.Flinch | Hit.Flash,
                props.element,
                Element.Sword,
                context, 
                Drag.None
            )
        end

        local count = 0
        local finish_delay = 16

        if props.time_freeze then 
            step = Battle.Step.new()
        else
            step = Battle.Component.new(realtime_controller, Lifetimes.Local)
        end

        field:spawn(navi, tile)
        local started = false
        step.update_func = function()
            if count == 3 then 
                if props.time_freeze then 
                    actor:hide()
                end
                
                manager = make_state_manager(navi, create_appear_state())
                Engine.play_audio(APPEAR_SFX, AudioPriority.Low)
            end

            if manager then 
                manager:update()
            end

            if manager and manager:is_finished() then
                if not navi:is_deleted() then navi:delete() end
                finish_delay = finish_delay - 1
                if finish_delay == 0 then 
                    if props.time_freeze then
                        step:complete_step()
                    end
                    realtime_controller:delete()
                end
            end
            
            count = count + 1
        end

        if not props.time_freeze then 
            realtime_controller:register_component(step)
        else
            self:add_step(step)
        end
        
        field:spawn(realtime_controller, tile)
    end

    return action
end

function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
    flip = flip or false
    delete_on_complete = delete_on_complete or false
    facing = facing or nil
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()

    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())

    end

    graphic:sprite():set_layer(layer)
    graphic:never_flip(flip)
    graphic:set_texture(texture)
    if facing then 
        graphic:set_facing(facing)
    end
    
    if user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    anim:load(animation)

    anim:set_state(state)
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end
