local FLIP_SFX = Engine.load_audio(_folderpath.."flip.ogg")
local SHOOT_SFX = Engine.load_audio(_folderpath.."shoot.ogg")

local KUNAI_TEXTURE = Engine.load_texture(_folderpath.."battle_fx43_animations.png")
local KUNAI_ANIM_PATH = _folderpath.."battle_fx43_animations.animation"
local SHADOW_TEXTURE = Engine.load_texture(_folderpath.."shadow.png")

function package_init(package) 
    package:declare_package_id("com.alrysc.card.BetterKunai")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'K', 'N', 'S', '*'})

    local props = package:get_card_props()
    props.shortname = "Kunai"
    props.damage = 30
    props.time_freeze = false
    props.element = Element.Sword
    props.description = "Kunai spins and shoots!"
    props.card_class = CardClass.Standard
    props.limit = 3
end

function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_SWORD")
    action:set_lockout(make_animation_lockout())
  
    --7, 2, 2, 15
    local override_frames = {
        {1, 0.116}, {2, 0.033}, {3, 0.033}, {4, 0.25}
    }
    local frame_data = make_frame_data(override_frames)
    action:override_animation_frames(frame_data)
    action.execute_func = function(self, actor)

        
    --    create_kunai(user, user:get_tile(Direction.join(Direction.Up, user:get_facing()), 1), props)
      --  create_kunai(user, user:get_tile(Direction.join(Direction.Down, user:get_facing()), 1), props)

        action:add_anim_action(2, function()
            local hilt = self:add_attachment("HILT")
            local hilt_sprite = hilt:sprite()
            hilt_sprite:set_texture(actor:get_texture())
            hilt_sprite:set_layer(-1)
            
            local hilt_anim = hilt:get_animation()
            hilt_anim:copy_from(actor:get_animation())
            hilt_anim:set_state("HAND")
            create_kunai(user, user:get_tile(user:get_facing(), 1), props)
            Engine.play_audio(FLIP_SFX, AudioPriority.Low)

        end)
        
    end

    return action
end


function extra_kunai_attack(field, team, props, tile, attack_duration)
    local spell = Battle.Spell.new(team)
    spell:set_hit_props(props)

    spell.update_func = function(self)
        if attack_duration == 0 then 
            self:delete()
        else
            tile:attack_entities(self)
        end

        attack_duration = attack_duration - 1
    end

    field:spawn(spell, tile)
end

function create_kunai(user, tile, props)
    if not tile or tile:is_edge() then return end
    local field = user:get_field()
    local spell = graphic_init("spell", 0, 0, KUNAI_TEXTURE, KUNAI_ANIM_PATH, -1, "2", user, user:get_facing())
    local anim = spell:get_animation()
    anim:set_playback(Playback.Loop)
    spell:set_elevation(40)

    spell:set_shadow(SHADOW_TEXTURE)
    spell:show_shadow(true)

    local hit_props = HitProps.new(
        props.damage,
        Hit.Impact | Hit.Flinch,
        props.element,
        user:get_context(),
        Drag.None
    )

    spell:set_hit_props(hit_props)

    local attacks = 2
    local attack_duration = 10
    local delay = 0
    local lifetime = attack_duration * (attacks)
    local move_time = 6
    local moving = false
    spell.update_func = function(self)
        if move_time > 0 then 
            if moving then 
                move_time = move_time - 1
                
            end

            return
        end
        if delay == 0 then 
            if attacks > 0 then 
                extra_kunai_attack(self:get_field(), self:get_team(), hit_props, self:get_current_tile(), attack_duration)
                delay = attack_duration
                attacks = attacks - 1
            else
                extra_kunai_attack(self:get_field(), self:get_team(), hit_props, self:get_current_tile(), 1)

                create_shooting_kunai(self)
                self:delete()
                self:hide()
            end
        end

        delay = delay - 1
    end

    spell.on_spawn_func = function(self)
        local team = user:get_team()
        local field = user:get_field()
        local found_enemy = false
        local t = tile
        local dir = 1
        local target_x = field:width()
        local facing = user:get_facing()

        local move_dir = facing
        if facing == Direction.Left then 
            dir = -1
            target_x = 0
        end

        local function check_row_ahead(start_x, y)
            for i=start_x, target_x, dir
            do
                local t = field:tile_at(i, y)
                if not t or t:is_edge() then return false end

              --  print("Check "..(i))
                if t:find_characters(function(c) 
                    return not c:is_deleted() and c:get_health() > 0 and c:get_team() ~= team
                end)[1] then 
                    return true
                end
            end
        end
        
        local dest = tile
        if not check_row_ahead(dest:x(), dest:y()) then 
            if check_row_ahead(dest:x(), dest:y()-1) then 
                dest = dest:get_tile(Direction.Up, 1)
            else
                if check_row_ahead(dest:x(), dest:y()+1) then 
                    dest = dest:get_tile(Direction.Down, 1)

                end
            end
        end
            
      
       -- dest = self:get_current_tile()
     --  move_time = 0
       --field:spawn(spell, dest)
       
        if dest == self:get_current_tile() then 
            move_time = 0
        else
            self:slide(dest, frames(move_time), frames(0), ActionOrder.Immediate, function()
                moving = true
            end)
        end
    end

    spell.can_move_to_func = function()
        return true
    end

    --[[
    anim:on_frame(1, function()
        extra_kunai_attack(spell:get_field(), spell:get_team(), hit_props, spell:get_current_tile())
    end)

    anim:on_frame(6, function()
        extra_kunai_attack(spell:get_field(), spell:get_team(), hit_props, spell:get_current_tile())
    end)

    anim:on_complete(function()
        create_shooting_kunai(spell)
        spell:delete()
        spell:hide()
    end)
]]

    
    field:spawn(spell, tile)
end

function create_shooting_kunai(previous)
    local spell = graphic_init("spell", 0, 0, KUNAI_TEXTURE, KUNAI_ANIM_PATH, -1, "1", previous, previous:get_facing())
    spell:set_elevation(previous:get_elevation())

    spell:set_shadow(SHADOW_TEXTURE)
    spell:show_shadow(true)

    local props = previous:copy_hit_props()
    spell:set_hit_props(props)
    spell.delay = 13

    spell.update_func = function(self)
        local t = self:get_current_tile()

        local delay = self.delay
        if delay > 0 then 
            self.delay = delay - 1
        else
            if delay == 0 then 
                Engine.play_audio(SHOOT_SFX, AudioPriority.Low)
                self.delay = delay - 1
            end

            t:attack_entities(self)

            if not self:is_moving() then 
                local dest = t:get_tile(self:get_facing(), 1)
                if not dest then
                    self:delete()
                    return
                end

                self:slide(dest, frames(7), frames(0), ActionOrder.Voluntary, nil)
            end
        end
    end

    spell.can_move_to_func = function()
        return true
    end

    previous:get_field():spawn(spell, previous:get_current_tile())
end

function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
    flip = flip or false
    delete_on_complete = delete_on_complete or false
    facing = facing or nil
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()

    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())

    end

    graphic:sprite():set_layer(layer)
    graphic:never_flip(flip)
    graphic:set_texture(texture, false)
    if facing then 
        graphic:set_facing(facing)
    end
    
    if user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    anim:load(animation)

    anim:set_state(state)
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

return card_create_action