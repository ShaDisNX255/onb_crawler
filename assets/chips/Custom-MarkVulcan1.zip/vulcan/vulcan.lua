-- Preview is -40 brightness, +30 contrast
-- TODO: The attack loop for the Vulcan misaligns its first frame only because 
-- it plays for 2f the first time and 3f every other time.
local attachment_texture = Engine.load_texture(_folderpath.."attachment.png")
local attachment_animation_path = _folderpath.."attachment.animation"
local vulcan_impact_texture = Engine.load_texture(_folderpath.."vulcan_impact.png")
local vulcan_impact_animation_path = _folderpath.."vulcan_impact.animation"
local bullet_hit_texture = Engine.load_texture(_folderpath.."bullet_hit.png")
local bullet_hit_animation_path = _folderpath.."bullet_hit.animation"
local gun_sfx = Engine.load_audio(_folderpath.."EXE4_200.ogg")

local RETICLE_TEX = Engine.load_texture(_folderpath.."battle_fx23_animations.png")
local RETICLE_ANIM_PATH = _folderpath.."battle_fx23_animations.animation"
local RED_TEX = Engine.load_texture(_folderpath.."red.png")
local LOCK_START_SFX = Engine.load_audio(_folderpath.."lock_start.ogg")
local LOCK_ON_SFX = Engine.load_audio(_folderpath.."lockon.ogg")

local vulcan = {}

function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
    flip = flip or false
    delete_on_complete = delete_on_complete or false
    facing = facing or nil

    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()

    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())

    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end

    graphic:sprite():set_layer(layer)
    graphic:never_flip(flip)
    graphic:set_texture(texture)
    if facing then 
        graphic:set_facing(facing)
    end

    if user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    anim:load(animation)

    anim:set_state(state)
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

function spawn_hitbox(field, facing, props, team, tile)
    local spell = Battle.Spell.new(team)
    spell:set_facing(facing)
    spell:set_hit_props(props)

    spell.on_spawn_func = function()
        tile:attack_entities(spell)
    end

    spell.update_func = function()
        spell:delete()
    end

    field:spawn(spell, tile)
end

function create_vulcan_shot(team, context, props, facing)
    local spell = Battle.Spell.new(team)
    spell:set_facing(facing)
    spell.slide_started = false
    local props = HitProps.new(
        props.damage,
        Hit.Impact | Hit.Flinch,
        props.element,
        context,
        Drag.None
    )

    spell.update_func = function(self, dt) 
        self:get_tile():attack_entities(self)
        local dest = self:get_tile(self:get_facing(), 1)
        if not self:is_sliding() then
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end
            
            self:slide(dest, frames(1), frames(0), ActionOrder.Involuntary, function()
                self.slide_started = true 
            end)
        end
    end
    
    spell.collision_func = function(self, other, judge)
        local field = self:get_field()
        local tile = other:get_tile()
        local facing = self:get_facing()
        local next_tile = tile:get_tile(facing, 1)

        spawn_hitbox(field, facing, props, self:get_team(), tile)
        if next_tile and not next_tile:is_edge() then
            spawn_hitbox(field, facing, props, self:get_team(), next_tile)
        end

        local hit_off = {
            x = math.random(-20, 20) >> 1 << 1,
            y = math.random(-55, -30) >> 1 << 1
        }

        field:spawn(graphic_init("artifact", hit_off.x, hit_off.y, vulcan_impact_texture, vulcan_impact_animation_path, -1, "IDLE", self, facing, true), tile)
        if judge:hint_spawn_gfx() then
            local hit_off2 = {
                x = math.random(-20, 20) >> 1 << 1,
                y = math.random(-55, -30) >> 1 << 1
            }
            field:spawn(graphic_init("artifact", hit_off2.x, hit_off2.y, bullet_hit_texture, bullet_hit_animation_path, -1, "HIT", self, facing, true), tile)
        end
        
        self:delete()
    end

    spell.can_move_to_func = function(tile)
        return true
    end
    Engine.play_audio(gun_sfx, AudioPriority.Immediate)
    return spell
end

function find_enemy_ahead(user)
    local team = user:get_team()
    local field = user:get_field()
    local facing = user:get_facing()
    for i=1, field:width() do
        local t = user:get_tile(facing, i)
        if not t or t:is_edge() then return nil end

        local chars = t:find_characters(function(c) return c:get_team() ~= team end)
        if chars[1] then 
            return chars[1]
        end
    end
end

vulcan.card_create_action = function(user,props)
    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
	action:set_lockout(make_animation_lockout())
    action.shots_animated = vulcan.shots_animated
    action.hits = vulcan.hits
    local vulcan_direction = user:get_facing()
    local f_padding = {1,0.033}
    action.frames = {f_padding,f_padding,f_padding,f_padding,f_padding,f_padding,f_padding}
    local hit_props = HitProps.new(
        props.damage, 
        Hit.Impact | Hit.Flinch, 
        props.element,
        user:get_context(),
        Drag.None
    )

    action.before_exec = function (action)
        local f_flash = {2,0.033}
        local f_between = {3,0.05}
        for i = 1, action.shots_animated, 1 do
            table.insert(action.frames,3,f_between)
            table.insert(action.frames,3,f_flash)
        end
        local FRAME_DATA = make_frame_data(action.frames)
        action:override_animation_frames(FRAME_DATA)
    end

    --prepare override frame data
    action.before_exec(action)

    local searching = false
    local red = nil
    local cursor = nil
    local attachment_animation = nil
    local search_time = 60
    local target_tile = nil
    local delay_time = 2
    action.update_func = function(self)
        if target_tile then 
            delay_time = delay_time - 1
            if delay_time == 0 then 
                local actor = self:get_actor()
                Engine.play_audio(LOCK_ON_SFX, AudioPriority.Immediate)
                actor:get_animation():set_playback_speed(1.0)
                red:hide()
                red:delete()

                local spell = Battle.Spell.new(user:get_team())
                spell:set_hit_props(HitProps.new()
                    :from(user:get_context())
                    :stun(frames(90))
                    :no_counter()
                )

                spell.update_func = function(self)
                    self:get_tile():attack_entities(self)
                    self:delete()
                end

                local fx = graphic_init("artifact", 0, -50, RETICLE_TEX, RETICLE_ANIM_PATH, -3, "1", actor, actor:get_facing())
                cursor = fx
                actor:get_field():spawn(spell, target_tile)
                actor:get_field():spawn(fx, target_tile)
            end
            return
        end

        if not searching then return end

        search_time = search_time - 1
        if search_time < 0 then 
            self:end_action()
            searching = false
            return
        end

        local target = find_enemy_ahead(user)
        if not target then
            --ignore any hits beyond the first one
            return
        end

        target_tile = target:get_tile()
        searching = false
    end

    action.execute_func = function(self, user)
        Engine.play_audio(LOCK_START_SFX, AudioPriority.Immediate)
        local actor = self:get_actor()
        local field = actor:get_field()
        actor:get_animation():set_playback_speed(0.0)
        --local props = self:copy_metadata()
        local attachment = self:add_attachment("BUSTER")
        local attachment_sprite = attachment:sprite()
        attachment_sprite:set_texture(attachment_texture)
        attachment_sprite:set_layer(-2)
        attachment_animation = attachment:get_animation()
        attachment_animation:load(attachment_animation_path)
        attachment_animation:set_state("SPAWN")
        attachment_animation:on_complete(function()
            searching = true
        end)

        self:add_anim_action(3,function()
            attachment_animation:set_state("ATTACK")
            attachment_animation:set_playback(Playback.Loop)
		end)

        local facing = actor:get_facing()
        red = Battle.Artifact.new()
        red:set_texture(RED_TEX)
        -- This does not affect the direction the width grows in, unfortunately
        red:set_facing(facing)
        red:sprite():set_layer(-1)
        local off = actor:get_offset()
        local origin = actor:get_animation():point("origin")
        local point = actor:get_animation():point("buster")
        local laser_point = attachment_animation:point("laser")
        local attach_origin = attachment_animation:point("origin")
        local vulcan_end = {
            x = -1 * origin.x + point.x - attach_origin.x + laser_point.x,
            y = -1 * origin.y + point.y - attach_origin.y + laser_point.y
        }
        local facing_mod = 1
        if facing == Direction.Left then 
            facing_mod = -1
        end
        red:sprite():set_width(Engine.get_viewport_size().x * facing_mod)
        red:set_offset(vulcan_end.x * 2 * facing_mod, vulcan_end.y * 2)
        field:spawn(red, actor:get_current_tile())

        local team = user:get_team()
        local context = user:get_context()
        for i = 1, action.hits, 1 do
            self:add_anim_action(i*4,function()
                field:spawn(create_vulcan_shot(team, context, props, facing), user:get_tile(facing, 1))
            end)
        end
        self:add_anim_action(#action.frames-5,function()
            --show lag animation for last 5 overriden frames
            attachment_animation:set_state("END")
        end)

    end

    action.action_end_func = function(self)
        seaching = false
        self:get_actor():get_animation():set_playback_speed(1.0)
        if red and not red:is_deleted() then 
            red:delete()
            red:hide()
        end

        if cursor and not cursor:is_deleted() then 
            cursor:delete()
            cursor:hide()
        end
    end

    return action
end

return vulcan