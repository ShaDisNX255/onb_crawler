--PREVIOUS Bugs: (think most are fixed now)
--code for some reason creates attacks at tiles from both the create attack and the create explosion, resulting in multi hits. Possible solution: remove all damage from the blast and make a third "impact" attack.
--for some reason tile2B doesn't spread properly, and will often appear at the end of the field or not appear at all. No clue what could be causing this.
--Hitting enemies in certain states with this chip just straight up crashes the game. Think this may have something to do with the target moving?

local BUSTER_TEXTURE = Engine.load_texture(_modpath.."heatbuster.png")
local BURST_TEXTURE = Engine.load_texture(_modpath.."spread_impact.png")
local HITAUDIO = Engine.load_audio(_modpath.."heatShotImpact.ogg")
local SHOTAUDIO = Engine.load_audio(_modpath.."sfx.ogg")
local INPUTAUDIO = Engine.load_audio(_modpath.."input.ogg")

local frame1 = {1, 0.1} --need to finetune these + animation file in general. Need to remember to ask about how frame timings should be.
local frame2 = {2, 0.05}
local frame3 = {3, 0.05}
local frame4 = {4, 0.05}
local frame5 = {5, 0.1}
local FRAMES = make_frame_data({frame1, frame2, frame3, frame4, frame5})

function package_init(package)
    package:declare_package_id("hoov.cards.neohetr2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes({"C","D","E"})
 
    local props = package:get_card_props()
    props.shortname = "NeoHetr2"
    props.damage = 80
    props.time_freeze = false
    props.element = Element.Fire
    props.description = "V-gun atk! B = pwrblast" --Powerful V-blast!
    props.limit = 4
end

function card_create_action(actor, props) --Shot properties
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
	
	action:override_animation_frames(FRAMES)
    local readystep =Battle.Step.new()
    local firestep = Battle.Step.new()
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(BUSTER_TEXTURE, true)
		buster:sprite():set_layer(-1)
		
		local buster_anim = buster:get_animation()
		buster_anim:load(_modpath.."heatbuster.animation")
		buster_anim:set_state("NEO")
		
        local canmove = true
        local timer = 0
        action:add_step(readystep)
        action:add_step(firestep)
        local chipdamage = props.damage
        local playsound = true
        readystep.update_func = function()
            actor:toggle_counter(true)
            if user:input_has(Input.Pressed.Shoot) or user:input_has(Input.Held.Shoot) then
                if playsound then
                    print("input registered")
                    Engine.play_audio(INPUTAUDIO, AudioPriority.Low)
                    playsound = false
                    end
                canmove = false
                
            end
            timer = timer + 1
            if timer == 10 then
                print("ready")
                readystep:complete_step()
            end
        end
        local do_once = true
        firestep.update_func = function()
        if do_once then
            if canmove == false then
                chipdamage = chipdamage + 20
            end
            actor:toggle_counter(false)
            local cannonshot = create_attack(user, props, chipdamage, canmove, true)
            local tile = user:get_tile(user:get_facing(), 1)
            actor:get_field():spawn(cannonshot, tile)
            Engine.play_audio(SHOTAUDIO, AudioPriority.Low)
            print("fire")
            do_once = false
        end
        timer = timer + 1
        if timer == 25 then
            print ("done")
            firestep:complete_step()
        end
        end
	end
    return action
end

function create_attack(user, props, mydamage, canmove, source)
	local spell = Battle.Spell.new(user:get_team())
	spell.slide_started = false
	local direction = user:get_facing()
    spell:set_hit_props(
        HitProps.new(
            mydamage, --originally props.damage
            Hit.Impact, 
            Element.Fire,
            user:get_context(),
            Drag.None
        )
    )
	
    spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)
        if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end 
			
            local dest = self:get_tile(direction, 1)
            local ref = self
            if canmove then
            self:slide(dest, frames(1), frames(0), ActionOrder.Voluntary, 
                function()
                    ref.slide_started = true 
                end
            )
            else
                local tile = self:get_current_tile()
                --if tile ~= nil then
                    --print(tile:x(), tile:y())
                --end
                create_fx(spell, props, tile)
                if source then
                    Engine.play_audio(HITAUDIO, AudioPriority.Low)
                    spread(self, spell, props, user, mydamage)
                end
                self:delete()
            end
        end
    end


    spell.collision_func = function(self, other)
		if canmove then
            local tile = self:get_current_tile()
            create_fx(spell, props, tile)
            Engine.play_audio(HITAUDIO, AudioPriority.Low)
            spread(self, spell, props, user, mydamage)
            self:delete()
        end
	end



    spell.delete_func = function(self)
        self:erase()
    end

    spell.can_move_to_func = function(tile)
        return true
    end

    Engine.play_audio(HITAUDIO, AudioPriority.Low) --was high
    return spell
end

function create_fx(spell, props, mytile)
    local fx = Battle.Artifact.new()
	fx:set_texture(BURST_TEXTURE, true)
	fx:get_animation():load(_modpath.."spread_impact.animation")
	fx:get_animation():set_state("DEFAULT")
	fx:get_animation():on_complete(function()
		fx:erase()
	end)
    fx:get_animation():refresh(fx:sprite())
	fx:set_height(-16.0)
	
    if mytile and not mytile:is_edge() then
        spell:get_field():spawn(fx, mytile)
    end
end

function spread (self, spell, props, user, damage)
    local blast = create_attack(user, props, damage, false, false)
    local blast2 = create_attack(user, props, damage, false, false)
    local blast3 = create_attack(user, props, damage, false, false)
    local blast4 = create_attack(user, props, damage, false, false)

    local rightend = false --from here
    local leftend = false
    local direction = user:get_facing()
    local tile2A = self:get_current_tile():get_tile(direction, 1):get_tile(Direction.Up, 1)
    if tile2A and not tile2A:is_edge() then
        spell:get_field():spawn(blast, tile2A)
        leftend = true
    end
    if leftend == true then --hopefully should prevent nil tileget when out of bounds
    local tile2B = self:get_current_tile():get_tile(direction, 2):get_tile(Direction.Up, 2)
    if tile2B and not tile2B:is_edge() then
        spell:get_field():spawn(blast2, tile2B)
    end
    end
    local tile3A = self:get_current_tile():get_tile(direction, 1):get_tile(Direction.Down, 1)
    if tile3A and not tile3A:is_edge() then
        spell:get_field():spawn(blast3, tile3A)
        rightend = true
    end
    if rightend == true then
    local tile3B = self:get_current_tile():get_tile(direction, 2):get_tile(Direction.Down, 2)
    if tile3B and not tile3B:is_edge() then
        spell:get_field():spawn(blast4, tile3B)
    end
    end --to here
end

