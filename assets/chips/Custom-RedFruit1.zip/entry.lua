local ObstacleInfo = include("ObstacleInfo/ObstacleInfo.lua")
local TEXTURE = Engine.load_texture(_modpath.."RedFruit.png")
local RECOVERY_TEXTURE = Engine.load_texture(_folderpath.."recovery.png")
local RECOVERY_ANIMPATH = _folderpath.."recovery.animation"
local RECOVERY_AUDIO = Engine.load_audio(_folderpath.."EXE4_335.ogg")
local TELEPORT_TEXTURE = Engine.load_texture(_folderpath.."Teleport.png")
local TELEPORT_ANIMPATH = _folderpath.."Teleport.animation"

function package_init(package) 
		package:declare_package_id("P0W3RK1D.card.RedFruit1")
		package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
		package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))


		local redfruit_texture = Engine.load_texture(_modpath.."RedFruit.png")
		local redfruit_animation_path = _modpath.."RedFruit.animation"

		package:set_codes({'K', 'E', 'Z'})

		local props = package:get_card_props()
		props.shortname = "RedFruit1"
		props.damage = 0
		props.time_freeze = false
		props.element = Element.None
		props.description = "Hit apple for +300 HP"
		props.can_boost = false
		props.limit = 4
		

		local apple = {}
		apple.summon_move_timer = 44
		apple.summon_times_moved = 5
		apple.dissapear_timer = 1
		apple.stranded_timer = 44
		apple.stranded_count = 0
		apple.dont_explode = 0
		

		--apple.explosion_timer = 0

	function card_create_action(actor, props)
		local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
		
			--this code here removes the frame lockout of your idle animation--
			--PLACE THIS UNDER THE BATTLE.CARDACTION.NEW TO MAKE IT WORK--
				action:set_lockout(make_async_lockout(0.33))
				local override_frames = {{1,0.017}}
				local frame_data = make_frame_data(override_frames)
				action:override_animation_frames(frame_data)
			-----------------------------------------------------------------
			-----------------------------------------------------------------


		action.execute_func = function(self, user)
			
			--this below will delete the apple if there is already one in existance. Below in the Battle.Object area the object is added to a table.
			if apple.action ~= nil then
				apple.action:delete()
				apple.summon_move_timer = 44
				apple.summon_times_moved = 5
			end



			local facing = actor:get_facing() 
			local field = actor:get_field()
			local team = actor:get_team()
			local tile = actor:get_tile() 
			local tile_2 = actor:get_tile(facing, 1) 
			local actor_tile = actor:get_tile()



					--this below defines the areas the apple can move to (ive also defined it below in the create_summon function)
						---------------------3 combined
	
								local function all_3_combined(tile)
			
									if tile:is_walkable() then

									
										--if tile:get_team() == actor:get_team() then

											

										-- 	local my_back_row = field:tile_at(1, 1)
										-- 	local my_back_row2 = field:tile_at(1, 2)
										-- 	local my_back_row3 = field:tile_at(1, 3)

										-- 	local enemy_back_row = field:tile_at(6, 1)
										-- 	local enemy_back_row2 = field:tile_at(6, 2)
										-- 	local enemy_back_row3 = field:tile_at(6, 3)


										-- if tile ~= my_back_row and tile ~= my_back_row2 and tile ~= my_back_row3 and tile ~= enemy_back_row and tile ~= enemy_back_row2 and tile ~= enemy_back_row3 then
										-- 	return true
										-- 	else return false
										-- end

											--##############(((BELOW IS THE EASIER WAY TO SAY THE ABOVE)))##############
									
										if tile:x() ~= 1 and tile:x() ~= 6 then
											
										


											
											local found_characters = tile:find_characters(function()
												return true
											end)
											
											local found_obstacles = tile:find_obstacles(function()
												return true
											end)

										

											if #found_characters == 0 and #found_obstacles == 0 then 

												
												return true
												else return false
								
												
										
											end
										end
										
									
									end
							
							
							end



						---------------------3 combined 

						local avalible_tiles_spawn = field:find_tiles(all_3_combined)



						if #avalible_tiles_spawn ~= 0 then
							create_summon(actor, team, facing, field, tile, redfruit_texture, redfruit_animation_path, tile_2, apple, action, avalible_tiles_spawn)
						
							--else print("THERE IS NO SPACE!!!!")
						end
		end
		return action
	end
end


--------------------------------------------------------------------------------------------
--------------------------------------RED FRUIT SUMMON----------------------------------


    function create_summon(actor, team, facing, field, tile, redfruit_texture, redfruit_animation_path, tile_2, apple, action, avalible_tiles_spawn)

		
			local summon_spell = Battle.Obstacle.new(Team.Other)
			
			apple.action = summon_spell
			--print(apple.action)
			

			ObstacleInfo.set_cannot_be_targeted(summon_spell, true)
			ObstacleInfo.set_cannot_be_manipulated(summon_spell, true)




			local defense_rule = Battle.DefenseRule.new(10, DefenseOrder.CollisionOnly)
			local target = nil
			local same_team = actor:get_team()
			
			defense_rule.can_block_func = function( defense_judge, attacker, target )
				local attack_props = attacker:copy_hit_props()
				local attacker_team = attacker:get_team()
				local attacker_ID = attacker:get_id()
				local attacking_entity = attacker:copy_hit_props().aggressor
				
	
				local userteam = actor:get_team()
				local enemy_target = actor:get_field():find_nearest_characters(actor, function(character)
					return character:get_team() ~= userteam 
				end)

				
				if( attack_props.flags & Hit.Impact ~= Hit.Impact ) then
	
					defense_judge:block_damage()
					defense_judge:block_impact()
			   
				   --print(attacker_team)
				   --print(attacker_ID)

				else
	
				   
				   if attacker_team ~= actor:get_team() then 
					--print("THIS IS THE ENEMY")
					enemy_target[1]:set_health(enemy_target[1]:get_health() + 300)
					
					Engine.play_audio(RECOVERY_AUDIO, AudioPriority.High)
					  create_effect_2(facing, RECOVERY_TEXTURE, RECOVERY_ANIMPATH, "0", 0, 0, true, -9, field, tile, actor, enemy_target)
	
				   end
	
				   if attacker_team == actor:get_team() then
					--print("NAHHH THIS U BRO!?")
				  	actor:set_health(actor:get_health() + 300)
				 
					  Engine.play_audio(RECOVERY_AUDIO, AudioPriority.High)
					  create_effect(facing, RECOVERY_TEXTURE, RECOVERY_ANIMPATH, "0", 0, 0, true, -9, field, tile, actor)
				   end
				   
				end
			end
			
			local apple_countdown_number = apple.summon_times_moved
			
			summon_spell:add_defense_rule(defense_rule)
			summon_spell:set_name('RedFruit')
			summon_spell:set_element( Element.None ) 
			summon_spell:get_animation():refresh(summon_spell:sprite())
			summon_spell:sprite():set_texture(redfruit_texture, true)
			summon_spell:get_animation():refresh(summon_spell:sprite())
			summon_spell:set_facing(facing)
			summon_spell:set_health(1) 
			summon_spell:get_animation():load(redfruit_animation_path)
			summon_spell:get_animation():set_state("REDFRUIT_"..apple_countdown_number)
			summon_spell:get_animation():refresh(summon_spell:sprite())
			--print(apple.summon_times_moved)
			apple.summon_times_moved = apple.summon_times_moved - 1
					

	
		  
	
			
			
	
	
	
	
							--THIS BELOW IS THE CODE THAT GIVES THE SPELL INFO FOR WHERE IT CAN SPAWN--
						---------------------3 combined
	
								local function all_3_combined(tile)
	
										if tile:is_walkable() then
	
										
											--if tile:get_team() == actor:get_team() then

												

											-- 	local my_back_row = field:tile_at(1, 1)
											-- 	local my_back_row2 = field:tile_at(1, 2)
											-- 	local my_back_row3 = field:tile_at(1, 3)

											-- 	local enemy_back_row = field:tile_at(6, 1)
											-- 	local enemy_back_row2 = field:tile_at(6, 2)
											-- 	local enemy_back_row3 = field:tile_at(6, 3)


											-- if tile ~= my_back_row and tile ~= my_back_row2 and tile ~= my_back_row3 and tile ~= enemy_back_row and tile ~= enemy_back_row2 and tile ~= enemy_back_row3 then
											-- 	return true
											-- 	else return false
											-- end

												--##############(((BELOW IS THE EASIER WAY TO SAY THE ABOVE)))##############
										
											if tile:x() ~= 1 and tile:x() ~= 6 then
												
											


												
												local found_characters = tile:find_characters(function()
													return true
												end)
												
												local found_obstacles = tile:find_obstacles(function()
													return true
												end)

											

												if #found_characters == 0 and #found_obstacles == 0 then 
	
													
													return true
													else return false
									  
													
											
												end
											end
											
										
										end
								
								
								end
	
	
	
						---------------------3 combined 
	
				--THIS BELOW IS THE RANDOM SPAWN SPOT FOR THE SPELLS FIRST SPAWN--
				local avalible_tiles_spawn = field:find_tiles(all_3_combined)
				local random_tile_spawn = avalible_tiles_spawn[math.random(1, #avalible_tiles_spawn)]
				apple.first_random_tile = random_tile_spawn
				

				-------------------------------------------------------------------------------
				-------------------------------------------------------------------------------			
				-------------------------------------------------------------------------------










	
				summon_spell.delete_func = function(self, tile)

					-- that "DONT_EXPLODE" value/table was created above, and basically allows me to tell the thing to 
					-- vanish instead of exploding on deletion.

					if apple.dont_explode < 1 then
						--print("DELETION!!!!!")
						SNS_explosion(actor, team, facing, field, tile, redfruit_texture, redfruit_animation_path, tile_2, summon_spell, apple)
						Engine.play_audio(Engine.load_audio(_folderpath.."explode_once.ogg"), AudioPriority.High)		 
					end

					apple.stranded_count = 0
					apple.summon_move_timer = 44
					apple.summon_times_moved = 5
					apple.dissapear_timer = 1
					apple.action = nil
					apple.dont_explode = 0
					
				end

	



				summon_spell.update_func = function(self)

					local avalible_tiles = field:find_tiles(all_3_combined)




					-- THIS IS THE FIRST TIMEE U MOVE/SPAWN THE APPLE.
					if #avalible_tiles ~= 0 and apple.summon_times_moved >= 4 and apple.summon_move_timer == 43 then
						summon_spell_fade(actor, team, facing, field, tile, redfruit_texture, redfruit_animation_path, tile_2, summon_spell, apple, random_tile)
					end


					-- IF your apple dosent have anywhere to move its considered "Stranded" -- start this timer--
					-- Ultimatly these several functions here are to get the apple to act normally and continue to
					-- countdown even when it has nowhere to mvove.
						if #avalible_tiles == 0 then
							apple.stranded_timer = apple.stranded_timer - 1
						end

						if apple.stranded_timer <= 0 then
							local apple_countdown_number = apple.summon_times_moved
							summon_spell:teleport(summon_spell:get_tile(), ActionOrder.Voluntary, nil )
							summon_spell:get_animation():set_state("REDFRUIT_"..apple_countdown_number)
							summon_spell:get_animation():refresh(summon_spell:sprite())

							apple.stranded_timer = 44
							apple.stranded_count = apple.stranded_count + 1
							apple.summon_times_moved = apple.summon_times_moved -1

							summon_spell_fade(actor, team, facing, field, tile, redfruit_texture, redfruit_animation_path, tile_2, summon_spell, apple, random_tile)
						end

						if #avalible_tiles == 0 and apple.summon_times_moved <= -1 then 
							apple.dont_explode = 1
							apple.summon_times_moved = 5
							self:delete()
						end
					-----------------------------------------------------------------------------------------------
					-----------------------------------------------------------------------------------------------
				




					
					--THIS counts down the apple's NORMAL move timer -- its always counting to make sure your apple moves
					-- at the right time (44frames)
					apple.summon_move_timer = apple.summon_move_timer -1


					-- This here tells your apple's purple Teleport animation to play when the move_timer has counter down to 
					-- 2 (2 frames before 0, and the thing resets)
						if #avalible_tiles ~= 0 and apple.summon_move_timer == 2 then

							summon_spell_fade(actor, team, facing, field, tile, redfruit_texture, redfruit_animation_path, tile_2, summon_spell, apple, random_tile)
							local avalible_tiles = field:find_tiles(all_3_combined)
							local random_tile = avalible_tiles[math.random(1, #avalible_tiles)]
							apple.current_random_tile = random_tile
							summon_spell_arrive(actor, team, facing, field, tile, redfruit_texture, redfruit_animation_path, tile_2, summon_spell, apple, random_tile)
						
						end
					---------------------------------------------------------------------------------------------------------
					---------------------------------------------------------------------------------------------------------



					-- IF there are tiles to move to AND the move_timer has reached Zero, then ...
					-- Check if you moved less than 5 times
					-- If both are true then move the apple to the new random tile, and change its number, Then reset the Timers.

						if #avalible_tiles ~= 0 and apple.summon_move_timer <= 0 then	
							--print("MOVE!!!!")
									
							apple.stranded_count = 0
							local avalible_tiles = field:find_tiles(all_3_combined)

								
			
			
			
							if #avalible_tiles ~= 0 and apple.summon_times_moved > -1 then
								
								
								
								
								local apple_countdown_number = apple.summon_times_moved

						
								summon_spell:teleport(apple.current_random_tile, ActionOrder.Voluntary, nil )
								summon_spell:get_animation():set_state("REDFRUIT_"..apple_countdown_number)
								summon_spell:get_animation():refresh(summon_spell:sprite())

								

								apple.summon_move_timer = 44	
								apple.summon_times_moved = apple.summon_times_moved - 1
								apple.stranded_count = 0
								


								-- OTHERWISE, if there are tiles, BUT the apple has moved more than 5 times, then just delete it
								else if #avalible_tiles ~= 0 and apple.summon_times_moved <= -1 then
								
									apple.dissapear_timer = apple.dissapear_timer + 1
									
									if apple.dissapear_timer >= 6 then
										apple.dont_explode = 1
										self:delete()
										apple.dissapear_timer = 1
										apple.action = nil
									end
								end
							end


						end
					--------------------------------------------------------------------------------------------------------------
					--------------------------------------------------------------------------------------------------------------
					--------------------------------------------------------------------------------------------------------------


					
				end


					summon_spell.can_move_to_func = all_3_combined

				--local team_3 = Team.Other
			
				
					field:spawn(summon_spell, random_tile_spawn)

				
			   -- --print("nearly") 
	
			  
				
				return summon_spell
	
	   
	end
	
--------------------------------------RED FRUIT SUMMON----------------------------------
--------------------------------------------------------------------------------------------
	
	
	
	

-------------------------------APPLE Death EXPLOSION---------------------------------000

	 function SNS_explosion(actor, team, facing, field, tile, redfruit_texture, redfruit_animation_path, tile_2, summon_spell, apple)
		local SpeakNSpellLocation = summon_spell:get_tile()
		local explosion_texture = Engine.load_texture(_modpath.."mob_explosion.png")
		local explosion_animation_path = _modpath.."mob_explosion.animation"

		local explosion = Battle.Spell.new(team)

		local sprite = explosion:sprite()
		explosion:set_offset( 0, -40 )
		--explosion:never_flip(true) 
		sprite:set_texture(explosion_texture , true)
		sprite:set_layer(-3)
		
		
			
		local anim = explosion:get_animation()
		anim:load(explosion_animation_path)
		anim:set_state("EXPLODE")
		explosion:get_animation():refresh(explosion:sprite())
	

		apple.explosion_timer = 0

		explosion.update_func = function(self)
			apple.explosion_timer = apple.explosion_timer + 1

			if apple.explosion_timer >= 25 then
				self:delete()
			end

		end
		

		field:spawn(explosion, SpeakNSpellLocation)
				

		return explosion

	end

-------------------------------APPLE Death EXPLOSION---------------------------------000



----------------------SELF HEALING GRAPHIC------------------------------------

	function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, flip, offset_layer, field, tile, actor)
		local hitfx = Battle.Artifact.new()
		hitfx:set_facing(effect_facing)
		hitfx:set_texture(effect_texture, true)
		hitfx:set_offset(offset_x, offset_y)
		hitfx:never_flip(flip)
		local hitfx_sprite = hitfx:sprite()
		hitfx_sprite:set_layer(offset_layer)
		local hitfx_anim = hitfx:get_animation()
		hitfx_anim:load(effect_animpath)
		hitfx_anim:set_state(effect_state)
		hitfx_anim:refresh(hitfx_sprite)
		hitfx_anim:on_complete(function()
			hitfx:erase()
		end)
		field:spawn(hitfx, actor:get_tile())

		return hitfx
	end
----------------------SELF HEALING GRAPHIC------------------------------------


----------------------ENEMY HEALING GRAPHIC------------------------------------
	function create_effect_2(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, flip, offset_layer, field, tile, actor, enemy_target)
		local hitfx = Battle.Artifact.new()
		hitfx:set_facing(effect_facing)
		hitfx:set_texture(effect_texture, true)
		hitfx:set_offset(offset_x, offset_y)
		hitfx:never_flip(flip)
		local hitfx_sprite = hitfx:sprite()
		hitfx_sprite:set_layer(offset_layer)
		local hitfx_anim = hitfx:get_animation()
		hitfx_anim:load(effect_animpath)
		hitfx_anim:set_state(effect_state)
		hitfx_anim:refresh(hitfx_sprite)
		hitfx_anim:on_complete(function()
			hitfx:erase()
		end)
		field:spawn(hitfx, enemy_target[1]:get_tile())

		return hitfx
	end
----------------------ENEMY HEALING GRAPHIC------------------------------------


----------------------------------------EFFECT PRE ARRIVE-----------------------------------------------
	function summon_spell_arrive(actor, team, facing, field, tile, redfruit_texture, redfruit_animation_path, tile_2, summon_spell, apple, random_tile)

		local arrive = Battle.Artifact.new()
		local arrive_sprite = arrive:sprite()
		--hitfx_sprite:set_layer(offset_layer)
		local arrive_anim = arrive:get_animation()
		arrive:set_texture(TELEPORT_TEXTURE, true)
		arrive:get_animation():load(TELEPORT_ANIMPATH)
		arrive:get_animation():set_state("2")
		arrive:get_animation():refresh(arrive:sprite())
		arrive:get_animation():on_complete(function()
			arrive:erase()
		end)
	
			if apple.summon_times_moved > -1 then 
				field:spawn(arrive, random_tile)
			end
		return arrive
	end

----------------------------------------EFFECT PRE ARRIVE-----------------------------------------------




------------------------------------------EFFECT TELEPORT AWAY-------------------------------------------------------
	function summon_spell_fade(actor, team, facing, field, tile, redfruit_texture, redfruit_animation_path, tile_2, summon_spell, apple, random_tile)

		local fade = Battle.Artifact.new()
		local fade_sprite = fade:sprite()
		--hitfx_sprite:set_layer(offset_layer)
		local fade_anim = fade:get_animation()
		fade:set_texture(TELEPORT_TEXTURE, true)
		fade:get_animation():load(TELEPORT_ANIMPATH)
		fade:get_animation():set_state("3")
		fade:get_animation():refresh(fade:sprite())
		fade:get_animation():on_complete(function()
			fade:erase()
		end)
		if apple.summon_times_moved >= 5 then
			field:spawn(fade, apple.first_random_tile)

			else
				field:spawn(fade, summon_spell:get_tile())
			end
		return fade
	end


------------------------------------------EFFECT TELEPORT AWAY-------------------------------------------------------

