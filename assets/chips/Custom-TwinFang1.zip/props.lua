local data = {}

    data.package_id = "hoov.card.twinfang1"
    data.icon = Engine.load_texture(_modpath.."icon.png")
    data.preview = Engine.load_texture(_modpath.."preview.png")
    data.codes = {"A","B","C","*"}
    data.shortname = "TwnFng1"
    data.damage = 70
    data.time_freeze = false
    data.skip_time_freeze_intro = false
    data.can_boost = true
    data.card_class = CardClass.Standard
    data.element = Element.None
    data.secondary_element = Element.None
    data.description = "Launch 2 fangs up and down"
    data.long_description = "Launch 2 fangs up and down"
    data.limit = 4
    data.mb = 13

return data