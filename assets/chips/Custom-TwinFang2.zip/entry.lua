--local BUSTER_TEXTURE = Engine.load_texture(_modpath.."buster.png")
local ATK_TEXTURE = Engine.load_texture(_modpath .. "twinfangtexture.png")
local SHOOT_AUDIO = Engine.load_audio(_modpath .. "yoyothrow.ogg")
local HIT_AUDIO = Engine.load_audio(_modpath .. "yoyohit.ogg")
local traits = include("props.lua")

local frame1 = { 1, 0.1 }
local frame2 = { 2, 0.033 }
local frame3 = { 3, 0.033 }
local frame4 = { 4, 0.1 }
local busterframes = make_frame_data({ frame1, frame2, frame3, frame4 })

function package_init(package) -- Basic stuff
    package:declare_package_id(traits.package_id)
    package:set_icon_texture(traits.icon)
    package:set_preview_texture(traits.preview)
    package:set_codes(traits.codes)

    local props = package:get_card_props()
    props.shortname = traits.shortname
    props.damage = traits.damage
    props.time_freeze = traits.time_freeze
    props.element = traits.element
    props.secondary_element = traits.secondary_element
    props.description = traits.description
    props.limit = traits.limit


    -- assign the global resources
end

function card_create_action(self, props)
    print("in create_card_action()!")

    local action = Battle.CardAction.new(self, "PLAYER_SHOOTING")
    action:override_animation_frames(busterframes)
    action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        --buster sprite
        local buster = action:add_attachment("Buster")
        buster:sprite():set_texture(user:get_texture(), true)
        buster:sprite():set_layer(-1)
        buster:sprite():enable_parent_shader(true)

        local buster_anim = buster:get_animation()
        buster_anim:copy_from(user:get_animation())
        buster_anim:set_state("BUSTER")
        --local direction = user:get_facing()
        local tile = user:get_current_tile()
        --gotta add the create shot functions. use code from 3way
        local shot1 = create_shot(user, 1, props)
        local shot2 = create_shot(user, 2, props)
        user:get_animation():on_frame(1, function()
            user:toggle_counter(true)
            user:get_field():spawn(shot1, tile)
            user:get_field():spawn(shot2, tile)
            Engine.play_audio(SHOOT_AUDIO, AudioPriority.Low)
        end, false)
        user:get_animation():on_frame(4, function()
            user:toggle_counter(false)
        end, false)
        user:get_animation():on_interrupt(function()
            user:toggle_counter(false)
            --print("interrupoted!")
        end)
    end

    return action
end

function create_shot(user, vertical, props)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(user:get_facing())
    --Set the hit properties of this spell.
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            props.element,
            user:get_context(),
            Drag.None
        )
    )
    local sprite = spell:sprite()
    sprite:set_texture(ATK_TEXTURE)
    sprite:set_layer(-1)
    local anim = spell:get_animation()
    anim:load(_modpath .. "twinfang.animation")
    anim:set_state("SPAWN")
    anim:refresh(spell:sprite())

    anim:on_complete(function()
        anim:set_state("IDLE")
        anim:set_playback(Playback.Loop)
    end)
    spell:set_shadow(Shadow.Small)
    spell:show_shadow(true)
    spell:set_elevation(20)
    local hasntmoved = true
    local coredirection = user:get_facing()
    spell.update_func = function(self, dt)
        local direction = nil

        --"vertical" controls if its moving up or down initially
        if hasntmoved then
            if vertical == 1 then
                direction = Direction.Up
                --print("moveup")
            elseif vertical == 2 then
                direction = Direction.Down
                --print("movedown")
            else
                print("INVALID INPUT WHY DID YOU DO THIS")
            end
        else
            direction = coredirection
            --print("movefoward")
        end
        --- Gets the next tile in the specified direction.
        --- If that tile is out of bounds, it returns nil
        local tile = spell:get_tile(direction, 1)

        if (tile == nil) then
            -- Spell will be erased once it reaches the end of the field.
            --print("erased")
            spell:delete()
            return
        end
        --- Makes the spell slide to the next tile over a certain number of frames.
        spell:slide(tile, frames(4), frames(0), ActionOrder.Voluntary, nil)
        --tilecount = tilecount + 1
        hasntmoved = false
        --- Attacks the entities this spell collides with.
        self:get_current_tile():attack_entities(self)
        --spell:highlight_tile(Highlight.Solid)
    end
    spell.collision_func = function(self, other, judge)
        --a
        spell:delete()
    end
    spell.attack_func = function(self, other, judge)
        judge:set_hit_sfx(HIT_AUDIO) --custom hit sound
        --Engine.play_audio(HIT_AUDIO, AudioPriority.Low)
    end

    spell.can_move_to_func = function(tile)
        return true
    end

    return spell
end
