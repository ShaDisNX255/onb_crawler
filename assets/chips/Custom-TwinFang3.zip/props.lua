local data = {}

data.package_id = "hoov.card.twinfang3"
data.icon = Engine.load_texture(_modpath .. "icon.png")
data.preview = Engine.load_texture(_modpath .. "preview.png")
data.codes = { "F", "G", "H" }
data.shortname = "TwnFng3"
data.damage = 130
data.time_freeze = false
data.skip_time_freeze_intro = false
data.can_boost = true
data.card_class = CardClass.Standard
data.element = Element.None
data.secondary_element = Element.None
data.description = "Launch 2 fangs up and down"
data.long_description = "Launch 2 fangs up and down"
data.limit = 4
data.mb = 39

return data
