local shockwave_texture = Engine.load_texture(_modpath.."battle_fx03_animations.png")
local shockwave_anim = _modpath.."battle_fx03_animations.animation"
local shockwave_audio = Engine.load_audio(_modpath.."shockwave.ogg")
local hit_audio = Engine.load_audio(_modpath.. "hitsound.ogg")

function package_init(package) 
    package:declare_package_id("hoov.cards.wavearm3")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon3.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."schip096.png"))
	package:set_codes({'R', 'S', 'T'})

    local props = package:get_card_props()
    props.shortname = "WaveArm3"
    props.damage = 160
    props.time_freeze = false
    props.element = Element.None
    props.description = "Fllw enemy and fire trap wave"
	props.can_boost = true
    props.limit = 4
end

function card_create_action(player, props)
    local action = Battle.CardAction.new(player, "PLAYER_SWORD")
    action:set_lockout(make_async_lockout(.50))
    action.execute_func = function(self, user)
        local actor = self:get_actor()
        self:add_anim_action(2, function()
            user:toggle_counter(true)
            local hilt = self:add_attachment("HILT")
            local hiltsprite = hilt:sprite()
            hiltsprite:set_texture(actor:get_texture())
            hiltsprite:set_layer(-2)
            hiltsprite:enable_parent_shader(true)
            local hiltanim = hilt:get_animation()
            hiltanim:copy_from(actor:get_animation())
            hiltanim:set_state("HAND")
		    hiltanim:refresh(hiltsprite)
        end)
        local spawnpoint = user:get_tile(user:get_facing(), 1)
        --local armwave = create_shockwave(user, props, false)
        self:add_anim_action(3, function()
            --user:get_field():spawn(armwave,spawnpoint)
            if spawnpoint:is_walkable() then
                create_shockwave(user, props, user:get_facing(), false, spawnpoint, user:get_facing())
            end
        end)
        self:add_anim_action(4, function()
            user:toggle_counter(false)
        end)

    end
    return action
end

function create_shockwave(user, props, facing, hasturned, spawntile, traveldirec)
    --if stuuff goes bad inclose this all in a function
    --function next_wave()
        --print("hello i am wavearmwave")
        local spell = Battle.Spell.new(user:get_team())
        --local myfield = user:get_field()
        --Set the hit properties of this spell.
        spell:set_facing(facing)
        spell:set_hit_props(
            HitProps.new(
                props.damage,
                Hit.Impact | Hit.Flash,
                props.element,
                user:get_context(),
                Drag.None
            )
        )
        local character_sensor = function(ent)
            if Battle.Character.from(ent) ~= nil then
                return true
            end
        end
        local find_ahead = function(user)
            local myfield = user:get_field()
            local y_axis = user:get_current_tile():y()
            local result_part
            local result_complete = 0
            local increment
            local limit
            if facing == Direction.Right then
                increment = 1
                limit = 6
            else
                increment = -1
                limit = 1
            end
            for xpos = user:get_tile(facing, 1):x(), limit, increment do
                result_part = myfield:tile_at(xpos, y_axis):find_characters(character_sensor)
                --myfield:tile_at(xpos, y_axis):highlight(Highlight.Solid)
                result_complete = result_complete + #result_part
            end
            --print("find_ahead results are as follows:", result_complete)
            return result_complete
        end
        local find_diag = function(user, direc)
            local checktile1 = user:get_tile(direc, 1)
            local checktile2 = user:get_tile(direc, 2)
            local result1 = #checktile1:find_characters(character_sensor)
            --checktile1:highlight(Highlight.Solid) --comment out once testings done
            local result2 
            if checktile2 ~= nil then
                result2 = #checktile2:find_characters(character_sensor)
                --checktile2:highlight(Highlight.Solid)
            else
                result2 = 0
            end
            local final_result = result1 + result2
            --print(final_result)
            return final_result
        end
        --local next_tile --cant set tile locations here cause it isn't spawned yet
        local currentframe = 0
        local destination
        local fowards_dir = spell:get_facing()
        local up_dir = Direction.join(spell:get_facing(), Direction.Up)
        local down_dir = Direction.join(spell:get_facing(), Direction.Down)
        --local nextone = create_shockwave(user, props, hasturned)
        local sprite = spell:sprite()
        sprite:set_texture(shockwave_texture)
        local animation = spell:get_animation()
        animation:load(shockwave_anim)
        animation:set_state("1")
        animation:refresh(sprite)
        Engine.play_audio(shockwave_audio, AudioPriority.Highest)
        animation:on_frame(3, function()
            --a
            local primeresult = find_ahead(spell)
            local upresult = find_diag(spell, Direction.join(user:get_facing(), Direction.Up))
            local downresult = find_diag(spell, Direction.join(user:get_facing(), Direction.Down))
            --local result1A = checktile1:find_characters(character_sensor)
            --local result2A = checktile2:find_characters(character_sensor)
            if hasturned == false and primeresult > 0 then
                traveldirec = fowards_dir
                print("straight ahread takes priority")
            elseif hasturned == false and upresult > 0 then
                traveldirec = up_dir
                hasturned = true
                print("turn upwards")
            elseif hasturned == false and downresult > 0 then
                traveldirec = down_dir
                hasturned = true
                print("turn downwards")
            else
                --destination = next_tile
                
            end
            if spell:get_tile(traveldirec, 1):is_edge() and hasturned == true then
                traveldirec = fowards_dir
            end
            destination = spell:get_tile(traveldirec, 1)
            --print("make another")
            if destination:is_walkable() then
                print("new shockwave on",  currentframe)
                create_shockwave(user, props, spell:get_facing(), hasturned, destination, traveldirec)
                --myfield:spawn(nextone, destination)
            else
                print("no further sorry")

            end
        end)
        spell.update_func = function()
            if not spell:get_current_tile():is_walkable() then
                spell:delete()
            end
            spell:get_current_tile():attack_entities(spell)
            spell:get_current_tile():highlight(Highlight.Solid)
            currentframe = currentframe + 1
            
            --print("currentframe is", currentframe)
            --[[if spell:get_current_tile() ~= nil then
                print("we good")
            else
                print("we bad")
            end]]
        end
        spell.attack_func = function()
            Engine.play_audio(hit_audio, AudioPriority.Highest)
        end
        animation:on_complete(function()
            spell:delete()
        end)
        --return spell
        user:get_field():spawn(spell, spawntile)

    --end

end