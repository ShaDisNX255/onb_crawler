local triplearrow = include("triplearrow/triplearrow.lua")

local DAMAGE = 50

triplearrow.shots_count = 3
triplearrow.needle_type = "1"
triplearrow.buster_speed_anim = "1_2"
triplearrow.buster_speed_frame = 0.118

triplearrow.codes = {"F","G","H","I","J"}
triplearrow.shortname = "TriSpear"
triplearrow.damage = DAMAGE
triplearrow.time_freeze = false
triplearrow.element = Element.None
triplearrow.description = "Fires a 3-spear burst"
triplearrow.long_description = "Fires a 3-shot spear"
triplearrow.can_boost = true
triplearrow.card_class = CardClass.Standard
triplearrow.limit = 5

function package_init(package) 
    package:declare_package_id("com.k1rbyat1na.card.EXE1-037-TripleSpear")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(triplearrow.codes)

    local props = package:get_card_props()
    props.shortname = triplearrow.shortname
    props.damage = triplearrow.damage
    props.time_freeze = triplearrow.time_freeze
    props.element = triplearrow.element
    props.description = triplearrow.description
    props.long_description = triplearrow.long_description
    props.can_boost = triplearrow.can_boost
	props.card_class = triplearrow.card_class
	props.limit = triplearrow.limit
end

card_create_action = triplearrow.card_create_action