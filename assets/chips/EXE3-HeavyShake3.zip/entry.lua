local heavyshake = include("heavyshake/heavyshake.lua")

local DAMAGE = 140

heavyshake.rank = 2
heavyshake.name = "HvyAreid"

heavyshake.codes = {"D","M","R","T","Z"}
heavyshake.shortname = "HvyShak3"
heavyshake.damage = DAMAGE
heavyshake.time_freeze = false
heavyshake.element = Element.None
heavyshake.description = "Shakes\nup&down\n3sq ahead"
heavyshake.long_description = "Throw an iron dumbbell 3 ahead. Attacks by shaking up&down"
heavyshake.can_boost = true
heavyshake.card_class = CardClass.Standard
heavyshake.limit = 4
heavyshake.mb = 50

function package_init(package) 
    package:declare_package_id("com.OFC.card.EXE3-083-HeavyShake3")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(heavyshake.codes)

    local props = package:get_card_props()
    props.shortname = heavyshake.shortname
    props.damage = heavyshake.damage
    props.time_freeze = heavyshake.time_freeze
    props.element = heavyshake.element
    props.description = heavyshake.description
    props.long_description = heavyshake.long_description
    props.can_boost = heavyshake.can_boost
	props.card_class = heavyshake.card_class
	props.limit = heavyshake.limit
end

card_create_action = heavyshake.card_create_action