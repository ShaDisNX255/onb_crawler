local print_debug = false

local HEAVYAREI_TEXTURE = Engine.load_texture(_folderpath.."gfx/battle.grayscaled.png")
local HEAVYAREI_ANIMPATH = _folderpath.."gfx/battle.animation"
local SHADOW_TEXTURE = Engine.load_texture(_folderpath.."gfx/battle_shadow.png")

local SPARKLE_TEXTURE = Engine.load_texture(_folderpath.."gfx/sparkle.grayscaled.png")
local SPARKLE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/sparkle.png")
local SPARKLE_ANIMPATH = _folderpath.."gfx/sparkle.animation"

local MOB_MOVE_TEXTURE = Engine.load_texture(_folderpath.."gfx/mob_move.grayscaled.png")
local MOB_MOVE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/mob_move.png")
local MOB_MOVE_ANIMPATH = _folderpath.."gfx/mob_move.animation"

local EFFECT8_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect8.grayscaled.png")
local EFFECT8_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect8.png")
local EFFECT8_ANIMPATH = _folderpath.."gfx/effect8.animation"

local SMOKE_TEXTURE = Engine.load_texture(_folderpath.."gfx/smoke.grayscaled.png")
local SMOKE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/smoke.png")
local SMOKE_ANIMPATH = _folderpath.."gfx/smoke.animation"

local GUARD_TEXTURE = Engine.load_texture(_folderpath.."gfx/guard.grayscaled.png")
local GUARD_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/guard.png")
local GUARD_ANIMPATH = _folderpath.."gfx/guard.animation"

local THROW_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE3_190.ogg", true)
local GUARD_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE3_14.ogg", true)

local ObstacleInfo = include("libs/ObstacleInfo.lua")
local WindPush = include("libs/WindPush.lua")

local function debug_print(text)
    if print_debug then
        print("[HeavyShake] "..text)
    end
end

local heavyshake = {}

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function create_heavyshake(user, props, facing, field, team, tile)
    -- Obs. controller
	local obs_control = nil
    local function create_controller(orig_obs, tile)
		local controller = Battle.Artifact.new()
	    controller:set_name("OSControl_"..orig_obs:get_id())
        controller.update_func = function(self)
            if not orig_obs or orig_obs:is_deleted() then
                self:delete()
                return
            end
            local new_offset = self:get_offset()
            local new_elevation = self:get_elevation()
            if self:get_tile() ~= orig_obs:get_tile() then
                self:teleport(orig_obs:get_tile(), ActionOrder.Immediate)
            end
            orig_obs:set_offset(new_offset.x, new_offset.y)
            orig_obs:set_elevation(new_elevation)
        end
        controller.can_move_to_func = function(self)
            return true
        end
	    controller.battle_end_func = function(self)
	    	self:delete()
	    end
        field:spawn(controller, tile)
        return controller
    end
    ----
    local round = function(val)
        if facing == Direction.Right then
            return math.floor(val)
        else
            return math.ceil(val)
        end
    end
    local function deleting(self, facing, field, tile)
        local move_fx = graphic_init("artifact", self:get_offset().x, self:get_offset().y, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, -99, "0", Playback.Once, self, facing, true, true, true)
        move_fx:set_elevation(20*2)
        field:spawn(move_fx, tile)
        self:delete()
    end
    local function create_hitbox(user, hit_props, facing, field, team, tile)
        local spell = Battle.Spell.new(team)
        spell:set_facing(facing)
        spell:set_hit_props(hit_props)
        spell.update_func = function(self)
            self:get_tile():attack_entities(self)
            if not user or user:is_deleted() then self:delete() return end
            if self:get_tile() ~= user:get_tile() then
                self:teleport(user:get_tile(), ActionOrder.Immediate)
            end
        end
        spell.attack_func = function(self, other, judge)
            if not judge:hint_spawn_gfx() then return end
            local offset_y = math.random(-6,5)
            local offset_x = math.random(-7,6)
            if facing == Direction.Left then offset_x = -offset_x end
            local hit_fx = graphic_init("artifact", self:get_tile_offset().x+self:get_offset().x+(offset_x*2), self:get_tile_offset().y+self:get_offset().y+(offset_y*2), EFFECT8_TEXTURE, EFFECT8_PALETTE, EFFECT8_ANIMPATH, -999, "0", Playback.Once, user, facing, true, false, true)
            field:spawn(hit_fx,other:get_tile())
        end
        spell.battle_end_func = function(self)
            self:delete()
        end
        spell.can_move_to_func = function(tile)
            return true
        end
        spell.delete_func = function(self)
            self:erase()
        end
        field:spawn(spell, tile)
        return spell
    end
    local tileWidthO = tile:width() -- 80
    local tileHeightO = tile:height()
    local tileWidth = tileWidthO/2 -- 40
    local tileHeight = tileHeightO/2 - tileHeightO/10
    local palette = Engine.load_texture(_folderpath.."gfx/palette/battle-"..heavyshake.rank..".png")
    local shake = graphic_init("spell", 0, 0, HEAVYAREI_TEXTURE, palette, HEAVYAREI_ANIMPATH, -3, "PLAYER_IDLE", Playback.Loop, user, facing)
    shake.anim = shake:get_animation()
	ObstacleInfo.set_cannot_be_targeted(shake, false)
	ObstacleInfo.set_cannot_be_manipulated(shake, false)
	ObstacleInfo.add_to_limit_1(shake, team, field)
	ObstacleInfo.set_obstacle_damage(shake, props.element, props.damage)
    local hit_props_c = HitProps.new()
    :dmg(props.damage)
    :impact()
    :flinch()
    :flash()
    :breaking()
    :no_counter()
    :elem(props.element)
    :from(user:get_context())
    --shake:set_hit_props(hit_props)
    shake:set_name(heavyshake.name)
    shake:set_health(9999) -- ??? I really don't know if it's actually defeatable. Even three Killer's Eye SPs can't destroy it.
    shake:set_float_shoe(true)
    shake:set_air_shoe(true)
    shake:share_tile(false)
    shake:toggle_hitbox(true)
    -- Other props
    shake.collision_available = true
    -- Defense Rule
    local box_defense = Battle.DefenseRule.new(1, DefenseOrder.Always)
    box_defense.filter_statuses_func = function(a_props)
        a_props.damage = 0
        a_props.flags = a_props.flags & (~Hit.Stun)
        a_props.flags = a_props.flags & (~Hit.Drag)
        a_props.flags = a_props.flags & (~Hit.Root)
        a_props.flags = a_props.flags & (~Hit.Shake)
        a_props.flags = a_props.flags & (~Hit.Blind)
        a_props.flags = a_props.flags & (~Hit.Flash)
        a_props.flags = a_props.flags & (~Hit.Freeze)
        a_props.flags = a_props.flags & (~Hit.Bubble)
        a_props.flags = a_props.flags & (~Hit.Confuse)
        return a_props
    end
    box_defense.can_block_func = function(judge, attacker, defender)
        --judge:block_damage()
        local a_props = attacker:get_hit_props()
        if not a_props:has_flags(Hit.Breaking) then
            judge:block_damage()
            Engine.play_audio(GUARD_AUDIO, AudioPriority.Immediate)
            local offset_y = math.random(-6,5)
            local offset_x = math.random(-7,6)
            if facing == Direction.Left then offset_x = -offset_x end
            local hit_fx = graphic_init("artifact", shake:get_tile_offset().x+shake:get_tile().x+(offset_x*2), shake:get_tile_offset().y+shake:get_tile().y+(offset_y*2), GUARD_TEXTURE, GUARD_PALETTE, GUARD_ANIMPATH, -999, "0", Playback.Once, user, facing, true, false, true)
            field:spawn(hit_fx,shake:get_tile())
        end
        if attacker:get_id() == shake:get_id() or attacker:get_name() == tostring(shake:get_id()) then
            judge:block_collision()
        end
    end
    shake:add_defense_rule(box_defense)
    --
    shake.move_state = "MOVING"
    shake.move_index = 1
    shake.y_speed = 0
    shake.state = "IDLE"
    shake.frames = 1
    shake.tile_traveled = 1
    shake.dir_m = 1
    shake.dir = Direction.Down
    if tile:y() >= field:height() then
        shake.dir_m = -shake.dir_m
        shake.dir = Direction.reverse(shake.dir)
    end
    local offsets_y = {}
    offsets_y.rank0 = { -- 11
        [1]  = {move=0, stop=2},
        [2]  = {move=0, stop=2},
        [3]  = {move=1, stop=2},
        [4]  = {move=1, stop=2},
        [5]  = {move=1, stop=1},
        [6]  = {move=1, stop=1},
        [7]  = {move=1, stop=1},
        [8]  = {move=2, stop=1},
        [9]  = {move=2, stop=0},
        [10] = {move=2, stop=0},
        [11] = {move=2, stop=0},
        [12] = {move=2, stop=0},
    }
    offsets_y.rank1 = {
        [1]  = {move=0, stop=3},
        [2]  = {move=0, stop=2},
        [3]  = {move=1, stop=2},
        [4]  = {move=1, stop=2},
        [5]  = {move=2, stop=2},
        [5]  = {move=2, stop=1},
        [6]  = {move=2, stop=1},
        [7]  = {move=2, stop=0},
        [8]  = {move=3, stop=0},
        [9]  = {move=3, stop=0},
        [10] = {move=3, stop=0},
        [11] = {move=3, stop=0},
        [12] = {move=3, stop=0},
    }
    offsets_y.rank2 = { -- 8
        [1]  = {move=0, stop=3},
        [2]  = {move=1, stop=3},
        [3]  = {move=1, stop=3},
        [4]  = {move=2, stop=2},
        [5]  = {move=2, stop=2},
        [6]  = {move=3, stop=1},
        [7]  = {move=3, stop=1},
        [7]  = {move=4, stop=0},
        [8]  = {move=4, stop=0},
        [9]  = {move=4, stop=0},
        [10] = {move=4, stop=0},
        [11] = {move=4, stop=0},
        [12] = {move=4, stop=0},
    }
    shake.offset_x = shake:get_offset().x
    shake.offset_y = shake:get_offset().y
    shake.on_spawn_func = function(self)
        WindPush.make_entity_immune_to_status(self)
        obs_control = create_controller(self, field:tile_at(0,0))
        create_hitbox(shake, hit_props_c, facing, field, shake:get_team(), tile)
        self:set_shadow(SHADOW_TEXTURE)
        self:show_shadow(true)
    end
    shake.update_func = function(self)
        --check_collision(self, hit_props_c)
        if self.state == "IDLE" then
            if self.frames == 6 then
                self.anim:set_state("ATTACK")
                self.anim:refresh(self:sprite())
            end
            if self.frames >= 7 then
                self.state = "ATTACK"
                self.frames = 1
                return
            end
        elseif self.state == "ATTACK" then
            --print("self.y_speed",self.y_speed)
            if self.move_state == "MOVING" then
                self.y_speed = offsets_y["rank"..heavyshake.rank][self.move_index].move
                if self:get_tile(self.dir,1):is_edge() then
                    self.move_index = 0
                    self.move_state = "STOPPING"
                    --return
                end
            elseif self.move_state == "STOPPING" then
                self.y_speed = offsets_y["rank"..heavyshake.rank][self.move_index].stop
                if (self.dir == Direction.Down and self.offset_y > 0) or (self.dir == Direction.Up and self.offset_y < 0) then
                    --self.offset_y = 0
                end
                if self.move_index >= 11-heavyshake.rank then
                    self.move_index = 0
                    self.move_state = "MOVING"
                    self.dir_m = -self.dir_m
                    self.dir = Direction.reverse(self.dir)
                    --return
                end
            end
            self.offset_y = self.offset_y+(self.y_speed*self.dir_m)
            --[[
            if self.frames == 1 then
                self.anim:set_state("ATTACK")
                self.anim:refresh(self:sprite())
            end]]
            if self.dir == Direction.Down and math.floor(self.offset_y) > tileHeight/2 then
                if self.tile_traveled < 8 then
                    self.tile_traveled = self.tile_traveled + 1
                    self:teleport(self:get_tile(Direction.Down,1), ActionOrder.Voluntary)
                    --print("tile Height:",tileHeight)
                    --print("offset Y OLD:",self.offset_y)
                    self.offset_y = self.offset_y-tileHeight
                    --print("offset Y NEW:",self.offset_y)
                else
                    deleting(self, facing, field, tile)
                end
            elseif self.dir == Direction.Up and math.floor(self.offset_y) < -tileHeight/2 then
                if self.tile_traveled < 8 then
                    self.tile_traveled = self.tile_traveled + 1
                    self:teleport(self:get_tile(Direction.Up,1), ActionOrder.Voluntary)
                    --print("tile Height:",tileHeight)
                    --print("offset Y OLD:",self.offset_y)
                    self.offset_y = self.offset_y+tileHeight
                    --print("offset Y NEW:",self.offset_y)
                else
                    deleting(self, facing, field, tile)
                end
            end
            if self.move_index < #offsets_y["rank"..heavyshake.rank] then
                self.move_index = self.move_index + 1
            end
            self:set_offset(self.offset_x*2,self.offset_y*2)
            self:get_tile():highlight(Highlight.Solid)
            --print("offset:",self:get_offset().x,self:get_offset().y)
        end
        self.frames = self.frames + 1
    end
    shake.can_move_to_func = function(tile)
        return true
    end
    if check_obstacles(tile) or check_characters_true(tile) then
        create_hitbox(shake, hit_props_c, facing, field, shake:get_team(), tile)
        local move_fx = graphic_init("artifact", 0, 0, SMOKE_TEXTURE, SMOKE_PALETTE, SMOKE_ANIMPATH, -99, "0", Playback.Once, shake, facing, true, true, true)
        field:spawn(move_fx, tile)
    else
        field:spawn(shake, tile)
        local move_fx = graphic_init("artifact", 0, 0, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, -99, "1", Playback.Once, shake, facing, true, true, true)
        move_fx:set_elevation(20*2)
        field:spawn(move_fx, tile)
    end
    return shake
end

local function create_sparkle(user, props, facing, field, team, tile, tile2)
    -- 113 / 40 = 2.825
    local round = function(val)
        if facing == Direction.Right then
            return math.floor(val)
        else
            return math.ceil(val)
        end
    end
    local tileWidthO = tile:width() -- 80
    local tileWidth = tileWidthO/2 -- 40
    local offset_x = math.floor(tileWidth/14.155*1000)*0.001
    if facing == Direction.Left then offset_x = -offset_x end
    local star = graphic_init("spell", tileWidth/10*2, 0, SPARKLE_TEXTURE, SPARKLE_PALETTE, SPARKLE_ANIMPATH, -3, "0", Playback.Loop, user, facing)
    star:set_elevation(48*2)
    local elevations = {
        [2] = 1,
        [3] = 2,
        [5] = 1,
        [11] = 0,
        [13] = 1,
        [14] = 0,
        [15] = -1,
        [16] = 0,
        [18] = -1,
        [24] = -2,
        [30] = -3,
        [31] = -2,
        [32] = -3,
        [35] = -4,
        [36] = -3,
        [37] = -4,
        [38] = -3,
        [39] = -4,
    }
    star.offset_x = star:get_offset().x
    star.offset_y = star:get_offset().y
    star.elevation = 0
    star.frames = 1
    star.update_func = function(self)
        if self.frames ~= 1 then
            if elevations[self.frames] ~= nil then
                self.elevation = elevations[self.frames]*2
            end
            self:set_elevation(self:get_elevation()+self.elevation)
            self.offset_x = self.offset_x+offset_x
            if facing == Direction.Right and round(self.offset_x) > tileWidth/2 then
                self:teleport(self:get_tile(Direction.Right, 1), ActionOrder.Immediate)
                self.offset_x = self.offset_x-tileWidth
            elseif facing == Direction.Left and round(self.offset_x) < -tileWidth/2 then
                self:teleport(self:get_tile(Direction.Left, 1), ActionOrder.Immediate)
                self.offset_x = self.offset_x+tileWidth
            end
            self:set_offset(round(self.offset_x*2),round(self.offset_y*2))
        end
        if self.frames >= 41 then
            create_heavyshake(user, props, facing, field, team, tile2)
            self:delete()
        end
        self.frames = self.frames + 1
    end
    star.can_move_to_func = function(tile)
        return true
    end
    star.battle_end_func = function(self)
        self:delete()
    end
    star.delete_func = function(self)
        self:erase()
    end
    field:spawn(star, tile)
    return star
end

heavyshake.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
	local action = Battle.CardAction.new(user, "PLAYER_THROW")
	local action_frame = 3
	--for alt THROW anims
	if user:get_animation():has_state("PLAYER_THROW52") then
		action = Battle.CardAction.new(user, "PLAYER_THROW52")
		action_frame = 4
	end
	--
	action:set_lockout(make_animation_lockout())
	action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
		local facing = user:get_facing()
		local field = user:get_field()
		local team = user:get_team()
        Engine.play_audio(THROW_AUDIO, AudioPriority.Immediate)
        self:add_anim_action(action_frame, function()
            create_sparkle(user, props, facing, field, team, user:get_tile(), user:get_tile(facing,3))
		end)
    end
	action.action_end_func = function(self)
	end
    return action
end

-- Checks for non-zero-health Obstacles.
function check_obstacles(tile)
    local ob = tile:find_obstacles(function(o)
        if o:get_animation():has_state("PASS_THROUGH") or o:get_name() == "CANTINTERACT" then
            return false
        else
            return true
        end
        return o:get_health() > 0
    end)
    return #ob > 0 
end

-- Checks for unfriendly Characters.
function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)
    return #characters > 0
end

-- Checks for any Characters.
function check_characters_true(tile)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0
    end)
    return #characters > 0
end

function check_characters_true_team(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_tile():get_team() == self:get_tile():get_team()
    end)
    return #characters > 0
end

return heavyshake