local plasmaball = include("plasmaball/plasmaball.lua")

local DAMAGE = 30

plasmaball.ver = 0
plasmaball.name = "Paraball"
plasmaball.health = 10 -- 10, 30, 50
plasmaball.atk_times = 12 -- 12, 15, 22
plasmaball.atk_interval = 15 -- 15, 12, 8

plasmaball.codes = {"B","D","J","R","T"}
plasmaball.shortname = "PlsmBal1"
plasmaball.damage = DAMAGE
plasmaball.time_freeze = false
plasmaball.element = Element.Elec
plasmaball.description = "Paraball\ndoes elec\nattk arnd"
plasmaball.long_description = "Place a Paraball that generates electricity in front of you"
plasmaball.can_boost = true
plasmaball.card_class = CardClass.Standard
plasmaball.limit = 4
plasmaball.mb = 14

function package_init(package) 
    package:declare_package_id("com.OFC.card.EXE3-106-PlasmaBall1")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(plasmaball.codes)

    local props = package:get_card_props()
    props.shortname = plasmaball.shortname
    props.damage = plasmaball.damage
    props.time_freeze = plasmaball.time_freeze
    props.element = plasmaball.element
    props.description = plasmaball.description
    props.long_description = plasmaball.long_description
    props.can_boost = plasmaball.can_boost
	props.card_class = plasmaball.card_class
	props.limit = plasmaball.limit
end

card_create_action = plasmaball.card_create_action