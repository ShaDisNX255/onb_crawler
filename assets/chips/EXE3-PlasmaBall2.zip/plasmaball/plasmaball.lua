local print_debug = false

local PARABALL_TEXTURE = Engine.load_texture(_folderpath.."gfx/paraball.grayscaled.png")
local PARABALL_ANIMPATH = _folderpath.."gfx/paraball.animation"

local PLASMABALL_TEXTURE = Engine.load_texture(_folderpath.."gfx/plasmaball.grayscaled.png")
local PLASMABALL_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/plasmaball.png")
local PLASMABALL_ANIMPATH = _folderpath.."gfx/plasmaball.animation"

local MOB_MOVE_TEXTURE = Engine.load_texture(_folderpath.."gfx/mob_move.grayscaled.png")
local MOB_MOVE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/mob_move.png")
local MOB_MOVE_ANIMPATH = _folderpath.."gfx/mob_move.animation"
local BOOM_TEXTURE = Engine.load_texture(_folderpath.."gfx/boom.grayscaled.png")
local BOOM_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/boom.png")
local BOOM_ANIMPATH = _folderpath.."gfx/boom.animation"

local SPAWN_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE3_173.ogg", true)
local PLASMABALL_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE3_198.ogg", true)
local BOOM_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE3_229.ogg", true)

local ObstacleInfo = include("libs/ObstacleInfo.lua")

local function debug_print(text)
    if print_debug then
        print("[PlasmaBall] "..text)
    end
end

local plasmaball = {}

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function create_plasmaball(ref, hit_props, facing, field, tile)
    if not tile then return end
    local plasma = graphic_init("spell", 0, 0, PLASMABALL_TEXTURE, PLASMABALL_PALETTE, PLASMABALL_ANIMPATH, -3, "1", Playback.Once, ref, facing, true, true, true)
    plasma:set_hit_props(hit_props)
    plasma.on_spawn_func = function()
        Engine.play_audio(PLASMABALL_AUDIO, AudioPriority.Immediate)
    end
    plasma.update_func = function(self)
        tile:highlight(Highlight.Solid)
        tile:attack_entities(self)
    end
    plasma.battle_end_func = function(self)
        self:delete()
    end
    plasma.delete_func = function(self)
        self:erase()
    end
    field:spawn(plasma,tile)
    return plasma
end

local function create_paraball(user, props, facing_away, facing, field, team, spawn_tile)
	Engine.play_audio(SPAWN_AUDIO, AudioPriority.Immediate)
    local palette = Engine.load_texture(_folderpath.."gfx/palette/paraball-"..plasmaball.ver..".png")
    local move_fx = graphic_init("artifact", 0, 0, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, -999, "5", Playback.Once, user, facing, true, true, true)
    move_fx:set_elevation(30*2)
    field:spawn(move_fx, spawn_tile)
    local tile = spawn_tile
	local chars = {}
	local obs = {}
	field:find_entities(function(e)
	  	local id = e:get_id()
	  	if Battle.Obstacle.from(e) then 
	  	  	table.insert(obs, id)
	  	elseif Battle.Character.from(e) then 
	  	  	table.insert(chars, id)
	  	end
	end)
	local ignore_list = obs
	-- https://paintylux.github.io/OpenNetBattleDocs/api/#tile-is_reserved
	local not_reserved_by_ob = tile:is_reserved(obs)
	--print(tile:is_walkable())
	--print(tile:is_reserved(chars))
	--print(tile:is_reserved(obs))
	--print(#tile:find_entities(query))
	if not tile:is_hole() and not check_obstacles(tile) and not check_characters_true(tile) and ((tile:is_reserved(chars) and tile:is_reserved(obs)) or (tile:is_reserved(chars) and not tile:is_reserved(obs)) or (not tile:is_reserved(chars) and not tile:is_reserved(obs))) then
	else
        local fake_fx = graphic_init("spell", 0, 0, PARABALL_TEXTURE, palette, PARABALL_ANIMPATH, -3, "2", Playback.Loop, user, facing, true)
        field:spawn(fake_fx, spawn_tile)
		return
    end
    --if not spawn_tile or spawn_tile:is_hole() or check_obstacles(spawn_tile) or check_characters_true(spawn_tile) then return end
    -- Destroyed Obstacle
	local function create_destroyedobstacle(self)
	    local field = self:get_field()
	    local objs = field:find_entities(function(e)
	        return e:get_name() == "DestroyedObstacle"
	    end)
	    if #objs >= 3 then return end
	    local dobj = Battle.Artifact.new()
	    dobj:set_name("DestroyedObstacle")
	    dobj.battle_end_func = function()
	    	dobj:delete()
	    end
	    field:spawn(dobj, self:get_tile())
	    return dobj
	end
    -- Obs. controller
	local obs_control = nil
    local function create_controller(orig_obs, tile)
		local controller = Battle.Artifact.new()
	    controller:set_name("OSControl_"..orig_obs:get_id())
        controller.update_func = function(self)
            if not orig_obs or orig_obs:is_deleted() then
                self:delete()
                return
            end
            local new_offset = self:get_offset()
            local new_elevation = self:get_elevation()
            if self:get_tile() ~= orig_obs:get_tile() then
                self:teleport(orig_obs:get_tile(), ActionOrder.Immediate)
            end
            orig_obs:set_offset(new_offset.x, new_offset.y)
            orig_obs:set_elevation(new_elevation)
        end
        controller.can_move_to_func = function(self)
            return true
        end
	    controller.battle_end_func = function(self)
	    	self:delete()
	    end
        field:spawn(controller, tile)
        return controller
    end
    ----
    local ball = graphic_init("obstacle", 0, 0, PARABALL_TEXTURE, palette, PARABALL_ANIMPATH, -3, "1", Playback.Loop, user, facing)
    ball.anim = ball:get_animation()
	ObstacleInfo.set_cannot_be_targeted(ball, true)
	ObstacleInfo.set_cannot_be_manipulated(ball, false)
	ObstacleInfo.add_to_limit_1(ball, team, field)
	ObstacleInfo.set_obstacle_damage(ball, props.element, props.damage)
    local hit_props_c = HitProps.new()
    :dmg(props.damage)
    :impact()
    :flinch()
    :flash()
    :no_counter()
    :elem(props.element)
    :from(user:get_context())
    --ball:set_hit_props(hit_props)
    ball:set_name(plasmaball.name)
    ball:set_health(plasmaball.health)
    ball:set_float_shoe(false)
    ball:set_air_shoe(false)
    ball:share_tile(false)
    ball:toggle_hitbox(true)
    -- Other props
    ball.collision_available = true
    ball.tile_y = spawn_tile:y()
    local hit_props_a = HitProps.new()
    :dmg(props.damage)
    :impact()
    :flinch()
    :no_counter()
    :elem(props.element)
    :from(user:get_context())
    ball.state = "IDLE"
    ball.frames = 1
    -- Defense Rule
    local box_defense = Battle.DefenseRule.new(1, DefenseOrder.Always)
    box_defense.filter_statuses_func = function(a_props)
        a_props.flags = a_props.flags & (~Hit.Flash)
        --a_props.flags = a_props.flags & (~Hit.Drag)
        return a_props
    end
    box_defense.can_block_func = function(judge, attacker, defender)
        if attacker:get_id() == ball:get_id() or attacker:get_name() == tostring(ball:get_id()) then
            judge:block_collision()
        end
    end
    ball:add_defense_rule(box_defense)
    ball.on_spawn_func = function(self)
        obs_control = create_controller(self, field:tile_at(0,0))
	    Engine.play_audio(SPAWN_AUDIO, AudioPriority.Immediate)
    end
    ball.dirs = {
        [1] = Direction.Up,
        [2] = Direction.join(facing_away,Direction.Up),
        [3] = facing_away,
        [4] = Direction.join(facing_away,Direction.Down),
        [5] = Direction.Down,
        [6] = Direction.join(facing,Direction.Down),
        [7] = facing,
        [8] = Direction.join(facing,Direction.Up),
    }
    ball.dir_index = {
        1,5
    }
    ball.plasmas = {
        [1] = nil,
        [2] = nil,
    }
    ball.update_func = function(self)
        check_collision(self, hit_props_c)
        if self.state == "IDLE" then
            for i=1,plasmaball.atk_times do
                if self.frames == 42+plasmaball.atk_interval*(i-1) then
                    for j=1,2 do
                        self.plasmas[j] = create_plasmaball(self, hit_props_a, self:get_facing(), self:get_field(), self:get_tile(self.dirs[self.dir_index[j]],1))
                        self.dir_index[j] = self.dir_index[j] + 1
                        if self.dir_index[j]>#self.dirs then self.dir_index[j] = 1 end
                    end
                end
            end
            if self.frames == 42+plasmaball.atk_interval*(plasmaball.atk_times-1) then
                local move_fx = graphic_init("artifact", 0, 0, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, -999, "5", Playback.Once, user, facing, true, true, true)
                move_fx:set_elevation(30*2)
                field:spawn(move_fx, spawn_tile)
            end
            if self.frames >= 42+plasmaball.atk_interval*(plasmaball.atk_times-1)+1 then
                self:delete()
            end
            self.frames = self.frames + 1
        end
    end
    ball.can_move_to_func = function(tile)
        if not tile:is_walkable() then
            return false
        end
        return true
    end
    ball.battle_end_func = function(self)
        self:set_health(0)
    end
    ball.delete_func = function(self)
        if self:get_health() <= 0 then
            create_destroyedobstacle(self)
	        Engine.play_audio(BOOM_AUDIO, AudioPriority.Immediate)
            local boom_fx = graphic_init("artifact", self:get_tile_offset().x+self:get_offset().x, self:get_tile_offset().y+self:get_offset().y, BOOM_TEXTURE, BOOM_PALETTE, BOOM_ANIMPATH, -999, "0", Playback.Once, self, self:get_facing(), true, false, true)
            field:spawn(boom_fx, self:get_tile())
            if self.plasmas[1] then self.plasmas[1]:delete() end
            if self.plasmas[2] then self.plasmas[2]:delete() end
        end
        self:erase()
    end
    field:spawn(ball, spawn_tile)
    return ball
end

plasmaball.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
	action:set_lockout(make_animation_lockout())
    local frame1 = {1,0.0} --(+)1 frame
    local frame2 = {1,0.267} --(-)1 frame
    local frame_sequence = make_frame_data({frame1, frame2})
    action:override_animation_frames(frame_sequence)
    action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        local facing_away = user:get_facing_away()
        local facing = user:get_facing()
        local field = user:get_field()
        local team = user:get_team()
        --
        local buster = self:add_attachment("BUSTER")
        local buster_sprite = buster:sprite()
        buster_sprite:set_texture(user:get_texture(), true)
        buster_sprite:set_layer(-1)
        buster_sprite:enable_parent_shader(true)
        local buster_anim = buster:get_animation()
        buster_anim:copy_from(user:get_animation())
        buster_anim:set_state("BUSTER")
        buster_anim:refresh(buster_sprite)
		self:add_anim_action(2, function()
            create_paraball(user, props, facing_away, facing, field, team, user:get_tile(facing,1))
		end)
	end
	action.action_end_func = function(self)
        debug_print("in custom card action action_end_func()!")
	end
    return action
end

--(Function by Alrysc)
-- TODO: When we get is_passthrough or something, check to see if target became flashing before 
    -- we are allowed to spawn another one. Don't want to instakill viruses
-- self.collision_available can do something related to that. Does nothing now
function check_collision(self, hit_props)
    local t = self:get_tile()
    if self.collision_available and check_characters(t, self) then 
        create_collision_attack(self, hit_props, t)
    end
end

--(Function by Alrysc, edited by K1rbYat1Na)
function create_collision_attack(user, hit_props, tile)
    local spell = Battle.Spell.new(Team.Other)
    spell:set_facing(user:get_facing())
    spell:set_hit_props(hit_props)
    spell:set_name(tostring(user:get_id()))
    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end
    spell.battle_end_func = function(self)
        self:delete()
    end
    spell.collision_func = function(self, other)
        if other:get_id() ~= user:get_id() and not other:get_animation():has_state("PASS_THROUGH") and other:get_name() ~= "CANTINTERACT" then
            user:set_health(0)
        end
    end
    spell.delete_func = function(self)
        self:erase()
    end
    user:get_field():spawn(spell, tile)
end

-- Checks for non-zero-health Obstacles.
function check_obstacles(tile)
    local ob = tile:find_obstacles(function(o)
        if o:get_animation():has_state("PASS_THROUGH") or o:get_name() == "CANTINTERACT" then
            return false
        else
            return true
        end
        return o:get_health() > 0
    end)
    return #ob > 0 
end

-- Checks for unfriendly Characters.
function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)
    return #characters > 0
end

-- Checks for any Characters.
function check_characters_true(tile)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0
    end)
    return #characters > 0
end

function check_characters_true_team(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_tile():get_team() == self:get_tile():get_team()
    end)
    return #characters > 0
end

return plasmaball