local print_debug = false

local BURNERMAN_TEXTURE = Engine.load_texture(_folderpath.."gfx/burnerman.grayscaled.png")
local BURNERMAN_ANIMPATH = _folderpath.."gfx/burnerman.animation"
local HEATCHASER_U_TEXTURE = Engine.load_texture(_folderpath.."gfx/heatchaser_u.grayscaled.png")
local HEATCHASER_U_ANIMPATH = _folderpath.."gfx/heatchaser_u.animation"
local HEATCHASER_D_TEXTURE = Engine.load_texture(_folderpath.."gfx/heatchaser_d.grayscaled.png")
local HEATCHASER_D_ANIMPATH = _folderpath.."gfx/heatchaser_d.animation"
local STRIKEBURNER_TEXTURE = Engine.load_texture(_folderpath.."gfx/strikeburner.grayscaled.png")
local STRIKEBURNER_ANIMPATH = _folderpath.."gfx/strikeburner.animation"
local MOB_MOVE_TEXTURE = Engine.load_texture(_folderpath.."gfx/mob_move.grayscaled.png")
local MOB_MOVE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/mob_move.png")
local MOB_MOVE_ANIMPATH = _folderpath.."gfx/mob_move.animation"
local EFFECT0_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect0.grayscaled.png")
local EFFECT0_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect0.png")
local EFFECT0_ANIMPATH = _folderpath.."gfx/effect0.animation"
local EFFECT2_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect2.grayscaled.png")
local EFFECT2_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect2.png")
local EFFECT2_ANIMPATH = _folderpath.."gfx/effect2.animation"
local BOOM_TEXTURE = Engine.load_texture(_folderpath.."gfx/boom.grayscaled.png")
local BOOM_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/boom.png")
local BOOM_ANIMPATH = _folderpath.."gfx/boom.animation"

local SPAWN_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_57.ogg", true)
local SPAWN2_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_109.ogg", true)
local HEATCHASER_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_220.ogg", true)
local STRIKEBURNER_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_303.ogg", true)
local BOOM_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_273.ogg", true)

local function debug_print(text)
    if print_debug then
        print("[BurnerMan] "..text)
    end
end

local burnerman = {}

--(Function by Alrysc)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function create_strike_burner_hitbox(user, facing, field, team, hit_props)
    --if not tile or tile:is_edge() then return end
    local hitbox = Battle.Spell.new(team)
    hitbox:set_facing(facing)
    hitbox:set_hit_props(hit_props)
    hitbox.update_func = function(self)
        self:highlight_tile(Highlight.Solid)
        self:get_tile():attack_entities(self)
    end
    hitbox.attack_func = function(self, other, judge)
        if not judge:hint_spawn_gfx() then return end
        local offset_y = math.random(-30,-15)
        local offset_x = math.random(-8,7)
        local hit_fx = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT2_TEXTURE, EFFECT2_PALETTE, EFFECT2_ANIMPATH, -999, "0", Playback.Once, self, self:get_facing(), true, true, true)
        self:get_field():spawn(hit_fx, self:get_tile())
    end
    hitbox.battle_end_func = function(self)
        self:delete()
    end
    hitbox.delete_func = function(self)
        self:erase()
    end
    --field:spawn(hitbox, tile)
    return hitbox
end

local function create_strike_burner(user, navi, facing, field, team, hit_props, tile)
    if not tile or tile:is_edge() then return end
    local field = user:get_field()
    local burner = graphic_init("spell", 0, 0, STRIKEBURNER_TEXTURE, navi:get_base_palette(), STRIKEBURNER_ANIMPATH, -3, "0", Playback.Loop, user, user:get_facing())
    burner.hitbox = {
        [1] = create_strike_burner_hitbox(user, facing, field, team, hit_props),
        [2] = create_strike_burner_hitbox(user, facing, field, team, hit_props),
        [3] = create_strike_burner_hitbox(user, facing, field, team, hit_props)
    }
    burner.frames = 0
    burner.on_spawn_func = function()
        Engine.play_audio(STRIKEBURNER_AUDIO, AudioPriority.Immediate)
    end
    burner.update_func = function(self)
        self.frames = self.frames + 1
        if self.frames%16==0 then Engine.play_audio(STRIKEBURNER_AUDIO, AudioPriority.Immediate) end
    end
    burner.battle_end_func = function(self)
        self:delete()
    end
    burner.delete_func = function(self)
        self:erase()
    end
    field:spawn(burner, tile)
    return burner
end

local function create_heat_chaser_hitbox(user, facing, field, team, hit_props)
    --if not tile or tile:is_edge() then return end
    local hitbox = Battle.Spell.new(team)
    hitbox:set_facing(facing)
    hitbox:set_hit_props(hit_props)
    hitbox.update_func = function(self)
        self:highlight_tile(Highlight.Solid)
        self:get_tile():attack_entities(self)
    end
    hitbox.attack_func = function(self, other, judge)
        if not judge:hint_spawn_gfx() then return end
        local offset_y = math.random(-30,-15)
        local offset_x = math.random(-8,7)
        local hit_fx = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT2_TEXTURE, EFFECT2_PALETTE, EFFECT2_ANIMPATH, -999, "0", Playback.Once, self, self:get_facing(), true, true, true)
        self:get_field():spawn(hit_fx, self:get_tile())
    end
    hitbox.battle_end_func = function(self)
        self:delete()
    end
    hitbox.delete_func = function(self)
        self:erase()
    end
    --field:spawn(hitbox, tile)
    return hitbox
end

local function create_heat_chaser(user, navi, hit_props_1, hit_props_2, texture, anim_path, tile, offset)
    if not tile or tile:is_edge() then return end
    local facing = navi:get_facing()
    local field = navi:get_field()
    local team = navi:get_team()
    local heatchaser = graphic_init("spell", offset*2, 0, texture, navi:get_base_palette(), anim_path, -3, "0", Playback.Loop, navi, facing, false, true)
    heatchaser:set_hit_props(hit_props_1)
    heatchaser.hitbox = {
        [1] = create_heat_chaser_hitbox(user, facing, field, team, hit_props_2),
        [2] = create_heat_chaser_hitbox(user, facing, field, team, hit_props_2)
    }
    heatchaser.frames = 0
    local anim = heatchaser:get_animation()
    heatchaser.on_spawn_func = function()
        Engine.play_audio(SPAWN2_AUDIO, AudioPriority.Immediate)
    end
    heatchaser.update_func = function(self)
        self.frames = self.frames + 1
        if anim:get_state() == "2" then
            if self.frames%16==0 then Engine.play_audio(HEATCHASER_AUDIO, AudioPriority.Immediate) end
        end
        tile:attack_entities(self)
    end
    heatchaser.attack_func = function(self, other, judge)
        if not judge:hint_spawn_gfx() then return end
        local offset_y = math.random(-22,-10)
        local offset_x = math.random(-7,6)
        if self:get_facing() == Direction.Left then offset_x = -offset_x end
        local hit_fx = graphic_init("artifact", self:get_offset().x+(offset_x*2), self:get_offset().y+(offset_y*2), EFFECT0_TEXTURE, EFFECT0_PALETTE, EFFECT0_ANIMPATH, -999, "0", Playback.Once, self, self:get_facing(), true, false, true)
        self:get_field():spawn(hit_fx, self:get_tile())
    end
    heatchaser.collision_func = function(self)
        local boom_fx = graphic_init("artifact", self:get_offset().x, self:get_offset().y+(-16*2), BOOM_TEXTURE, BOOM_PALETTE, BOOM_ANIMPATH, -999, "0", Playback.Once, self, self:get_facing(), true, false)
        self:get_field():spawn(boom_fx, self:get_tile())
	    Engine.play_audio(BOOM_AUDIO, AudioPriority.Immediate)
        self:delete()
    end
    heatchaser.battle_end_func = function(self)
        self:delete()
    end
    heatchaser.delete_func = function(self)
        self:erase()
    end
    field:spawn(heatchaser, tile)
    return heatchaser
end

burnerman.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_MOVE")
    local frame_sequence = make_frame_data({
        {1,0.0}, {2,0.017}, {3,0.017}, {4,0.117}, {4,0.017}, {4,0.350}, {4,0.017}, {3,0.017}, {2,0.017}, {1,0.033}
    })
    action:override_animation_frames(frame_sequence)
	action:set_lockout(make_animation_lockout())
    local voice_lines = {
        [1] = {frame=41, line="sutoraikubaanaa2", text="STRIKE BURNER!"},  -- AXESS #30
        [2] = {frame=61, line="sutoraikubaanaa3", text="Strike Burner!"},  -- AXESS #46
        [3] = {frame=71, line="kuraena1",         text="Take this!"},      -- AXESS #24
        [4] = {frame=61, line="moero1",           text="Burn!"},           -- AXESS #24
        [5] = {frame=41, line="moero2",           text="Burn, BUUUUUURN!"} -- AXESS #24
    }
    local random_voice = math.random(1,#voice_lines)
    local add_frames = 0
    local read_voice_input = true
    local use_voice = false
    action.update_func = function(self)
        if read_voice_input and user:input_has(Input.Held.Use) then
            use_voice = true
            read_voice_input = false
        end
    end
	action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        local actor = self:get_actor()
        local facing = user:get_facing()
        local field = user:get_field()
        local team = user:get_team()

        local navi = nil
        local navi_anim = nil
        self:add_anim_action(4, function()
            actor:hide()
        end)
        self:add_anim_action(5, function()
            if random_voice == #voice_lines and use_voice then add_frames = 100 end
            read_voice_input = false
            actor:get_animation():set_playback_speed(0)

            navi = graphic_init("spell", 0, 0, BURNERMAN_TEXTURE, nil, BURNERMAN_ANIMPATH, -1, "IDLE", Playback.Loop, user, facing, false, true)
            navi:store_base_palette(Engine.load_texture(_folderpath.."gfx/palette/burnerman-"..burnerman.palette_type..".png"))
            navi:set_palette(navi:get_base_palette())
            navi_anim = navi:get_animation()
            navi.state = "SPAWN"
            navi.frames = 1

            navi.burnerU = nil
            navi.burnerD = nil
            navi.strikeburner = nil

            local user_tile = user:get_tile()
            if user_tile:is_hole() then
                navi.state = "HOLE"
                navi_anim:set_state("HOLE")
                navi_anim:refresh(navi:sprite())
            end
            local next_tile = user_tile:get_tile(facing, 1)

            local base_damage = props.damage
            local panel_damage = 0
            local finalized_damage = 0
            if burnerman.damage_type ~= "NORMAL" then
                base_damage = 70
                if burnerman.damage_type == "HOLY" then
                    local holy_query = function(o)
                        return o and o:get_state() == TileState.Holy and o:get_team() == team
                    end
                    local find_holy = field:find_tiles(holy_query)
                    if find_holy[1] ~= nil then
                        if #find_holy > 10 then
                            panel_damage = (5 * 10)
                        else
                            panel_damage = (5 * #find_holy)
                        end
                    end
                elseif burnerman.damage_type == "DARK" then
                    local dark_query = function(o)
                        return o and o:get_health() == 0 and o:get_name() == "DarkHole" and o:get_animation():get_state() == "DARKHOLE"
                    end
                    local find_dark = field:find_entities(dark_query)
                    if find_dark[1] ~= nil then
                        if #find_dark > 10 then
                            panel_damage = (5 * 10)
                        else
                            panel_damage = (5 * #find_dark)
                        end
                    end
                end
                debug_print("base damage is "..base_damage..".")
                local multiplied_damage = props.damage
                if multiplied_damage ~= 777 then
                    if multiplied_damage % 2 == 0 then
                        debug_print("multiplied pre-damage is an EVEN number.")
                        if multiplied_damage / 2 < 777 then
                            finalized_damage = math.floor((base_damage + panel_damage + ((multiplied_damage) - 777)))
                            if not print_debug then
                                print("BurnerMan: "..base_damage.."+"..panel_damage.."+"..math.floor(multiplied_damage - 777).." = "..finalized_damage)
                            end
                        else
                            finalized_damage = math.floor((base_damage + panel_damage + ((multiplied_damage / 2) - 777))*2)
                            if not print_debug then
                                print("BurnerMan: ("..base_damage.."+"..panel_damage.."+"..math.floor((multiplied_damage / 2) - 777)..")*2 = "..finalized_damage)
                            end
                        end
                    else
                        debug_print("multiplied pre-damage is an ODD number.")
                        finalized_damage = math.floor(base_damage + panel_damage + (multiplied_damage - 777))
                        if not print_debug then
                            print("BurnerMan: "..base_damage.."+"..panel_damage.."+"..math.floor(multiplied_damage - 777).." = "..finalized_damage)
                        end
                    end
                else
                    debug_print("multiplied pre-damage is NOT multiplied at all.")
                    finalized_damage = math.floor(base_damage + panel_damage)
                    if not print_debug then
                        print("BurnerMan: "..base_damage.."+"..panel_damage.."+0 = "..finalized_damage)
                    end
                end
                debug_print("finalized damage is "..finalized_damage..".")
            else
                finalized_damage = base_damage
            end
            local holy_k = 0
            local holy_c = 0.033
		    local holy_is_reveal = false
		    local holy_own_tiles = field:find_tiles(function(tile) 
		    	return not tile:is_edge() and tile:get_state() == TileState.Holy and tile:get_team() == user:get_team()
		    end)

            local hit_props_1 = HitProps.new()
            :dmg(finalized_damage)
            :impact()
            :flinch()
            :flash()
            :breaking()
            :no_counter()
            :elem(props.element)
            :from(user:get_context())
            local hit_props_2 = HitProps.new()
            :dmg(finalized_damage)
            :impact()
            :flinch()
            :flash()
            :no_counter()
            :elem(props.element)
            :from(user:get_context())

            navi.on_spawn_func = function()
                debug_print("spawned on tile ("..user_tile:x()..";"..user_tile:y()..")")
                Engine.play_audio(SPAWN_AUDIO, AudioPriority.Immediate)
            end
            navi.update_func = function(self, dt)
			    if holy_k < 9 and holy_c <= 0 and burnerman.damage_type == "HOLY" then
				    holy_k = holy_k + 1
				    holy_c = 0.033
			    	if holy_is_reveal then
			    		holy_is_reveal = false
			    		for i=1, #holy_own_tiles do
			    			holy_own_tiles[i]:set_state(TileState.Holy)
			    		end
			    	else
			    		holy_is_reveal = true
			    		for j=1, #holy_own_tiles do
			    			holy_own_tiles[j]:set_state(TileState.Normal)
			    		end
			    	end
			    else
			    	holy_c = holy_c - dt
			    end
                self.frames = self.frames + 1
                if self.state == "HOLE" then
                    if self.frames == 21 then
                        local move_fx = graphic_init("artifact", self:get_offset().x+self:get_tile_offset().x, self:get_offset().y+self:get_tile_offset().y+(-16*2), MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, -99, "1", Playback.Once, self, facing, true, false, true)
                        field:spawn(move_fx, user_tile)
                        self:delete()
                    end
                elseif self.state == "SPAWN" then
                    if self.frames == voice_lines[random_voice].frame then
                        if use_voice then
                            print("BurnerMan: "..voice_lines[random_voice].text)
                            Engine.play_audio(Engine.load_audio(_folderpath.."sfx/voice/"..voice_lines[random_voice].line..".ogg", true), AudioPriority.Immediate)
                        end
                    end
                    if self.frames == 21 then
                        local tileU = user_tile:get_tile(self:get_facing(), 2):get_tile(Direction.Up,   1)
                        self.burnerU = create_heat_chaser(user, self, hit_props_1, hit_props_2, HEATCHASER_U_TEXTURE, HEATCHASER_U_ANIMPATH, tileU, 8)
                        local tileD = user_tile:get_tile(self:get_facing(), 2):get_tile(Direction.Down, 1)
                        self.burnerD = create_heat_chaser(user, self, hit_props_1, hit_props_2, HEATCHASER_D_TEXTURE, HEATCHASER_D_ANIMPATH, tileD, -9)
                    end
                    if self.frames == 41 then
                        navi_anim:set_state("READY")
                        navi_anim:refresh(navi:sprite())
                    end
                    if self.frames == 42 then
                        if self.burnerU and not self.burnerU:is_deleted() then
                            local anim = self.burnerU:get_animation()
                            anim:set_state("1")
                            anim:set_playback(Playback.Loop)
                            --anim:refresh(self.burnerU:sprite())
                        end
                        if self.burnerD and not self.burnerD:is_deleted() then
                            local anim = self.burnerD:get_animation()
                            anim:set_state("1")
                            anim:set_playback(Playback.Loop)
                            --anim:refresh(self.burnerU:sprite())
                        end
                    end
                    if self.frames == 71 then
                        if self.burnerU and not self.burnerU:is_deleted() then
                            local anim = self.burnerU:get_animation()
                            anim:set_state("2")
                            anim:set_playback(Playback.Loop)
                            --anim:refresh(self.burnerU:sprite())
                            self.burnerU.frames = 0
                            Engine.play_audio(HEATCHASER_AUDIO, AudioPriority.Immediate)
                        end
                    end
                    if self.frames == 72 then
                        if self.burnerU and not self.burnerU:is_deleted() then
                            for i=1,2 do
                                local tile = self.burnerU:get_tile(Direction.Down, i)
                                if tile and not tile:is_edge() then
                                    field:spawn(self.burnerU.hitbox[i],tile)
                                end
                            end
                        end
                    end
                    if self.frames == 81 then
                        if self.burnerD and not self.burnerD:is_deleted() then
                            local anim = self.burnerD:get_animation()
                            anim:set_state("2")
                            anim:set_playback(Playback.Loop)
                            --anim:refresh(self.burnerU:sprite())
                            self.burnerD.frames = 0
                            Engine.play_audio(HEATCHASER_AUDIO, AudioPriority.Immediate)
                        end
                    end
                    if self.frames == 82 then
                        if self.burnerD and not self.burnerD:is_deleted() then
                            for i=1,2 do
                                local tile = self.burnerD:get_tile(Direction.Up, i)
                                if tile and not tile:is_edge() then
                                    field:spawn(self.burnerD.hitbox[i],tile)
                                end
                            end
                        end
                    end
                    if self.frames == 91 then
                        navi_anim:set_state("ATTACK")
                        navi_anim:set_playback(Playback.Loop)
                        navi_anim:refresh(navi:sprite())
                        local tile = user_tile:get_tile(self:get_facing(), 1)
                        self.strikeburner = create_strike_burner(user, self, facing, field, team, hit_props_2, tile)
                    end
                    if self.frames == 92 then
                        if self.strikeburner and not self.strikeburner:is_deleted() then
                            for i=1,3 do
                                local tile = user_tile:get_tile(self:get_facing(), i)
                                if tile and not tile:is_edge() then
                                    field:spawn(self.strikeburner.hitbox[i],tile)
                                end
                            end
                        end
                    end
                    if self.frames == 149+add_frames then
                        for i=1,2 do
                            if self.burnerU and not self.burnerU:is_deleted() then
                                if self.burnerU.hitbox[i] and not self.burnerU.hitbox[i]:is_deleted() then
                                    self.burnerU.hitbox[i]:delete()
                                end
                            end
                            if self.burnerD and not self.burnerD:is_deleted() then
                                if self.burnerD.hitbox[i] and not self.burnerD.hitbox[i]:is_deleted() then
                                    self.burnerD.hitbox[i]:delete()
                                end
                            end
                        end
                        if self.burnerU and not self.burnerU:is_deleted() then
                            self.burnerU:delete()
                        end
                        if self.burnerD and not self.burnerD:is_deleted() then
                            self.burnerD:delete()
                        end
                    end
                    if self.frames == 150+add_frames then
                        for i=1,3 do
                            if self.strikeburner.hitbox[i] and not self.strikeburner.hitbox[i]:is_deleted() then
                                self.strikeburner.hitbox[i]:delete()
                            end
                        end
                    end
                    if self.frames == 151+add_frames then
                        if self.strikeburner and not self.strikeburner:is_deleted() then
                            self.strikeburner:delete()
                        end
                        local move_fx = graphic_init("artifact", self:get_offset().x+self:get_tile_offset().x, self:get_offset().y+self:get_tile_offset().y+(-16*2), MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, -99, "1", Playback.Once, self, facing, true, false, true)
                        field:spawn(move_fx, user_tile)
                        self:delete()
                    end
                end
            end
            navi.delete_func = function()
                actor:get_animation():set_playback_speed(1)
            end
            field:spawn(navi, user_tile)
        end)
        self:add_anim_action(7, function()
            actor:reveal()
        end)
    end
    action.action_end_func = function(self)
        debug_print("in custom card action action_end_func()!")
        local actor = self:get_actor()
        actor:reveal()
    end
	return action
end

return burnerman