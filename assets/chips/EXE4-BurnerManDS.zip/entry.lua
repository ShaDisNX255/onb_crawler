local burnerman = include("burnerman/burnerman.lua")

local DAMAGE = 777 -- ???
burnerman.damage_type = "DARK"
burnerman.palette_type = "DARK"

burnerman.codes = {"B"}
burnerman.shortname = "BurnrMnDS"
burnerman.damage = DAMAGE
burnerman.time_freeze = true
burnerman.element = Element.Fire
burnerman.description = "Burnr atk\nfrom 3sds\n2sq ahead"
burnerman.long_description = "Concentrated burner attack from 3 sides, aiming 2 squares ahead"
burnerman.can_boost = true
burnerman.card_class = CardClass.Mega
burnerman.limit = 1
burnerman.mb = 69

function package_init(package)
    package:declare_package_id("com.OFC.card.EXE4-250-BurnerManDS")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(burnerman.codes)

    local props = package:get_card_props()
    props.shortname = burnerman.shortname
    props.damage = burnerman.damage
    props.time_freeze = burnerman.time_freeze
    props.element = burnerman.element
    props.description = burnerman.description
    props.long_description = burnerman.long_description
    props.can_boost = burnerman.can_boost
	props.card_class = burnerman.card_class
	props.limit = burnerman.limit
    props.meta_classes = {"Navi"}
end

card_create_action = burnerman.card_create_action