local superkitakaze = include("superkitakaze/superkitakaze.lua")

local DAMAGE = 0

superkitakaze.codes = {"E","N","T","*"}
superkitakaze.shortname = "SNrthWnd"
superkitakaze.damage = DAMAGE
superkitakaze.time_freeze = true
superkitakaze.element = Element.Wind
superkitakaze.description = "NorthWind blows off barriers"
superkitakaze.long_description = "A tremendous north wind blows off barriers"
superkitakaze.can_boost = false
superkitakaze.card_class = CardClass.Standard
superkitakaze.limit = 4
superkitakaze.mb = 33

function package_init(package) 
    package:declare_package_id("com.OFC.card.EXE4-130-SuperKitakaze")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(superkitakaze.codes)

    local props = package:get_card_props()
    props.shortname = superkitakaze.shortname
    props.damage = superkitakaze.damage
    props.time_freeze = superkitakaze.time_freeze
    props.element = superkitakaze.element
    props.description = superkitakaze.description
    props.long_description = superkitakaze.long_description
    props.can_boost = superkitakaze.can_boost
	props.card_class = superkitakaze.card_class
	props.limit = superkitakaze.limit
end

card_create_action = superkitakaze.card_create_action