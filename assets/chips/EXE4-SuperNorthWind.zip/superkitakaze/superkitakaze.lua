local print_debug = false

local SUPERKITAKAZE_TEXTURE = Engine.load_texture(_folderpath.."gfx/windgust.grayscaled.png")
local SUPERKITAKAZE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/Toppuu.png")
local SUPERKITAKAZE_ANIMPATH = _folderpath.."gfx/windgust.animation"
local SUPERKITAKAZE_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_76.ogg", true)

local function debug_print(text)
    if print_debug then
        print("[SuperKitakaze] "..text)
    end
end

local superkitakaze = {}

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function remove_barrier(user, facing, field, team, tile)
    local spell = Battle.Spell.new(team)
    spell:set_facing(facing)
    spell:set_hit_props(
        HitProps.new()
        :dmg(0)
        :impact()
        :no_counter()
        :elem(Element.Wind)
        :from(user:get_context())
    )
    spell.update_func = function(self)
        tile:attack_entities(self)
        self:erase()
    end
    user:get_field():spawn(spell, tile)
    return spell
end

local function spawn_kitakaze(user, facing, field, team, tile, offset1_x, offset1_y)
    local kitakaze = graphic_init("artifact", offset1_x, offset1_y, SUPERKITAKAZE_TEXTURE, SUPERKITAKAZE_PALETTE, SUPERKITAKAZE_ANIMPATH, -99, "0", Playback.Once, user, facing)
    kitakaze.update_func = function(self)
        kitakaze:get_animation():on_complete(function()
            if facing == Direction.Right then
                if self:get_offset().x < 1000 then
                    self:set_offset(self:get_offset().x + 48, self:get_offset().y + 20)
                else
                    self:erase()
                end
            else
                if self:get_offset().x > 1000 then
                    self:set_offset(self:get_offset().x - 48, self:get_offset().y + 20)
                else
                    self:erase()
                end
            end
        end)
    end
    field:spawn(kitakaze, tile)
	return kitakaze
end

superkitakaze.card_create_action = function(user, props)
    debug_print("in card_create_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())
    action.execute_func = function(self, user)
		debug_print("in custom card action execute_func()!")
        local actor = self:get_actor()
        local orig_speed = actor:get_animation():get_playback_speed()
        actor:get_animation():set_playback_speed(0)

		local facing = user:get_facing()
		local field = user:get_field()
		local team = user:get_team()

        local offset1_x = nil
        local offset1_y = nil
        local kitakaze_tile = nil
        local offsets = {
            [ 1] = {f=  9 , o_x= -16 , o_y=   -8 , t_y= math.ceil(field:height()/2)},
            [ 2] = {f= 17 , o_x= -10 , o_y= -100 , t_y= 1},
            [ 3] = {f= 25 , o_x= -20 , o_y= -124 , t_y= 1},
            [ 4] = {f= 33 , o_x= -40 , o_y= -172 , t_y= 1},
            [ 5] = {f= 42 , o_x= -32 , o_y=  -48 , t_y= math.ceil(field:height()/2)},
            [ 6] = {f= 50 , o_x= -40 , o_y= -206 , t_y= 1},
            [ 7] = {f= 57 , o_x= -20 , o_y= - 78 , t_y= 1},
            [ 8] = {f= 65 , o_x= -34 , o_y= - 74 , t_y= 1},
            [ 9] = {f= 73 , o_x= -46 , o_y= - 66 , t_y= 1},
            [10] = {f= 81 , o_x= -22 , o_y= - 48 , t_y= 1},
            [11] = {f= 89 , o_x= -38 , o_y= - 68 , t_y= math.ceil(field:height()/2)},
            [12] = {f= 98 , o_x= -38 , o_y= - 50 , t_y= field:height()},
        }
		self.frames = 1
        local step1 = Battle.Step.new()
        step1.update_func = function()
            for i=1,#offsets do
                if self.frames == offsets[i].f then
                    offset1_y = offsets[i].o_y
                    offset1_x = offsets[i].o_x
                    kitakaze_tile = field:tile_at(1,offsets[i].t_y)
                    if facing == Direction.Left then
                        offset1_x = -offset1_x
                        kitakaze_tile = field:tile_at(field:width(),offsets[i].t_y)
                    end
                    spawn_kitakaze(user, facing, field, team, kitakaze_tile, offset1_x, offset1_y)
                end
            end
			if self.frames == offsets[1].f-1 then
	            Engine.play_audio(SUPERKITAKAZE_AUDIO, AudioPriority.Immediate)
			end
			if self.frames == offsets[#offsets].f+3 then
                for x=1, field:width() do
                    for y=1, field:height() do
                        local remove_tile = field:tile_at(x,y)
                        if remove_tile:get_team() ~= team then
                            remove_barrier(user, facing, field, team, remove_tile)
                        end
                    end
                end
			end
			if self.frames == offsets[#offsets].f+25 then
                user:get_animation():set_playback_speed(orig_speed)
				step1:complete_step()
			end
			self.frames = self.frames + 1
        end
        self:add_step(step1)
    end
	return action
end

return superkitakaze