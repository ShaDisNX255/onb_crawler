local meteorearth = include("meteorearth/meteorearth.lua")

local DAMAGE = 80

meteorearth.meteor_number = 10

meteorearth.codes = {"C","P","Y"}
meteorearth.shortname = "MtoErth3"
meteorearth.damage = DAMAGE
meteorearth.time_freeze = false
meteorearth.element = Element.Fire
meteorearth.description = "Mteos aim\nat enemy&\ncrack sqs!"
meteorearth.long_description = "Cracking meteors rain down on the enemy!"
meteorearth.can_boost = true
meteorearth.card_class = CardClass.Standard
meteorearth.limit = 4
meteorearth.mb = 56

function package_init(package) 
    package:declare_package_id("com.OFC.card.EXE5-095-MeteorEarth3")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(meteorearth.codes)

    local props = package:get_card_props()
    props.shortname = meteorearth.shortname
    props.damage = meteorearth.damage
    props.time_freeze = meteorearth.time_freeze
    props.element = meteorearth.element
    props.description = meteorearth.description
    props.long_description = meteorearth.long_description
    props.can_boost = meteorearth.can_boost
	props.card_class = meteorearth.card_class
	props.limit = meteorearth.limit
end

card_create_action = meteorearth.card_create_action