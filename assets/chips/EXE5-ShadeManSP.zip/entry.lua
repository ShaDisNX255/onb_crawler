local shademan = include("shademan/shademan.lua")

local DAMAGE = 190
shademan.damage_type = "NORMAL"
shademan.palette_type = "NORMAL"

shademan.codes = {"S"}
shademan.shortname = "ShadeMnSP"
shademan.damage = DAMAGE
shademan.time_freeze = true
shademan.element = Element.None
shademan.description = "Rdial spr\nsonic atk\nCrshNoise"
shademan.long_description = "Radial supersonic attack CrushNoise!"
shademan.can_boost = true
shademan.card_class = CardClass.Mega
shademan.limit = 1
shademan.mb = 74

function package_init(package)
    package:declare_package_id("com.OFC.card.EXE5-263-ShadeManSP")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(shademan.codes)

    local props = package:get_card_props()
    props.shortname = shademan.shortname
    props.damage = shademan.damage
    props.time_freeze = shademan.time_freeze
    props.element = shademan.element
    props.description = shademan.description
    props.long_description = shademan.long_description
    props.can_boost = shademan.can_boost
	props.card_class = shademan.card_class
	props.limit = shademan.limit
    props.meta_classes = {"Navi"}
end

card_create_action = shademan.card_create_action