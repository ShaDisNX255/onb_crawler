local print_debug = false

local SHADOWMAN_TEXTURE = Engine.load_texture(_folderpath.."gfx/shadowman.grayscaled.png")
local SHADOWMAN_ANIMPATH = _folderpath.."gfx/shadowman.animation"
local SHURIKEN_TEXTURE = Engine.load_texture(_folderpath.."gfx/shuriken.grayscaled.png")
local SHURIKEN_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/shuriken.png")
local SHURIKEN_ANIMPATH = _folderpath.."gfx/shuriken.animation"
local SMOKE_TEXTURE = Engine.load_texture(_folderpath.."gfx/smoke.grayscaled.png")
local SMOKE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/smoke.png")
local SMOKE_ANIMPATH = _folderpath.."gfx/smoke.animation"

local SPAWN_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE5_109.ogg", true)
local THROW_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE5_221.ogg", true)

local function debug_print(text)
    if print_debug then
        print("[ShadowMan] "..text)
    end
end

local shadowman = {}

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function create_hitbox(user, damage, facing, field, tile)
    local hitbox = Battle.Spell.new(user:get_team())
    hitbox:set_facing(facing)
    hitbox:set_hit_props(
        HitProps.new()
        :dmg(damage)
        :impact()
        :flinch()
        :flash()
        :pierce_ground()
        :retangible()
        :no_counter()
        :elem2(Element.Sword)
        :from(user:get_context())
    )
    hitbox.update_func = function(self)
        self:get_tile():attack_entities(self)
        self:erase()
    end
    hitbox.attack_func = function(self, other)
		debug_print("attacked tile ("..self:get_tile():x()..";"..self:get_tile():y()..")")
	end
    field:spawn(hitbox, tile)
    return hitbox
end

local function create_shuriken(user, damage, facing, field, tile)
    if not tile or tile:is_edge() then return end
    local shuriken = graphic_init("spell", (-84*2), (-84*2), SHURIKEN_TEXTURE, SHURIKEN_PALETTE, SHURIKEN_ANIMPATH, -3, "0", Playback.Once, user, facing, false, true)
    shuriken.off_y = (12*2)
    shuriken.off_x = (12*2)
    if shuriken:get_facing() == Direction.Left then shuriken.off_x = -shuriken.off_x end
    shuriken.frames = 0
    shuriken.landed = false
    shuriken.on_spawn_func = function(self)
        Engine.play_audio(THROW_AUDIO, AudioPriority.Immediate)
        self:hide()
    end
    shuriken.update_func = function(self)
        self.frames = self.frames + 1
        if not self.landed then
            self:highlight_tile(Highlight.Solid)
            if self.frames >= 9-1 then
                if self.frames == 9-1 then
                    local smoke_fx = graphic_init("artifact", (-84*2), (-84*2), SMOKE_TEXTURE, SMOKE_PALETTE, SMOKE_ANIMPATH, -9, "0", Playback.Once, user, facing, true, true, true)
                    field:spawn(smoke_fx, tile)
                    self:reveal()
                end
                if self:get_offset().y < 0 then
                    self:set_offset(self:get_offset().x+self.off_x, self:get_offset().y+self.off_y)
                else
                    create_hitbox(user, damage, facing, field, tile)
                    self:get_animation():set_state("1")
                    self:get_animation():refresh(self:sprite())
                    self:set_offset(0,0)
                    self.frames = 0
                    self.landed = true
                end
            end
        else
            self:highlight_tile(Highlight.None)
            for i=34-1, 46-1, 4 do
                if self.frames == i then
                    self:hide()
                end
            end
            for i=36-1, 48-1, 4 do
                if self.frames == i then
                    self:reveal()
                end
            end
            if self.frames == 50-1 then
                self:erase()
            end
        end
    end
    field:spawn(shuriken, tile)
    return shuriken
end

shadowman.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_MOVE")
    local frame_sequence = make_frame_data({
        {1,0.0}, {2,0.017}, {3,0.017}, {4,0.517}, {4,0.017}, {4,0.533}, {4,0.017}, {3,0.017}, {2,0.017}, {1,0.4}
    })
    action:override_animation_frames(frame_sequence)
	action:set_lockout(make_animation_lockout())
    local read_voice_input = true
    local use_voice = false
    local voice_choice = math.random(1,2)
    action.update_func = function(self)
        if read_voice_input and user:input_has(Input.Held.Use) then
            use_voice = true
            read_voice_input = false
        end
    end
	action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        local actor = self:get_actor()
        local facing = user:get_facing()
        local field = user:get_field()
        local team = user:get_team()

        local navi = nil
        local navi_anim = nil
        local navi2 = nil
        local navi2_anim = nil
        local navi3 = nil
        local navi3_anim = nil
        self:add_anim_action(4, function()
            actor:hide()
        end)
        self:add_anim_action(5, function()
            read_voice_input = false
            actor:get_animation():set_playback_speed(0)
            
            navi = graphic_init("spell", 0, 0, SHADOWMAN_TEXTURE, nil, SHADOWMAN_ANIMPATH, -1, "WARP2", Playback.Once, user, facing, false, true)
            navi:store_base_palette(Engine.load_texture(_folderpath.."gfx/palette/shadowman-"..shadowman.palette_type..".png"))
            navi:set_palette(navi:get_base_palette())
            navi_anim = navi:get_animation()
            navi.state = "SPAWN"
            navi.frames = 0
            
            navi2 = graphic_init("spell", 0, 0, SHADOWMAN_TEXTURE, nil, SHADOWMAN_ANIMPATH, -1, "WARP2", Playback.Once, user, facing, false, true)
            navi2:store_base_palette(Engine.load_texture(_folderpath.."gfx/palette/shadowman-"..shadowman.palette_type..".png"))
            navi2:set_palette(navi2:get_base_palette())
            navi2_anim = navi2:get_animation()
            navi3 = graphic_init("spell", 0, 0, SHADOWMAN_TEXTURE, nil, SHADOWMAN_ANIMPATH, -1, "WARP2", Playback.Once, user, facing, false, true)
            navi3:store_base_palette(Engine.load_texture(_folderpath.."gfx/palette/shadowman-"..shadowman.palette_type..".png"))
            navi3:set_palette(navi3:get_base_palette())
            navi3_anim = navi3:get_animation()

            local user_tile = user:get_tile()

            local base_damage = props.damage
            local panel_damage = 0
            local finalized_damage = 0
            if shadowman.damage_type ~= "NORMAL" then
                base_damage = 45
                local multp_table = {
                    [1] = 1,
                    [2] = 1,
                    [3] = 2,
                    [4] = 2,
                    [5] = 3,
                    [6] = 3,
                    [7] = 4,
                    [8] = 4,
                    [9] = 5
                }
                if shadowman.damage_type == "HOLY" then
                    local holy_query = function(o)
                        return o and o:get_state() == TileState.Holy and o:get_team() == team
                    end
                    local find_holy = field:find_tiles(holy_query)
                    if find_holy[1] ~= nil then
                        if #find_holy > #multp_table then
                            panel_damage = 5 * #multp_table
                        else
                            panel_damage = 5 * multp_table[find_holy]
                        end
                    end
                elseif shadowman.damage_type == "DARK" then
                    local flinch_count = Battle.Player.from(user):get_flinch_count()
                    if flinch_count>0 then
                        if flinch_count > #multp_table then
                            panel_damage = (5 * #multp_table)
                        else
                            panel_damage = (5 * multp_table[flinch_count])
                        end
                    end
                end
                debug_print("base damage is "..base_damage..".")
                local multiplied_damage = props.damage
                if multiplied_damage ~= 777 then
                    if multiplied_damage % 2 == 0 then
                        debug_print("multiplied pre-damage is an EVEN number.")
                        if multiplied_damage / 2 < 777 then
                            finalized_damage = math.floor((base_damage + panel_damage + ((multiplied_damage) - 777)))
                            if not print_debug then
                                print("ShadowMan: "..base_damage.."+"..panel_damage.."+"..math.floor(multiplied_damage - 777).." = "..finalized_damage)
                            end
                        else
                            finalized_damage = math.floor((base_damage + panel_damage + ((multiplied_damage / 2) - 777))*2)
                            if not print_debug then
                                print("ShadowMan: ("..base_damage.."+"..panel_damage.."+"..math.floor((multiplied_damage / 2) - 777)..")*2 = "..finalized_damage)
                            end
                        end
                    else
                        debug_print("multiplied pre-damage is an ODD number.")
                        finalized_damage = math.floor(base_damage + panel_damage + (multiplied_damage - 777))
                        if not print_debug then
                            print("ShadowMan: "..base_damage.."+"..panel_damage.."+"..math.floor(multiplied_damage - 777).." = "..finalized_damage)
                        end
                    end
                else
                    debug_print("multiplied pre-damage is NOT multiplied at all.")
                    finalized_damage = math.floor(base_damage + panel_damage)
                    if not print_debug then
                        print("ShadowMan: "..base_damage.."+"..panel_damage.."+0 = "..finalized_damage)
                    end
                end
                debug_print("finalized damage is "..finalized_damage..".")
            else
                finalized_damage = base_damage
            end
            local holy_k = 0
            local holy_c = 0.033
		    local holy_is_reveal = false
		    local holy_own_tiles = field:find_tiles(function(tile) 
		    	return not tile:is_edge() and tile:get_state() == TileState.Holy and tile:get_team() == user:get_team()
		    end)

            local c_query = function(c)
                return c and c:get_health() > 0 and not c:is_team(team)
            end
            local start_tiles = {}
            local start_tile1 = field:tile_at(1,1)
            if facing == Direction.Left then field:tile_at(field:width(),1) end
            for x=1, field:width() do
                local new_tile = start_tile1:get_tile(facing, x-1)
                if new_tile and not new_tile:is_edge() and new_tile:get_team() == team then
                    for y=field:height(), 1, -1 do
                        table.insert(start_tiles, field:tile_at(new_tile:x(), y))
                    end
                    break
                end
            end
            local enemy_tiles = {}
            local enemy_start = 1
            local enemy_end = field:width()
            local enemy_mid = 1
            if facing == Direction.Left then
                enemy_start = field:width()
                enemy_end = 1
                enemy_mid = -1
            end
            for x=enemy_start, enemy_end, enemy_mid do
                for y=1, field:height() do
                    local target_tile = field:tile_at(x,y)
                    if target_tile and #target_tile:find_characters(c_query) > 0 then
                        table.insert(enemy_tiles, target_tile)
                    end
                end
            end
            local target_tiles = {}
            if #enemy_tiles == 1 then
                for i=1, 3 do table.insert(target_tiles, enemy_tiles[1]) end
            elseif #enemy_tiles == 2 then
                if enemy_tiles[1]:find_characters(c_query)[1]:get_health() <= enemy_tiles[2]:find_characters(c_query)[1]:get_health() then
                    for i=1, 2 do table.insert(target_tiles, enemy_tiles[1]) end
                    table.insert(target_tiles, enemy_tiles[2])
                else
                    table.insert(target_tiles, enemy_tiles[1])
                    for i=1, 2 do table.insert(target_tiles, enemy_tiles[2]) end
                end
            elseif #enemy_tiles >= 3 then
                for i=1, 3 do table.insert(target_tiles, enemy_tiles[i]) end
            end

            navi.on_spawn_func = function(self)
                debug_print("spawned on tile ("..user_tile:x()..";"..user_tile:y()..")")
                Engine.play_audio(SPAWN_AUDIO, AudioPriority.Immediate)
            end
            navi.update_func = function(self, dt)
			    if holy_k < 9 and holy_c <= 0 and shadowman.damage_type == "HOLY" then
				    holy_k = holy_k + 1
				    holy_c = 0.033
			    	if holy_is_reveal then
			    		holy_is_reveal = false
			    		for i=1, #holy_own_tiles do
			    			holy_own_tiles[i]:set_state(TileState.Holy)
			    		end
			    	else
			    		holy_is_reveal = true
			    		for j=1, #holy_own_tiles do
			    			holy_own_tiles[j]:set_state(TileState.Normal)
			    		end
			    	end
			    else
			    	holy_c = holy_c - dt
			    end
                self.frames = self.frames + 1
                if self.state == "SPAWN" then
                    if self.frames == 3-1 then
                        navi_anim:set_state("IDLE1")
                        navi_anim:set_playback(Playback.Loop)
                        navi_anim:refresh(navi:sprite())
                        navi2_anim:set_state("IDLE1")
                        navi2_anim:set_playback(Playback.Loop)
                        navi2_anim:refresh(navi2:sprite())
                        navi3_anim:set_state("IDLE1")
                        navi3_anim:set_playback(Playback.Loop)
                        navi3_anim:refresh(navi3:sprite())
                    end
                    if self.frames == 17-1 then
                        if use_voice then
                            print("ShadowMan: Shuriken Barrage!")
                            Engine.play_audio(Engine.load_audio(_folderpath.."sfx/voice/shurikenmidareuchi.ogg", true), AudioPriority.Immediate)
                        end
                    end
                    if self.frames == 25-1 then
                        local smoke_fx = graphic_init("artifact", 0, (-32*2), SMOKE_TEXTURE, SMOKE_PALETTE, SMOKE_ANIMPATH, -9, "0", Playback.Once, user, facing, true, true, true)
                        field:spawn(smoke_fx, navi:get_tile())
                    end
                    if self.frames == 27-1 then
                        navi_anim:set_state("WARP2")
                        navi_anim:refresh(navi:sprite())
                    end
                    if self.frames == 31-1 then
                        navi_anim:set_state("THROW")
                        navi_anim:refresh(navi:sprite())
                        create_shuriken(user, finalized_damage, facing, field, target_tiles[1])
                    end
                    if self.frames == 40-1 then
                        local smoke_fx = graphic_init("artifact", 0, (-32*2), SMOKE_TEXTURE, SMOKE_PALETTE, SMOKE_ANIMPATH, -9, "0", Playback.Once, user, facing, true, true, true)
                        field:spawn(smoke_fx, navi2:get_tile())
                    end
                    if self.frames == 42-1 then
                        navi2_anim:set_state("WARP2")
                        navi2_anim:refresh(navi2:sprite())
                    end
                    if self.frames == 46-1 then
                        navi2_anim:set_state("THROW")
                        navi2_anim:refresh(navi2:sprite())
                        create_shuriken(user, finalized_damage, facing, field, target_tiles[2])
                    end
                    if self.frames == 55-1 then
                        local smoke_fx = graphic_init("artifact", 0, (-32*2), SMOKE_TEXTURE, SMOKE_PALETTE, SMOKE_ANIMPATH, -9, "0", Playback.Once, user, facing, true, true, true)
                        field:spawn(smoke_fx, navi3:get_tile())
                    end
                    if self.frames == 57-1 then
                        navi3_anim:set_state("WARP2")
                        navi3_anim:refresh(navi3:sprite())
                    end
                    if self.frames == 61-1 then
                        navi3_anim:set_state("THROW")
                        navi3_anim:refresh(navi3:sprite())
                        create_shuriken(user, finalized_damage, facing, field, target_tiles[3])
                    end
                    ----
                    if self.frames == 69-1 then
                        navi:hide()
                    end
                    for i=70-1, 98-1, 4 do
                        if self.frames == i then
                            navi:reveal()
                        end
                    end
                    for i=72-1, 96-1, 4 do
                        if self.frames == i then
                            navi:hide()
                        end
                    end
                    if self.frames == 99-1 then
                        navi:hide()
                    end
                    ----
                    if self.frames == 84-1 then
                        navi2:hide()
                    end
                    for i=85-1, 113-1, 4 do
                        if self.frames == i then
                            navi2:reveal()
                        end
                    end
                    for i=87-1, 111-1, 4 do
                        if self.frames == i then
                            navi2:hide()
                        end
                    end
                    if self.frames == 114-1 then
                        navi2:hide()
                    end
                    ----
                    if self.frames == 99-1 then
                        navi3:hide()
                    end
                    for i=100-1, 128-1, 4 do
                        if self.frames == i then
                            navi3:reveal()
                        end
                    end
                    for i=102-1, 126-1, 4 do
                        if self.frames == i then
                            navi3:hide()
                        end
                    end
                    if self.frames == 129-1 then
                        navi:delete()
                        navi2:delete()
                        navi3:delete()
                        actor:get_animation():set_playback_speed(1)
                    end
                    ----
                end
            end
            navi.can_move_to_func = function(tile)
                return true
            end
            navi2.can_move_to_func = function(tile)
                return true
            end
            navi3.can_move_to_func = function(tile)
                return true
            end
            navi3.delete_func = function()
                actor:get_animation():set_playback_speed(1)
            end
            field:spawn(navi3, start_tiles[3])
            field:spawn(navi2, start_tiles[2])
            field:spawn(navi,  start_tiles[1])
        end)
        self:add_anim_action(7, function()
            actor:reveal()
        end)
    end
    action.action_end_func = function(self)
        local actor = self:get_actor()
        actor:reveal()
    end
	return action
end

return shadowman