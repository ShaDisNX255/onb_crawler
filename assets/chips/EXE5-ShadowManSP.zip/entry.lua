local shadowman = include("shadowman/shadowman.lua")

local DAMAGE = 60
shadowman.damage_type = "NORMAL"
shadowman.palette_type = "NORMAL"

shadowman.codes = {"S"}
shadowman.shortname = "ShadoMnSP"
shadowman.damage = DAMAGE
shadowman.time_freeze = true
shadowman.element = Element.None
shadowman.description = "Throw 3\nshurikens\nat enemy!"
shadowman.long_description = "Throw 3 shurikens at an enemy square!"
shadowman.can_boost = true
shadowman.card_class = CardClass.Mega
shadowman.limit = 1
shadowman.mb = 80

function package_init(package)
    package:declare_package_id("com.OFC.card.EXE5-245-ShadowManSP")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(shadowman.codes)

    local props = package:get_card_props()
    props.shortname = shadowman.shortname
    props.damage = shadowman.damage
    props.time_freeze = shadowman.time_freeze
    props.element = shadowman.element
    props.description = shadowman.description
    props.long_description = shadowman.long_description
    props.can_boost = shadowman.can_boost
	props.card_class = shadowman.card_class
	props.limit = shadowman.limit
    props.meta_classes = {"Navi"}
end

card_create_action = shadowman.card_create_action