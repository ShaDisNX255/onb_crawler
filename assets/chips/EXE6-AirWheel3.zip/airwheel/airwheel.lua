local print_debug = false

local AIRWHEEL_TEXTURE = Engine.load_texture(_folderpath.."gfx/airwheel.grayscaled.png")
local AIRWHEEL_ANIMPATH = _folderpath.."gfx/airwheel.animation"
local WINDBLADE_TEXTURE = Engine.load_texture(_folderpath.."gfx/windblade.grayscaled.png")
local WINDBLADE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/windblade.png")
local WINDBLADE_ANIMPATH = _folderpath.."gfx/windblade.animation"
local MOB_MOVE_TEXTURE = Engine.load_texture(_folderpath.."gfx/mob_move.grayscaled.png") -- flip for Player 2?
local MOB_MOVE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/mob_move.png")
local MOB_MOVE_ANIMPATH = _folderpath.."gfx/mob_move.animation"
local BOOM_TEXTURE = Engine.load_texture(_folderpath.."gfx/boom.grayscaled.png") -- flip for Player 2?
local BOOM_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/boom.png")
local BOOM_ANIMPATH = _folderpath.."gfx/boom.animation"

local TOSS_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_342.ogg", true)
local SPIN_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_159.ogg", true)
local BOOM_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_132.ogg", true) -- ???

local ObstacleInfo = include("ObstacleInfo.lua")

local function debug_print(text)
    if print_debug then
        print("[AirWheel] "..text)
    end
end

local airwheel = {}

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip, team)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    team = team or user:get_team()
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(team)
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(team)
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function create_blade_hitbox(user, hit_props, facing, field, team, tile)
    if not tile or tile:is_edge() then return end
    debug_print(tile:x(),tile:y())
    local spell = Battle.Spell.new(team)
    spell:set_facing(facing)
    spell:set_hit_props(hit_props)
    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end
    spell.battle_end_func = function(self)
        self:delete()
    end
    spell.delete_func = function(self)
        self:erase()
    end
    field:spawn(spell, tile)
    return spell
end

local function create_wind_blade(user, hit_props, facing, field, team, tile)
    debug_print("ATTACK")
	Engine.play_audio(SPIN_AUDIO, AudioPriority.Immediate)
    local blade = graphic_init("artifact", user:get_tile_offset().x+user:get_offset().x, user:get_tile_offset().y+user:get_offset().y, WINDBLADE_TEXTURE, WINDBLADE_PALETTE, WINDBLADE_ANIMPATH, -99, "0", Playback.Once, user, facing, true, false, false, team)
    for i=0,7 do
        create_blade_hitbox(user, hit_props, facing, field, team, tile:get_tile(math.floor(2^i),1))
    end
    field:spawn(blade, tile)
    return blade
end

local function create_air_wheel(user, props, facing, field, team, spawn_tile)
    if not spawn_tile or spawn_tile:is_hole() or check_obstacles(spawn_tile) then
        local move_fx = graphic_init("artifact", 0, 0, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, -99, "0", Playback.Once, user, facing, true, false, true)
        field:spawn(move_fx, spawn_tile)
        return
    end
    -- Destroyed Obstacle
	local function create_destroyedobstacle(self)
	    local field = self:get_field()
	    local objs = field:find_entities(function(e)
	        return e:get_name() == "DestroyedObstacle"
	    end)
	    if #objs >= 3 then return end
	    local dobj = Battle.Artifact.new()
	    dobj:set_name("DestroyedObstacle")
	    dobj.battle_end_func = function()
	    	dobj:delete()
	    end
	    field:spawn(dobj, self:get_tile())
	    return dobj
	end
    -- Obs. controller
    --[[
	local obs_control = nil
    local function create_controller(orig_obs, tile)
		local controller = Battle.Artifact.new()
	    controller:set_name("OSControl_"..orig_obs:get_id())
        controller.update_func = function(self)
            if not orig_obs or orig_obs:is_deleted() then
                self:delete()
                return
            end
            local new_offset = self:get_offset()
            local new_elevation = self:get_elevation()
            if self:get_tile() ~= orig_obs:get_tile() then
                self:teleport(orig_obs:get_tile(), ActionOrder.Immediate)
            end
            orig_obs:set_offset(new_offset.x, new_offset.y)
            orig_obs:set_elevation(new_elevation)
        end
        controller.can_move_to_func = function(self)
            return true
        end
	    controller.battle_end_func = function(self)
	    	self:delete()
	    end
        field:spawn(controller, tile)
        return controller
    end]]
    ----
    local palette = Engine.load_texture(_folderpath.."gfx/palette/v"..airwheel.version..".png")
    local wheel = graphic_init("obstacle", 0, 0, AIRWHEEL_TEXTURE, palette, AIRWHEEL_ANIMPATH, -3, "0", Playback.Once, user, facing, false, false, false, Team.Other)
    wheel.anim = wheel:get_animation()
	ObstacleInfo.set_cannot_be_targeted(wheel, true)
	ObstacleInfo.set_cannot_be_manipulated(wheel, true)
	ObstacleInfo.add_to_limit_1(wheel, team, field)
	ObstacleInfo.set_obstacle_damage(wheel, props.element, props.damage)
    local hit_props = HitProps.new()
    :dmg(props.damage)
    :impact()
    :flinch()
    :elem(props.element)
    :from(user:get_context())
    --wheel:set_hit_props(hit_props)
    wheel:set_name("AirWheel")
    wheel:set_health(airwheel.health)
    wheel:set_float_shoe(false)
    wheel:set_air_shoe(false)
    wheel:share_tile(false)
    wheel:toggle_hitbox(true)
    -- Other props
    wheel.collision_available = true
    wheel.hits = airwheel.hits
    wheel.deleting = false
    wheel.state = "SLIDING"
    wheel.frames = 1
    -- Defense Rule
    local wheel_defense = Battle.DefenseRule.new(1, DefenseOrder.Always)
    wheel_defense.filter_statuses_func = function(a_props)
        a_props.flags = a_props.flags & (~Hit.Flash)
        a_props.flags = a_props.flags & (~Hit.Drag)
        return a_props
    end
    wheel_defense.can_block_func = function(judge, attacker, defender)
        local attacker_hit_props = attacker:copy_hit_props()
        if attacker_hit_props:has_element(Element.Wind) and attacker_hit_props.damage > 1 then
            wheel.hits = wheel.hits + 1
        end
        if attacker:get_id() == wheel:get_id() or attacker:get_name() == tostring(wheel:get_id()) then
            judge:block_collision()
        end
    end
    wheel:add_defense_rule(wheel_defense)
    wheel.on_spawn_func = function(self)
        --obs_control = create_controller(self, field:tile_at(0,0))
	    Engine.play_audio(TOSS_AUDIO, AudioPriority.Immediate)
    end
    wheel.update_func = function(self)
        check_collision(self, hit_props)
        if self.state == "SLIDING" then
            if not self:is_sliding() then
                local tile = self:get_tile(facing,1)
                if not tile or not tile:is_walkable() or check_characters_true(tile) or check_obstacles(tile) then
                    self.state = "WAITING"
                    self.frames = 1
                else
                    self:slide(tile, frames(10), frames(0), ActionOrder.Voluntary)
                end
            end
        end
        if self.state == "WAITING" then
            if self.frames == 17 then
                self.state = "ATTACK"
                self.frames = 1
                self.anim:set_state("1")
                self.anim:set_playback(Playback.Loop)
                self.anim:refresh(self:sprite())
            end
        end
        if self.state == "ATTACK" then
            if self.frames == 1 then
                create_wind_blade(user, hit_props, facing, field, team, self:get_tile())
            end
            if self.deleting then
                if self.frames == 1 then
                    --wheel:share_tile(true)
                    wheel:toggle_hitbox(false)
                end
                if self.frames == 2 then
                    self.anim:set_state("0")
                    self.anim:refresh(self:sprite())
                    local move_fx = graphic_init("artifact", self:get_tile_offset().x+self:get_offset().x, self:get_tile_offset().y+self:get_offset().y, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, -99, "0", Playback.Once, self, self:get_facing(), true, false, true)
                    field:spawn(move_fx, self:get_tile())
                end
                if self.frames == 6 then
                    self:delete()
                end
            else
                if self.frames == 11 then
                    self.hits = self.hits - 1
                    --self.state = "ATTACK"
                    if self.hits <= 0 then
                        self.deleting = true
                    end
                    self.frames = 1
                    return
                end
            end
        end
        self.frames = self.frames + 1
    end
    wheel.can_move_to_func = function(tile)
        return true
    end
    wheel.battle_end_func = function(self)
        self:set_health(0)
    end
    wheel.delete_func = function(self)
        if self:get_health() <= 0 then
            create_destroyedobstacle(self)
	        Engine.play_audio(BOOM_AUDIO, AudioPriority.Immediate)
            local move_fx = graphic_init("artifact", self:get_tile_offset().x+self:get_offset().x, self:get_tile_offset().y+self:get_offset().y, BOOM_TEXTURE, BOOM_PALETTE, BOOM_ANIMPATH, -99, "0", Playback.Once, self, self:get_facing(), true, false, true)
            field:spawn(move_fx, self:get_tile())
        end
        self:erase()
    end
    field:spawn(wheel, spawn_tile)
    return wheel
end

airwheel.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_SWORD")
    local frame1 = {1,0.017} --(+)1 frame
    local frame2 = {2,0.033}
    local frame3 = {3,0.033}
    local frame4 = {4,0.167}
    local frame5 = {4,0.1}   --(-)1 frame
    local frame_sequence = make_frame_data({frame1, frame2, frame3, frame4, frame5})
    action:override_animation_frames(frame_sequence)
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        local facing = user:get_facing()
        local field = user:get_field()
		local team = user:get_team()
        user:toggle_counter(true)
		self:add_anim_action(2, function()
            create_air_wheel(user, props, facing, field, team, user:get_tile(facing,1))
            local hilt = self:add_attachment("HILT")
            local hilt_sprite = hilt:sprite()
            hilt_sprite:set_texture(user:get_texture(), true)
            hilt_sprite:set_layer(-1)
            hilt_sprite:enable_parent_shader(true)
            local hilt_anim = hilt:get_animation()
            hilt_anim:copy_from(user:get_animation())
            hilt_anim:set_state("HAND")
            hilt_anim:refresh(hilt_sprite)
        end)
		self:add_anim_action(5,function()
			user:toggle_counter(false)
		end)
	end
	action.action_end_func = function()
		user:toggle_counter(false)
	end
    return action
end

--(Function by Alrysc)
-- TODO: When we get is_passthrough or something, check to see if target became flashing before 
    -- we are allowed to spawn another one. Don't want to instakill viruses
-- self.collision_available can do something related to that. Does nothing now
function check_collision(self, hit_props)
    local t = self:get_tile()
    if self.collision_available and check_characters(t, self) then 
        create_collision_attack(self, hit_props, t)
    end
end

--(Function by Alrysc, edited by K1rbYat1Na)
function create_collision_attack(user, hit_props, tile)
    local spell = Battle.Spell.new(Team.Other)
    spell:set_facing(user:get_facing())
    spell:set_hit_props(hit_props)
    spell:set_name(tostring(user:get_id()))
    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end
    spell.battle_end_func = function(self)
        self:delete()
    end
    spell.collision_func = function(self, other)
        if other:get_id() ~= user:get_id() and not other:get_animation():has_state("PASS_THROUGH") and other:get_name() ~= "CANTINTERACT" then
            user:set_health(0)
        end
    end
    spell.delete_func = function(self)
        self:erase()
    end
    user:get_field():spawn(spell, tile)
end

-- Checks for non-zero-health Obstacles.
function check_obstacles(tile)
    local ob = tile:find_obstacles(function(o)
        if o:get_animation():has_state("PASS_THROUGH") or o:get_name() == "CANTINTERACT" then
            return false
        else
            return true
        end
        return o:get_health() > 0
    end)
    return #ob > 0 
end

-- Checks for unfriendly Characters.
function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_name() ~= "PASS_THROUGH" and c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)
    return #characters > 0
end

-- Checks for any Characters.
function check_characters_true(tile)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_name() ~= "PASS_THROUGH"
    end)
    return #characters > 0
end

function check_characters_true_team(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_name() ~= "PASS_THROUGH" and c:get_tile():get_team() == self:get_tile():get_team()
    end)
    return #characters > 0
end

return airwheel