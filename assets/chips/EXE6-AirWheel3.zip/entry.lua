local airwheel = include("airwheel/airwheel.lua")

local DAMAGE = 50

airwheel.version = 3
airwheel.health = 400
airwheel.hits = airwheel.version

airwheel.codes = {"N","O","T"}
airwheel.shortname = "AirWhel"..airwheel.version
airwheel.damage = DAMAGE
airwheel.time_freeze = false
airwheel.element = Element.Wind
airwheel.description = "Spits out\nwindstorm\nattk arnd"
airwheel.long_description = "A wheel slides forward to create a windstorm that hits around"
airwheel.can_boost = true
airwheel.card_class = CardClass.Standard
airwheel.limit = 3
airwheel.mb = 36

function package_init(package) 
    package:declare_package_id("com.OFC.card.EXE6-13"..airwheel.version.."-AirWheel"..airwheel.version)
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(airwheel.codes)

    local props = package:get_card_props()
    props.shortname = airwheel.shortname
    props.damage = airwheel.damage
    props.time_freeze = airwheel.time_freeze
    props.element = airwheel.element
    props.description = airwheel.description
    props.long_description = airwheel.long_description
    props.can_boost = airwheel.can_boost
	props.card_class = airwheel.card_class
	props.limit = airwheel.limit
end

card_create_action = airwheel.card_create_action