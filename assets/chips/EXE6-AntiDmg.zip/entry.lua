local ANTIDMG_DEBUG = false


-- ============================================================================
-- Special thanks to Alrysc for the pointers and for the assets
-- Assets taken from KawarimiMagic NCP block
-- Original code by Dawn
-- ============================================================================

-- ============================================================================
-- Kawarimi assets
-- ============================================================================

local SHURIKEN_TEXTURE =
    Engine.load_texture(_folderpath.."gfx/shuriken.grayscaled.png")

local SHURIKEN_PALETTE =
    Engine.load_texture(_folderpath.."gfx/palette/shuriken.png")

local SHURIKEN_ANIMPATH =
    _folderpath.."gfx/shuriken.animation"


local SMOKE_TEXTURE =
    Engine.load_texture(_folderpath.."gfx/smoke.grayscaled.png")

local SMOKE_PALETTE =
    Engine.load_texture(_folderpath.."gfx/palette/smoke.png")

local SMOKE_ANIMPATH =
    _folderpath.."gfx/smoke.animation"


local SMOKE_AUDIO =
    Engine.load_audio(
        _folderpath.."sfx/EXE6_269.ogg",
        true
    )


-- ============================================================================
-- Debug logging
-- ============================================================================

local function antidmg_log(message)
    if ANTIDMG_DEBUG then
        print("[AntiDmg DEBUG] " .. message)
    end
end


-- ============================================================================
-- Generic Kawarimi graphic helper
--
-- Based on the helper used by KawarimiMagic.
-- ============================================================================

local function graphic_init(
    graphic_type,
    x,
    y,
    texture,
    animation,
    layer,
    state,
    user,
    facing,
    delete_on_complete,
    relative_to_user,
    flip
)
    flip = flip or false
    delete_on_complete = delete_on_complete or false
    facing = facing or nil

    local graphic = nil

    if graphic_type == "artifact" then
        graphic = Battle.Artifact.new()

    elseif graphic_type == "spell" then
        graphic = Battle.Spell.new(user:get_team())

    elseif graphic_type == "obstacle" then
        graphic = Battle.Obstacle.new(user:get_team())
    end

    graphic:sprite():set_layer(layer)
    graphic:never_flip(flip)
    graphic:set_texture(texture)

    if facing then
        graphic:set_facing(facing)
    end

    if relative_to_user
        and user:get_facing() == Direction.Left
    then
        x = x * -1
    end

    graphic:set_offset(x, y)

    local anim = graphic:get_animation()

    anim:load(animation)
    anim:set_state(state)
    anim:refresh(graphic:sprite())

    if delete_on_complete then
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end


-- ============================================================================
-- Progress helper used by Kawarimi's shuriken
-- ============================================================================

local function get_progress_vector(vector, time, frame)
    if frame == time then
        return vector
    end

    local progress_x =
        math.floor(vector.x / time * frame)

    local progress_y =
        math.floor(vector.y / time * frame)

    return {
        x = progress_x,
        y = progress_y
    }
end


-- ============================================================================
-- Targeting
-- ============================================================================

local function targeting(user, target, field)
    local tile

    if not target
        or (target and target:is_deleted())
    then
        local enemy_filter = function(character)
            return character:get_team()
                ~= user:get_team()
        end

        local enemy_list =
            field:find_nearest_characters(
                user,
                enemy_filter
            )

        if #enemy_list > 0 then
            tile =
                enemy_list[1]:get_current_tile()
        else
            tile = nil
        end
    else
        tile = target:get_tile()
    end

    if not tile then
        return nil
    end

    return tile
end


-- ============================================================================
-- Independent AntiDmg cleanup watcher
--
-- The CardAction normally turns the player's hitbox back on.
--
-- If something such as a form change wipes the CardAction before its cleanup
-- executes, can_attack() eventually becomes true again. This independent
-- Spell survives that action cancellation and restores the hitbox.
-- ============================================================================

local function start_antidmg_failsafe(
    user,
    reaction_state
)
    if user:is_deleted() then
        return
    end

    local field = user:get_field()

    local watcher =
        Battle.Spell.new(user:get_team())

    watcher:hide()

    local last_can_attack =
        user:can_attack()

    local saw_cannot_attack =
        not last_can_attack

    antidmg_log(
        "failsafe started; can_attack = "
        .. tostring(last_can_attack)
    )

    watcher.update_func =
        function(self, dt)
            if user:is_deleted() then
                antidmg_log(
                    "user deleted; ending failsafe"
                )

                self:erase()
                return
            end

            local can_attack =
                user:can_attack()

            if can_attack
                ~= last_can_attack
            then
                antidmg_log(
                    "can_attack -> "
                    .. tostring(can_attack)
                )

                last_can_attack =
                    can_attack
            end

            if not can_attack then
                saw_cannot_attack = true
                return
            end

            if saw_cannot_attack then

                -- Normal CardAction cleanup already handled everything.
                if reaction_state.normal_cleanup then
                    antidmg_log(
                        "failsafe ending; "
                        .. "normal cleanup already restored player"
                    )

                    self:erase()
                    return
                end

                -- The CardAction vanished before reaching its normal
                -- cleanup. Restore the player ourselves.
                antidmg_log(
                    "failsafe restoring player"
                )

                user:reveal()
                user:toggle_hitbox(true)

                self:erase()
            end
        end

    field:spawn(
        watcher,
        user:get_tile()
    )
end


-- ============================================================================
-- Kawarimi-style smoke
-- ============================================================================

local function create_kawarimi_smoke(user)
    local smoke =
        graphic_init(
            "spell",
            0,
            -16 * 2,
            SMOKE_TEXTURE,
            SMOKE_ANIMPATH,
            -4,
            "0",
            user,
            user:get_facing(),
            true,
            true,
            true
        )

    smoke:store_base_palette(
        SMOKE_PALETTE
    )

    smoke:set_palette(
        smoke:get_base_palette()
    )

    user:get_field():spawn(
        smoke,
        user:get_tile()
    )

    Engine.play_audio(
        SMOKE_AUDIO,
        AudioPriority.Low
    )
end


-- ============================================================================
-- Kawarimi-style shuriken
--
-- This is based on the NaviCust KawarimiMagic shuriken instead of the old
-- AntiDmg tile-slide implementation.
--
-- The Spell itself lives on the destination tile. Its sprite begins offset
-- high above and toward the user, then moves toward offset 0 over 16 frames.
-- It attacks the destination tile when the visual reaches it.
-- ============================================================================

local function create_shuriken(
    user,
    start_tile,
    dest_tile,
    hit_props
)
    if user:is_deleted()
        or not start_tile
        or not dest_tile
    then
        return
    end

    -- Same value used by KawarimiMagic.
    local height = 166 * 2

    local distx =
        (
            dest_tile:x()
            - start_tile:x()
        )
        * start_tile:width()

    local dist_mod = 1
    local offset_mod = 1

    local movement_dir =
        user:get_facing()

    if (
        movement_dir == Direction.Right
        and (
            dest_tile:x()
            - start_tile:x()
        ) <= 0
    ) or (
        movement_dir == Direction.Left
        and (
            dest_tile:x()
            - start_tile:x()
        ) >= 0
    ) then
        movement_dir =
            Direction.reverse(
                movement_dir
            )

        offset_mod = -1
    end

    if movement_dir == Direction.Left then
        dist_mod = -1
    end

    local spell =
        graphic_init(
            "spell",

            distx
                * -1
                * offset_mod
                * dist_mod,

            height * -1,

            SHURIKEN_TEXTURE,
            SHURIKEN_ANIMPATH,

            -3,
            "0",

            user,
            movement_dir,

            false,
            true
        )

    spell:store_base_palette(
        SHURIKEN_PALETTE
    )

    spell:set_palette(
        spell:get_base_palette()
    )

    spell:set_hit_props(
        hit_props
    )

    local move_duration = 16
    local move_progress = 1

    local dest = {
        x = distx,
        y = height
    }

    local offset =
        spell:get_offset()

    local first = true

    antidmg_log(
        "launching Kawarimi-style shuriken"
    )

    spell.update_func =
        function(self)
            self:get_tile():highlight(
                Highlight.Solid
            )

            if move_progress
                > move_duration
            then
                if first then
                    first = false

                    antidmg_log(
                        "shuriken reached destination; "
                        .. "attacking tile"
                    )

                    self:get_tile():attack_entities(
                        self
                    )
                end

                self:get_animation():set_state(
                    "1"
                )

                self:get_animation():on_complete(
                    function()
                        self:hide()
                        self:delete()
                    end
                )

                self:get_animation():refresh(
                    self:sprite()
                )

                self.update_func =
                    function()
                    end

                return
            end

            local d_v =
                get_progress_vector(
                    dest,
                    move_duration,
                    move_progress
                )

            self:set_offset(
                offset.x
                    + d_v.x
                    - d_v.x % 2,

                offset.y
                    + d_v.y
                    - d_v.y % 2
            )

            move_progress =
                move_progress + 1
        end

    user:get_field():spawn(
        spell,
        dest_tile
    )
end


-- ============================================================================
-- AntiDmg reaction
-- ============================================================================

local function poof_user(
    user,
    aggressor,
    props
)
    if user:is_deleted()
        or aggressor == nil
    then
        return nil
    end

    local action =
        Battle.CardAction.new(
            user,
            "PLAYER_IDLE"
        )

    local field =
        user:get_field()

    local tile =
        targeting(
            user,
            aggressor,
            field
        )

    if tile == nil then
        antidmg_log(
            "targeting returned nil"
        )

        return action
    end

    action:set_lockout(
        make_sequence_lockout()
    )

    action.execute_func =
        function(self, user)
            antidmg_log(
                "poof action execute_func STARTED"
            )

            antidmg_log(
                "poof start: can_attack = "
                .. tostring(
                    user:can_attack()
                )
            )

            local step1 =
                Battle.Step.new()

            local reaction_state = {
                normal_cleanup = false
            }

            -- ------------------------------------------------------------
            -- Kawarimi smoke
            -- ------------------------------------------------------------

            antidmg_log(
                "spawning Kawarimi smoke"
            )

            create_kawarimi_smoke(
                user
            )


            -- ------------------------------------------------------------
            -- Hide / disable hitbox
            -- ------------------------------------------------------------

            user:hide()

            antidmg_log(
                "disabling hitbox"
            )

            user:toggle_hitbox(false)

            antidmg_log(
                "hitbox disabled"
            )


            -- Start the failsafe only once the CardAction is truly active
            -- and the hitbox has actually been disabled.
            start_antidmg_failsafe(
                user,
                reaction_state
            )


            -- ------------------------------------------------------------
            -- Kawarimi shuriken
            -- ------------------------------------------------------------

            -- Preserve AntiDmg's original damage/flags.
            --
            -- We're borrowing Kawarimi's projectile presentation, not
            -- changing AntiDmg into the NaviCust attack.
            local shuriken_props =
                HitProps.new(
                    props.damage,

                    Hit.Impact
                        | Hit.Flinch,

                    Element.Sword,

                    user:get_context(),

                    Drag.None
                )

            create_shuriken(
                user,
                user:get_tile(),
                tile,
                shuriken_props
            )


            -- ------------------------------------------------------------
            -- Original AntiDmg duration / cleanup
            -- ------------------------------------------------------------

            local cooldown = 60

            step1.update_func =
                function(self, dt)
                    if cooldown > 0 then
                        cooldown =
                            cooldown - 1

                        return
                    end

                    antidmg_log(
                        "normal poof cleanup reached"
                    )

                    reaction_state.normal_cleanup =
                        true

                    user:reveal()

                    antidmg_log(
                        "restoring hitbox normally"
                    )

                    user:toggle_hitbox(true)

                    antidmg_log(
                        "normal poof cleanup complete; "
                        .. "can_attack = "
                        .. tostring(
                            user:can_attack()
                        )
                    )

                    self:complete_step()
                end

            self:add_step(step1)
        end

    return action
end


-- ============================================================================
-- Package
-- ============================================================================

function package_init(package)
    package:declare_package_id(
        "com.ShaDis.CardBN6.189"
    )

    package:set_icon_texture(
        Engine.load_texture(
            _folderpath.."icon.png"
        )
    )

    package:set_preview_texture(
        Engine.load_texture(
            _folderpath.."preview.png"
        )
    )

    package:set_codes({
        'G',
        'R',
        'V',
        '*'
    })

    local props =
        package:get_card_props()

    props.shortname = "AntiDmg"
    props.damage = 100
    props.time_freeze = true
    props.element = Element.None
    props.description =
        "Sets trap and throw a star"

    props.limit = 3
    props.card_class =
        CardClass.Standard
end


-- ============================================================================
-- Card action / trap
-- ============================================================================

function card_create_action(
    user,
    props
)
    local action =
        Battle.CardAction.new(
            user,
            "PLAYER_IDLE"
        )

    local new_props =
        action:copy_metadata()

    new_props.shortname = "????"

    action:set_metadata(
        new_props
    )

    action:set_lockout(
        make_sequence_lockout()
    )

    action.execute_func =
        function(self, user)
            local step1 =
                Battle.Step.new()

            local antidamage_rule =
                Battle.DefenseRule.new(
                    777,
                    DefenseOrder.CollisionOnly
                )

            antidamage_rule.has_blocked =
                false

            local field =
                user:get_field()

            antidamage_rule.can_block_func =
                function(
                    judge,
                    attacker,
                    defender
                )
                    local hit_props =
                        attacker:copy_hit_props()

                    local temp_action =
                        poof_user(
                            user,

                            field:get_entity(
                                hit_props.aggressor
                            ),

                            props
                        )

                    if temp_action ~= nil then
                        antidamage_rule.second_action =
                            temp_action
                    else
                        return
                    end


                    -- Cursor removes AntiDmg without triggering it.
                    if hit_props.element
                        == Element.Cursor
                    then
                        defender:remove_defense_rule(
                            antidamage_rule
                        )

                        return
                    end


                    if hit_props.damage >= 10 then
                        judge:block_damage()

                        if not antidamage_rule.has_blocked then
                            local player =
                                Battle.Player.from(
                                    defender
                                )

                            antidmg_log(
                                "AntiDmg triggered"
                            )

                            antidmg_log(
                                "before queue: can_attack = "
                                .. tostring(
                                    player:can_attack()
                                )
                            )

                            player:card_action_event(
                                antidamage_rule.second_action,
                                ActionOrder.Involuntary
                            )

                            antidmg_log(
                                "shuriken action queued"
                            )

                            antidmg_log(
                                "after queue: can_attack = "
                                .. tostring(
                                    player:can_attack()
                                )
                            )

                            defender:remove_defense_rule(
                                antidamage_rule
                            )
                        end
                    end
                end


            step1.update_func =
                function(self, dt)
                    user:add_defense_rule(
                        antidamage_rule
                    )

                    self:complete_step()
                end

            self:add_step(step1)
        end

    return action
end