local sword = include("sword/sword.lua")

local DAMAGE = 160

sword.palette = "aqua"
sword.elem = Element.Aqua
sword.type = "0"

sword.codes = {"A","I","Y"}
sword.shortname = "AquaSwrd"
sword.damage = DAMAGE
sword.time_freeze = false
sword.element = Element.Aqua
sword.description = "Aqua swrd\nthat cuts\n3sq fwrd!"
sword.long_description = "An Aqua sword that cuts 3 vertical squares in front!"
sword.can_boost = true
sword.card_class = CardClass.Standard
sword.limit = 3
sword.mb = 32

function package_init(package)
    package:declare_package_id("com.OFC.card.EXE6-076-AquaSword")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes(sword.codes)

    local props = package:get_card_props()
    props.shortname = sword.shortname
    props.damage = sword.damage
    props.time_freeze = sword.time_freeze
    props.element = sword.element
    props.description = sword.description
    props.long_description = sword.long_description
    props.can_boost = sword.can_boost
	props.card_class = sword.card_class
	props.limit = sword.limit
end

card_create_action = sword.card_create_action