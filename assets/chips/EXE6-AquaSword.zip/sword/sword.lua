local print_debug = false

local AUDIO_DAMAGE_ENEMY = Engine.load_audio(_folderpath.."sfx/EXE6_50.ogg", true)
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."sfx/EXE6_131.ogg", true)

local SWORD_TEXTURE = Engine.load_texture(_folderpath.."gfx/sword.png")
local SWORD_ANIMPATH = _folderpath.."gfx/sword.animation"
local SLASH_TEXTURE = Engine.load_texture(_folderpath.."gfx/slash.grayscaled.png")
local SLASH_ANIMPATH = _folderpath.."gfx/slash.animation"

local SLASH_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_247.ogg", true)

local function debug_print(text)
    if print_debug then
        print("[Sword] "..text)
    end
end

local sword = {}

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function create_slash_hitbox(user, damage, tile)
    if not tile or tile:is_edge() then return end
    local facing = user:get_facing()
    local field = user:get_field()
    local team = user:get_team()
	local hitbox = Battle.Spell.new(team)
    hitbox:set_facing(facing)
    if sword.elem == Element.Elec then
        hitbox:set_hit_props(
	    	HitProps.new()
            :dmg(damage)
            :impact()
            :flinch()
            :stun(frames(90))
            :elem(Element.Elec)
            :elem2(Element.Sword)
            :from(user:get_context())
	    )
    elseif sword.elem == Element.Wood then
        hitbox:set_hit_props(
	    	HitProps.new()
            :dmg(damage)
            :impact()
            :flinch()
            :elem(Element.Wood)
            :elem2(Element.Sword)
            :from(user:get_context())
	    )
    else
        hitbox:set_hit_props(
	    	HitProps.new()
            :dmg(damage)
            :impact()
            :flinch()
            :flash()
            :elem(sword.elem)
            :elem2(Element.Sword)
            :from(user:get_context())
	    )
    end
    hitbox.on_spawn_func = function()
        debug_print("attack spawned at tile ("..tile:x()..";"..tile:y()..")")
    end
	hitbox.update_func = function(self)
		tile:attack_entities(self)
		self:erase()
	end
    hitbox.attack_func = function(self, other)
        if not other:get_animation():has_state("HITSOUND_N") and #other:sprite():find_child_nodes_with_tags({"IS_BARRIER"}) <= 0 then
            if not other:get_animation():has_state("HITSOUND_C") and not other:get_animation():has_state("HITSOUND_O") then
    	        if Battle.Obstacle.from(other) == nil then
                    if Battle.Player.from(user) ~= nil then
    	            	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
    	            end
                else
    	        	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
    	        end
            else
                if other:get_animation():has_state("HITSOUND_C") then
    	            if Battle.Player.from(user) ~= nil then
    	            	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
    	            end
    	        end
    	        if other:get_animation():has_state("HITSOUND_O") then
    	        	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
    	        end
            end
    	end
    end
	field:spawn(hitbox, tile)
	return hitbox
end

local function create_slash(user, damage, tile)
    if not tile or tile:is_edge() then return end
    local facing = user:get_facing()
    local field = user:get_field()
    local palette = Engine.load_texture(_folderpath.."gfx/palette/palette_"..sword.palette..".png")
	local slash_fx = graphic_init("artifact", 0, (-16*2), SLASH_TEXTURE, palette, SLASH_ANIMPATH, -3, sword.type, Playback.Once, user, facing, true, true)
	field:spawn(slash_fx, tile)
    if sword.type == "0" then
        for i=-1,1 do
            create_slash_hitbox(user, damage, field:tile_at(tile:x(), tile:y()+i))
        end
    elseif sword.type == "1" then
        create_slash_hitbox(user, damage, tile)
        create_slash_hitbox(user, damage, tile:get_tile(facing, 1))
    elseif sword.type == "2" then
        create_slash_hitbox(user, damage, tile)
    elseif sword.type == "3" then
        for i=1,3 do
            create_slash_hitbox(user, damage, tile:get_tile(facing, i))
        end
    end
end

sword.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_SWORD")
    local frame1 = {1,0.117} --(+)1 frame
    local frame2 = {2,0.017}
    local frame3 = {2,0.017}
    local frame4 = {3,0.033}
    local frame5 = {4,0.067}
    local frame6 = {4,0.2} --(-)1 frame
    local frame_sequence = make_frame_data({frame1, frame2, frame3, frame4, frame5, frame6})
    action:override_animation_frames(frame_sequence)
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        Engine.play_audio(SLASH_AUDIO, AudioPriority.Low)
        user:toggle_counter(true)
		self:add_anim_action(2, function()
            local hilt = self:add_attachment("HILT")
            local hilt_sprite = hilt:sprite()
            hilt_sprite:set_texture(user:get_texture(), true)
            hilt_sprite:set_layer(-1)
            hilt_sprite:enable_parent_shader(true)
            local hilt_anim = hilt:get_animation()
            hilt_anim:copy_from(user:get_animation())
            hilt_anim:set_state("HILT")
            hilt_anim:refresh(hilt_sprite)
            local anim_state = nil
            if sword.elem == Element.Fire then
                anim_state = "1"
            elseif sword.elem == Element.Aqua then
                anim_state = "2"
            elseif sword.elem == Element.Elec then
                anim_state = "3"
            elseif sword.elem == Element.Wood then
                anim_state = "4"
            else
                anim_state = "0"
            end
            local blade = hilt:add_attachment("ENDPOINT")
            local blade_sprite = blade:sprite()
            blade_sprite:set_texture(SWORD_TEXTURE, true)
            blade_sprite:set_layer(-2)
            local blade_anim = blade:get_animation()
            blade_anim:load(SWORD_ANIMPATH)
            blade_anim:set_state(anim_state)
            blade_anim:refresh(blade_sprite)
        end)
		self:add_anim_action(3,function()
            create_slash(user, props.damage, user:get_tile(user:get_facing(), 1))
		end)
		self:add_anim_action(6,function()
			user:toggle_counter(false)
		end)
	end
	action.action_end_func = function()
		user:toggle_counter(false)
	end
    return action
end

return sword