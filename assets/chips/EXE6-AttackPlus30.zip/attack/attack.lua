-- TODO: should use chip icon position.

local print_debug = false

local SMOKE_TEXTURE = Engine.load_texture(_folderpath.."gfx/smoke.grayscaled.png")
local SMOKE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/smoke.png")
local SMOKE_ANIMPATH = _folderpath.."gfx/smoke.animation"
local SMOKE_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_264.ogg", true)

local function debug_print(text)
    if print_debug then
        print("[Attack+] "..text)
    end
end

local attack = {}

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

attack.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
	action:set_lockout(make_async_lockout(0.333))
    local frame_sequence = make_frame_data({{1,0.017}})
	action:override_animation_frames(frame_sequence)
	action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        local smoke_fx = graphic_init("artifact", -4*2, 0, SMOKE_TEXTURE, SMOKE_PALETTE, SMOKE_ANIMPATH, -99, "1", Playback.Once, user, user:get_facing(), true, true, true)
        smoke_fx:set_elevation(user:get_height()*2+4*2)
        smoke_fx.update_func = function(self)
            smoke_fx:set_elevation(smoke_fx:get_elevation()+(2*2))
        end
        user:get_field():spawn(smoke_fx, user:get_tile())
        Engine.play_audio(SMOKE_AUDIO, AudioPriority.Immediate)
	end
	return action
end

return attack