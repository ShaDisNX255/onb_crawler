local attack = include("attack/attack.lua")

local DAMAGE = 0

attack.multiplier = 30

attack.codes = {"*"}
attack.shortname = "Atk+30"
attack.damage = DAMAGE
attack.time_freeze = false
attack.element = Element.Plus
attack.description = "+30 for\nselected\natk chip"
attack.long_description = "+30 attack power if selected after the attack chip"
attack.can_boost = false
attack.card_class = CardClass.Standard
attack.limit = 1
attack.mb = 66

function package_init(package) 
    package:declare_package_id("com.OFC.card.EXE6-197-Attack+30")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(attack.codes)

    local props = package:get_card_props()
    props.shortname = attack.shortname
    props.damage = attack.damage
    props.time_freeze = attack.time_freeze
    props.element = attack.element
    props.description = attack.description
    props.long_description = attack.long_description
    props.can_boost = attack.can_boost
	props.card_class = attack.card_class
	props.limit = attack.limit

    package.filter_hand_step = function(in_props, adj_cards) 
        if adj_cards:has_card_to_left() and adj_cards.left_card.can_boost then
            adj_cards.left_card.damage = adj_cards.left_card.damage + attack.multiplier
            adj_cards:discard_incoming()
        end
	end
end

card_create_action = attack.card_create_action