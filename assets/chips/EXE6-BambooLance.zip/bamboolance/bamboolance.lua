local print_debug = false

local BAMBOOLANCE_TEXTURE = Engine.load_texture(_folderpath.."gfx/bamboolance.grayscaled.png") -- flip for Player 2?
local BAMBOOLANCE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/bamboolance.png")
local BAMBOOLANCE_ANIMPATH = _folderpath.."gfx/bamboolance.animation"
local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect.grayscaled.png")
local EFFECT_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect.png")
local EFFECT_ANIMPATH = _folderpath.."gfx/effect.animation"

local BAMBOOLANCE_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_247.ogg", true)

local function debug_print(text)
    if print_debug then
        print("[BambooLance] "..text)
    end
end

local bamboolance = {}

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function create_hitbox(user, props, tile, facing)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(facing)
    spell:set_hit_props(
        HitProps.new()
        :dmg(props.damage)
        :impact()
        :flinch()
        :drg(Drag.new(facing, 1))
        :elem(props.element)
        :from(user:get_context())
    )
    spell.update_func = function(self)
        tile:attack_entities(self)
        self:erase()
    end
    spell.attack_func = function(self, other, judge)
        debug_print("attacked tile ("..other:get_tile():x()..";"..other:get_tile():y()..")")
        if not judge:hint_spawn_gfx() then return end
        local offset_x = math.random(-9,8)
        local offset_y = math.random(-7,2)
        local hit_fx = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT_TEXTURE, EFFECT_PALETTE, EFFECT_ANIMPATH, -999, "0", Playback.Once, user, facing, true, true, true)
        user:get_field():spawn(hit_effect, self:get_tile())
    end
    user:get_field():spawn(spell, tile)
    return spell
end

local function create_bamboolance(user, props, tile, facing)
    local offset_x = tile:width()/2
    local spell = graphic_init("spell", offset_x, 0, BAMBOOLANCE_TEXTURE, BAMBOOLANCE_PALETTE, BAMBOOLANCE_ANIMPATH, -3, "0", Playback.Once, user, facing, true)
    spell:get_animation():on_frame(6, function()
        create_hitbox(user, props, tile, facing)
    end)
    spell.on_spawn_func = function(self)
		debug_print("spawned on tile ("..tile:x()..";"..tile:y()..")")
        Engine.play_audio(BAMBOOLANCE_AUDIO, AudioPriority.Immediate)
    end
    user:get_field():spawn(spell, tile)
    return spell
end

bamboolance.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
	action:set_lockout(make_async_lockout(0.167))
    local frame_sequence = make_frame_data({{1,0.0}})
	action:override_animation_frames(frame_sequence)
    action.execute_func = function(self, user)
		debug_print("in custom card action execute_func()!")
        local field = user:get_field()
        for j=1, 3 do
            local tile = field:tile_at(field:width(), j)
            if user:get_facing() == Direction.Left then
                tile = field:tile_at(1, j)
            end
            create_bamboolance(user, props, tile, user:get_facing_away())
        end
    end
    return action
end

return bamboolance