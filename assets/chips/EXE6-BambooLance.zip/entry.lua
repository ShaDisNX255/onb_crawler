local bamboolance = include("bamboolance/bamboolance.lua")

local DAMAGE = 150

bamboolance.codes = {"A","R","W","*"}
bamboolance.shortname = "BambLanc"
bamboolance.damage = DAMAGE
bamboolance.time_freeze = false
bamboolance.element = Element.Wood
bamboolance.description = "BmbSpears\nappear on\nback line"
bamboolance.long_description = "Bamboo spears suddenly appear on the right side of the enemy area!"
bamboolance.can_boost = true
bamboolance.card_class = CardClass.Standard
bamboolance.limit = 2
bamboolance.mb = 42

function package_init(package)
    package:declare_package_id("com.OFC.card.EXE6-122-BambooLance")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes(bamboolance.codes)

    local props = package:get_card_props()
    props.shortname = bamboolance.shortname
    props.damage = bamboolance.damage
    props.time_freeze = bamboolance.time_freeze
    props.element = bamboolance.element
    props.description = bamboolance.description
    props.long_description = bamboolance.long_description
    props.can_boost = bamboolance.can_boost
	props.card_class = bamboolance.card_class
	props.limit = bamboolance.limit
end

card_create_action = bamboolance.card_create_action