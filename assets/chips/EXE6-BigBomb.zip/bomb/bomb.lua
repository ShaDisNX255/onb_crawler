local debug = false

local DAMAGE = 140

local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."EXE6_50.ogg")
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."EXE6_131.ogg")
local TESTDOT_SPRITE = Engine.load_texture(_folderpath.."testdot.png")
local TESTDOT_ANIMPATH = _folderpath.."testdot.animation"

local attachment_texture = Engine.load_texture(_folderpath.."attachment.png")
local attachment_animation_path = _folderpath.."attachment.animation"
local explosion_texture = Engine.load_texture(_folderpath.."explosion.png")
local explosion_sfx = Engine.load_audio(_folderpath.."EXE6_132.ogg")
local explosion_animation_path = _folderpath.."explosion.animation"
local throw_sfx = Engine.load_audio(_folderpath.."EXE6_118.ogg")
local shadow_texture = Engine.load_texture(_folderpath.."shadow.png")
local shadow_animation_path = _folderpath.."shadow.animation"
local smoke_texture = Engine.load_texture(_folderpath.."smoke.png")
local smoke_animation_path = _folderpath.."smoke.animation"

function debug_print(text)
    if debug then
        print("[bigbomb] " .. text)
    end
end

local bomb = {
    codes = {"O","P","V"},
    shortname = "BigBomb",
    damage = DAMAGE,
    time_freeze = false,
    element = Element.None,
    description = "Throw a 9sq Bomb 3sq fwd!",
    long_description = "Throw a Bomb that blasts 9 squares, 3 squares ahead!",
    can_boost = true,
    card_class = CardClass.Standard,
    limit = 3,
    mb = 32
}

bomb.card_create_action = function(user,props)
    local action = Battle.CardAction.new(user, "PLAYER_THROW")
	action:set_lockout(make_animation_lockout())
    local override_frames = {{1,0.084},{2,0.068},{3,0.050},{4,0.084},{5,0.068}}
    local frame_data = make_frame_data(override_frames)
    action:override_animation_frames(frame_data)

    local hit_props = HitProps.new(
        props.damage,
        Hit.Impact | Hit.Flinch | Hit.Flash, 
        props.element,
        user:get_context(),
        Drag.None
    )

    action.execute_func = function(self, user)
        --local props = self:copy_metadata()
        local attachment = self:add_attachment("HAND")
        local attachment_sprite = attachment:sprite()
        attachment_sprite:set_texture(attachment_texture)
        attachment_sprite:set_layer(-2)

        local attachment_animation = attachment:get_animation()
        attachment_animation:load(attachment_animation_path)
        attachment_animation:set_state("DEFAULT")

        user:toggle_counter(true)
        self:add_anim_action(3,function()
            attachment_sprite:hide()
            --self.remove_attachment(attachment)
            local tiles_ahead = 3
            local frames_in_air = 40
            local toss_height = 70
            local field = user:get_field()
            local facing = user:get_facing()
            local target_tile = user:get_tile(facing,tiles_ahead)
            if not target_tile then
                return
            end
            action.on_landing = function()
                if target_tile:is_walkable() then
                    local tile = target_tile
                    create_effect(Direction.Right, explosion_texture, explosion_animation_path, "0", 0.0, -((3.0)*2), -99999, field, tile)
                    hit_explosion(user,tile,hit_props,TESTDOT_SPRITE,TESTDOT_ANIMPATH,explosion_sfx)
                    local tile = target_tile:get_tile(Direction.Up, 1)
                    create_effect(Direction.Right, explosion_texture, explosion_animation_path, "0", 0.0, -((3.0)*2), -99999, field, tile)
                    hit_explosion(user,tile,hit_props,TESTDOT_SPRITE,TESTDOT_ANIMPATH,explosion_sfx)
                    local tile = target_tile:get_tile(Direction.Down, 1)
                    create_effect(Direction.Right, explosion_texture, explosion_animation_path, "0", 0.0, -((3.0)*2), -99999, field, tile)
                    hit_explosion(user,tile,hit_props,TESTDOT_SPRITE,TESTDOT_ANIMPATH,explosion_sfx)
                    local tile = target_tile:get_tile(Direction.Left, 1)
                    create_effect(Direction.Right, explosion_texture, explosion_animation_path, "0", 0.0, -((3.0)*2), -99999, field, tile)
                    hit_explosion(user,tile,hit_props,TESTDOT_SPRITE,TESTDOT_ANIMPATH,explosion_sfx)
                    local tile = target_tile:get_tile(Direction.Right, 1)
                    create_effect(Direction.Right, explosion_texture, explosion_animation_path, "0", 0.0, -((3.0)*2), -99999, field, tile)
                    hit_explosion(user,tile,hit_props,TESTDOT_SPRITE,TESTDOT_ANIMPATH,explosion_sfx)
                    local tile = target_tile:get_tile(Direction.UpLeft, 1)
                    create_effect(Direction.Right, explosion_texture, explosion_animation_path, "0", 0.0, -((3.0)*2), -99999, field, tile)
                    hit_explosion(user,tile,hit_props,TESTDOT_SPRITE,TESTDOT_ANIMPATH,explosion_sfx)
                    local tile = target_tile:get_tile(Direction.UpRight, 1)
                    create_effect(Direction.Right, explosion_texture, explosion_animation_path, "0", 0.0, -((3.0)*2), -99999, field, tile)
                    hit_explosion(user,tile,hit_props,TESTDOT_SPRITE,TESTDOT_ANIMPATH,explosion_sfx)
                    local tile = target_tile:get_tile(Direction.DownLeft, 1)
                    create_effect(Direction.Right, explosion_texture, explosion_animation_path, "0", 0.0, -((3.0)*2), -99999, field, tile)
                    hit_explosion(user,tile,hit_props,TESTDOT_SPRITE,TESTDOT_ANIMPATH,explosion_sfx)
                    local tile = target_tile:get_tile(Direction.DownRight, 1)
                    create_effect(Direction.Right, explosion_texture, explosion_animation_path, "0", 0.0, -((3.0)*2), -99999, field, tile)
                    hit_explosion(user,tile,hit_props,TESTDOT_SPRITE,TESTDOT_ANIMPATH,explosion_sfx)
                else
                    create_effect(Direction.Right, smoke_texture, smoke_animation_path, "0", 0.0, -((3.0)*2), -99999, field, target_tile)
                end
            end
            toss_spell(user,toss_height,attachment_texture,attachment_animation_path,target_tile,frames_in_air,action.on_landing)
            toss_spell2(user,toss_height,shadow_texture,shadow_animation_path,target_tile)
		end)
        self:add_anim_action(4,function()
            user:toggle_counter(false)
		end)
        self.action_end_func = function()
            user:toggle_counter(false)
        end

        Engine.play_audio(throw_sfx, AudioPriority.Highest)
    end
    return action
end

function toss_spell(tosser,toss_height,texture,animation_path,target_tile,frames_in_air,arrival_callback)
    local starting_height = -110
    local start_tile = tosser:get_current_tile()
    local field = tosser:get_field()
    local spell = Battle.Spell.new(tosser:get_team())
    local spell_animation = spell:get_animation()
    spell_animation:load(animation_path)
    spell_animation:set_state("DEFAULT")
    if tosser:get_height() > 1 then
        starting_height = -(tosser:get_height()*2)
    end

    spell.jump_started = false
    spell.starting_y_offset = starting_height
    spell.starting_x_offset = 10
    if tosser:get_facing() == Direction.Left then
        spell.starting_x_offset = -10
    end
    spell.y_offset = spell.starting_y_offset
    spell.x_offset = spell.starting_x_offset
    local sprite = spell:sprite()
    sprite:set_texture(texture)
    spell:set_offset(spell.x_offset,spell.y_offset)

    spell.update_func = function(self)
        if not spell.jump_started then
            self:jump(target_tile, toss_height, frames(frames_in_air), frames(frames_in_air), ActionOrder.Voluntary)
            self.jump_started = true
        end
        if self.y_offset < 0 then
            self.y_offset = self.y_offset + math.abs(self.starting_y_offset/frames_in_air)
            self.x_offset = self.x_offset - math.abs(self.starting_x_offset/frames_in_air)
            self:set_offset(0,self.y_offset)
        else
            arrival_callback()
            self:delete()
        end
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    field:spawn(spell, start_tile)
end

function toss_spell2(tosser,toss_height,texture,animation_path,target_tile)
    local starting_height1 = -80
    local frames_in_air1 = 40
    local starting_height2 = 60
    local frames_in_air2 = 40
    local start_tile = tosser:get_current_tile()
    local field = tosser:get_field()
    local spell = Battle.Spell.new(tosser:get_team())
    local spell_animation = spell:get_animation()
    spell_animation:load(animation_path)
    spell_animation:set_state("0")
    if tosser:get_height() > 1 then
        starting_height1 = -(tosser:get_height()*2)
    end

    spell.slide_started = false

    spell.jump_started = false
    --spell.starting_y_offset = starting_height
    spell.starting_y_offset = starting_height2
    spell.starting_x_offset = 10
    if tosser:get_facing() == Direction.Left then
        spell.starting_x_offset = -10
    end
    --spell.y_offset = spell.starting_y_offset
    spell.y_offset = spell.starting_x_offset
    spell.x_offset = spell.starting_x_offset
    local sprite = spell:sprite()
    sprite:set_texture(texture)
    spell:set_offset(spell.x_offset,0)

    spell.update_func = function(self)
        if not spell.jump_started then
            self:jump(target_tile, 0, frames(frames_in_air1), frames(frames_in_air1), ActionOrder.Voluntary)
            self.jump_started = true
        end
        if self.x_offset > 0 then
            self.y_offset = (self.y_offset + math.abs(self.starting_y_offset/frames_in_air2))
            --self.y_offset = 0
            self.x_offset = self.x_offset - math.abs(self.starting_x_offset/frames_in_air1)
            --self:set_offset(0,self.y_offset)
            self:set_offset(self.x_offset,0)
        else
            self:delete()
        end
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    field:spawn(spell, start_tile)
end

function hit_explosion(user,target_tile,props,texture,anim_path,explosion_sound)
    local field = user:get_field()
    local spell = Battle.Spell.new(user:get_team())

    local spell_animation = spell:get_animation()
    spell_animation:load(anim_path)
    spell_animation:set_state("0")
    --[[local sprite = spell:sprite()
    sprite:set_texture(texture)
    spell_animation:refresh(sprite)]]

    spell_animation:on_complete(function()
		spell:erase()
	end)

    spell:set_hit_props(props)
    spell.has_attacked = false
    spell.update_func = function(self)
        if not spell.has_attacked then
            Engine.play_audio(explosion_sound, AudioPriority.High)
            spell:get_current_tile():attack_entities(self)
            spell.has_attacked = true
        end
    end
    spell.attack_func = function(self, ent)
        if not antiaura then
            if Battle.Obstacle.from(ent) == nil then
                if Battle.Player.from(user) ~= nil then
                    Engine.play_audio(AUDIO_DAMAGE, AudioPriority.High)
                end
            else
                Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.High)
            end
        end
    end
    field:spawn(spell, target_tile)
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end

return bomb