local bomb = include("bomb/bomb.lua")

local DAMAGE = 140

bomb.codes = {"O","P","V"}
bomb.shortname = "BigBomb"
bomb.damage = DAMAGE
bomb.time_freeze = false
bomb.element = Element.None
bomb.description = "Throw a 9sq Bomb 3sq fwd!"
bomb.long_description = "Throw a Bomb that blasts 9 squares, 3 squares ahead!"
bomb.can_boost = true
bomb.card_class = CardClass.Standard
bomb.limit = 3
bomb.mb = 32

function package_init(package)
    package:declare_package_id("com.ipc.k1rbyat1na.card.EXE6-059-BigBomb")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes(bomb.codes)

    local props = package:get_card_props()
    props.shortname = bomb.shortname
    props.damage = bomb.damage
    props.time_freeze = bomb.time_freeze
    props.element = bomb.element
    props.description = bomb.description
    props.long_description = bomb.long_description
    props.can_boost = bomb.can_boost
	props.card_class = bomb.card_class
	props.limit = bomb.limit
end

card_create_action = bomb.card_create_action