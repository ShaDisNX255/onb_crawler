local burnsquare = include("burnsquare/burnsquare.lua")

local DAMAGE = 120

burnsquare.codes = {"D","M","T"}
burnsquare.shortname = "BurnSqr2"
burnsquare.damage = DAMAGE
burnsquare.time_freeze = true
burnsquare.element = Element.Fire
burnsquare.description = "Press A to\nburn a\n4sq area!"
burnsquare.long_description = "Press A button to stop the sight in a 4-square area and attack with flames!"
burnsquare.can_boost = true
burnsquare.card_class = CardClass.Standard
burnsquare.limit = 3
burnsquare.mb = 30

function package_init(package)
    package:declare_package_id("com.OFC.card.EXE6-109-BurnSquare2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes(burnsquare.codes)

    local props = package:get_card_props()
    props.shortname = burnsquare.shortname
    props.damage = burnsquare.damage
    props.time_freeze = burnsquare.time_freeze
    props.element = burnsquare.element
    props.description = burnsquare.description
    props.long_description = burnsquare.long_description
    props.can_boost = burnsquare.can_boost
	props.card_class = burnsquare.card_class
	props.limit = burnsquare.limit
end

card_create_action = burnsquare.card_create_action