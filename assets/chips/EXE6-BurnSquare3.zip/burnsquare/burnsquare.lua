local print_debug = false

local CURSOR_TEXTURE = Engine.load_texture(_folderpath.."gfx/cursor.grayscaled.png") -- flip for Player 2?
local CURSOR_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/cursor.png")
local CURSOR_ANIMPATH = _folderpath.."gfx/cursor.animation"
local FLAMETOWER_TEXTURE = Engine.load_texture(_folderpath.."gfx/flametower.grayscaled.png") -- flip for Player 2?
local FLAMETOWER_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/flametower.png")
local FLAMETOWER_ANIMPATH = _folderpath.."gfx/flametower.animation"
local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect.grayscaled.png") -- flip for Player 2?
local EFFECT_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect.png")
local EFFECT_ANIMPATH = _folderpath.."gfx/effect.animation"

local CURSOR_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_211.ogg", true)
local LOCKON_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_103.ogg", true)
local FLAMETOWER_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_268.ogg", true)

local function debug_print(text)
    if print_debug then
        print("[BurnSquare] "..text)
    end
end

local burnsquare = {}

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function create_flametower(user, props, team, facing, field, tile)
    local query = function(e)
        return e:get_health() > 0 and not e:is_team(team)
    end
    if not tile or tile:is_hole() then return end
    local tower = graphic_init("spell", 0, 0, FLAMETOWER_TEXTURE, FLAMETOWER_PALETTE, FLAMETOWER_ANIMPATH, -3, "0", Playback.Once, user, facing, false, true, true)
    tower:set_hit_props(
        HitProps.new()
        :dmg(props.damage)
        :impact()
        :flinch()
        :flash()
        :pierce_ground()
        :retangible()
        :no_counter()
        :elem(props.element)
        :from(user:get_context())
    )
    tower.frames = 1
    tower.on_spawn_func = function(self)
	    Engine.play_audio(FLAMETOWER_AUDIO, AudioPriority.Immediate)
    end
    tower.update_func = function(self)
        self:get_tile():attack_entities(self)
        if self.frames == 8 then
            self:get_animation():set_state("1")
            self:get_animation():set_playback(Playback.Loop)
            self:get_animation():refresh(self:sprite())
        elseif self.frames == 34 then
            self:get_animation():set_state("2")
            self:get_animation():refresh(self:sprite())
        elseif self.frames >= 37 then
            self:erase()
        end
        self.frames = self.frames + 1
    end
    tower.attack_func = function(self, other, judge)
		debug_print("attacked tile ("..other:get_tile():x()..";"..other:get_tile():y()..")")
        if not judge:hint_spawn_gfx() then return end
        local offset_y = math.random(-8,5)
        local offset_x = math.random(-7,6)
        local hit_effect = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT_TEXTURE, EFFECT_PALETTE, EFFECT_ANIMPATH, -999, "0", Playback.Once, user, facing, true, true, true)
        field:spawn(hit_effect, other:get_tile())
	end
    tower.battle_end_func = function(self)
        self:erase()
    end
    field:spawn(tower, tile)
end

burnsquare.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
    action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        local actor = self:get_actor()
        local orig_speed = actor:get_animation():get_playback_speed()
        actor:get_animation():set_playback_speed(0)
        
		local facing = user:get_facing()
        local field = user:get_field()
		local team = user:get_team()
        local a_state = "SEARCH"
		local a_frames = 0
		local step1 = Battle.Step.new()

        local corner_tile = field:width()
        local corner_tile2 = -1
        if facing == Direction.Left then
            corner_tile = 1
            corner_tile2 = 1
        end
        local cursor1 = graphic_init("artifact", 0, 0, CURSOR_TEXTURE, CURSOR_PALETTE, CURSOR_ANIMPATH, -3, "0", Playback.Loop, user, facing, false, false, true)
        cursor1:set_float_shoe(true)
        cursor1:set_air_shoe(true)
        cursor1.can_move_to_func = function(tile)
            return true
        end
        field:spawn(cursor1, field:tile_at(corner_tile, 1))
        local cursor2 = graphic_init("artifact", 0, 0, CURSOR_TEXTURE, CURSOR_PALETTE, CURSOR_ANIMPATH, -3, "0", Playback.Loop, user, facing, false, false, true)
        cursor2:set_float_shoe(true)
        cursor2:set_air_shoe(true)
        cursor2.can_move_to_func = function(tile)
            return true
        end
        field:spawn(cursor2, field:tile_at(corner_tile, 2))
        local cursor3 = graphic_init("artifact", 0, 0, CURSOR_TEXTURE, CURSOR_PALETTE, CURSOR_ANIMPATH, -3, "0", Playback.Loop, user, facing, false, false, true)
        cursor3:set_float_shoe(true)
        cursor3:set_air_shoe(true)
        cursor3.can_move_to_func = function(tile)
            return true
        end
        field:spawn(cursor3, field:tile_at(corner_tile+corner_tile2, 1))
        local cursor4 = graphic_init("artifact", 0, 0, CURSOR_TEXTURE, CURSOR_PALETTE, CURSOR_ANIMPATH, -3, "0", Playback.Loop, user, facing, false, false, true)
        cursor4:set_float_shoe(true)
        cursor4:set_air_shoe(true)
        cursor4.can_move_to_func = function(tile)
            return true
        end
        field:spawn(cursor4, field:tile_at(corner_tile+corner_tile2, 2))
        local cursor_dir_table = {
            [1] = Direction.Down,
            [2] = Direction.reverse(facing),
            [3] = Direction.Up,
            [4] = facing
        }
        local cursor_dir_index = 1
        local cursor_dir = Direction.Down
        local cursor_delay = 6
        local cursor_times = 49

		Engine.play_audio(CURSOR_AUDIO, AudioPriority.Immediate)
		local stuntDouble = self:get_actor()
        step1.update_func = function(self)
            a_frames = a_frames + 1
            if a_state == "SEARCH" then
                if user:input_has(Input.Pressed.Use) or (cursor_times <= 0 and a_frames == cursor_delay-1) then
                    cursor1:hide()
                    cursor2:hide()
                    cursor3:hide()
                    cursor4:hide()
		            Engine.play_audio(LOCKON_AUDIO, AudioPriority.Immediate)
                    a_state = "ATTACK"
                    a_frames = 0
                end
                if a_frames >= cursor_delay then
                    if cursor1:get_tile(cursor_dir_table[cursor_dir_index], 1):is_edge() or cursor2:get_tile(cursor_dir_table[cursor_dir_index], 1):is_edge() or cursor3:get_tile(cursor_dir_table[cursor_dir_index], 1):is_edge() or cursor4:get_tile(cursor_dir_table[cursor_dir_index], 1):is_edge() then
                        cursor_dir_index = cursor_dir_index + 1
                        if cursor_dir_index > #cursor_dir_table then cursor_dir_index = 1 end
                    end
                    cursor1:teleport(cursor1:get_tile(cursor_dir_table[cursor_dir_index], 1), ActionOrder.Immediate)
                    cursor2:teleport(cursor2:get_tile(cursor_dir_table[cursor_dir_index], 1), ActionOrder.Immediate)
                    cursor3:teleport(cursor3:get_tile(cursor_dir_table[cursor_dir_index], 1), ActionOrder.Immediate)
                    cursor4:teleport(cursor4:get_tile(cursor_dir_table[cursor_dir_index], 1), ActionOrder.Immediate)
		            Engine.play_audio(CURSOR_AUDIO, AudioPriority.Immediate)
                    cursor_times = cursor_times - 1
                    a_frames = 0
                end
            elseif a_state == "ATTACK" then
                for i=1, 13 do
                    if a_frames == i then
                        cursor1:get_tile():highlight(Highlight.Flash)
                        cursor2:get_tile():highlight(Highlight.Flash)
                        cursor3:get_tile():highlight(Highlight.Flash)
                        cursor4:get_tile():highlight(Highlight.Flash)
                    end
                end
                if a_frames == 14 then
                    cursor1:get_tile():highlight(Highlight.Solid)
                    cursor2:get_tile():highlight(Highlight.Solid)
                    cursor3:get_tile():highlight(Highlight.Solid)
                    cursor4:get_tile():highlight(Highlight.Solid)
                    actor:get_animation():set_playback_speed(orig_speed)
			    	actor:get_animation():set_state("PLAYER_SWORD")
			    	actor:get_animation():on_frame(2, function()
			    		local hilt = action:add_attachment("HILT")
			    		local hilt_sprite = hilt:sprite()
			    		hilt_sprite:set_texture(actor:get_texture())
			    		hilt_sprite:set_layer(-2)
			    		hilt_sprite:enable_parent_shader(true)
			    		local hilt_anim = hilt:get_animation()
			    		hilt_anim:copy_from(actor:get_animation())
			    		hilt_anim:set_state("HAND")
			    		hilt_anim:refresh(hilt_sprite)
			    	end)
			    	actor:get_animation():on_frame(3, function()
                        create_flametower(user, props, team, facing, field, cursor1:get_tile())
                        create_flametower(user, props, team, facing, field, cursor2:get_tile())
                        create_flametower(user, props, team, facing, field, cursor3:get_tile())
                        create_flametower(user, props, team, facing, field, cursor4:get_tile())
                        cursor1:erase()
                        cursor2:erase()
                        cursor3:erase()
                        cursor4:erase()
			    	end)
                elseif a_frames >= 80 then
                    actor:get_animation():set_playback_speed(orig_speed)
                    self:complete_step()
                end
            end
        end
		self:add_step(step1)
    end
    return action
end

return burnsquare