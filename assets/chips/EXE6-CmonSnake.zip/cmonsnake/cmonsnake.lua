local print_debug = false

local SNAKE_TEXTURE = Engine.load_texture(_folderpath.."gfx/snake.grayscaled.png")
local SNAKE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/snake.png")
local SNAKE_ANIMPATH = _folderpath.."gfx/snake.animation"

local BURST_TEXTURE = Engine.load_texture(_folderpath.."gfx/burst.grayscaled.png")
local BURST_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/burst.png")
local BURST_ANIMPATH = _folderpath.."gfx/burst.animation"

local SPAWN_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_65.ogg", true)
local SNAKE_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_224.ogg", true)

local function debug_print(text)
    if print_debug then
        print("[CmonSnake] "..text)
    end
end

local cmonsnake = {}

--(Function by Alrysc)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function create_snake(user, props, facing, field, team, tile)
    local snake = graphic_init("spell", 0, 0, SNAKE_TEXTURE, SNAKE_PALETTE, SNAKE_ANIMPATH, -3, "0", Playback.Once, user, facing)
    snake.anim = snake:get_animation()
    snake:set_elevation(2*2)
    snake:set_hit_props(
        HitProps.new()
        :dmg(props.damage)
        :impact()
        :flinch()
        :flash()
        :elem(props.element)
        :from(user:get_context())
    )
    local width = field:width()
    local height = field:height()
    local found = false
    local target = nil
    local xy = 0
    local do_once = true
    snake.frames = 1
    snake.on_spawn_func = function(self)
	    Engine.play_audio(SPAWN_AUDIO, AudioPriority.Immediate)
    end
    snake.update_func = function(self)
        if self:get_tile():is_edge() then
            self:delete()
            return
        end
        for i=2,5 do
            if self.frames == i then
                self:set_elevation(self:get_elevation()+2*2)
            end
        end
        if self.frames == 27 then
            self.anim:set_state("1")
            self.anim:refresh(self:sprite())
            for i=1,width do
                local t = tile:get_tile(facing,i)
                if t and check_characters(t,user) then
                    found = true
                    target = t
                    break
                end
            end
            if not found then
                for y=1,height do
                    for i=0,width do
                        local t2 = tile:get_tile(Direction.Up,y)
                        if t2 then
                            local t = t2:get_tile(facing,i)
                            if t and check_characters(t,user) then
                                found = true
                                target = t
                                break
                            end
                        end
                    end
                end
            end
            if not found then
                for y=1,height do
                    for i=0,width do
                        local t2 = tile:get_tile(Direction.Down,y)
                        if t2 then
                            local t = t2:get_tile(facing,i)
                            if t and check_characters(t,user) then
                                found = true
                                target = t
                                break
                            end
                        end
                    end
                end
            end
            if not target then
                target = self:get_tile(facing,1)
            end
            local x = tile:x()-target:x()
            if x<0 then x=-x end
            local y = tile:y()-target:y()
            if y<0 then y=-y end
            xy = x+y
        end
        if self.frames >= 37 then
            if do_once then
                do_once = false
	            Engine.play_audio(SNAKE_AUDIO, AudioPriority.Immediate)
            end
            if not self:is_sliding() then
                if found and self:get_tile() == target then
                    self:get_tile():attack_entities(self)
                    self:delete()
                    return
                end
                self:slide(target, frames(2+xy*2), frames(0), ActionOrder.Voluntary)
            end
        end
        self.frames = self.frames + 1
    end
    snake.collision_func = function(self)
        --self:delete()
    end
    snake.attack_func = function(self, other, judge)
        if not judge:hint_spawn_gfx() then return end
        local offset_y = math.random(-7,6)
        local offset_x = math.random(-8,7)
        if facing == Direction.Left then offset_x = -offset_x end
        local hit_fx = graphic_init("artifact", other:get_tile_offset().x+other:get_offset().x+(offset_x*2), other:get_tile_offset().y+other:get_offset().y+(offset_y*2), BURST_TEXTURE, BURST_PALETTE, BURST_ANIMPATH, -999, "0", Playback.Once, user, facing, true, false, true)
        hit_fx:set_elevation(10*2)
        field:spawn(hit_fx, other:get_tile())
    end
    snake.battle_end_func = function(self)
        self:delete()
    end
    snake.delete_func = function(self)
        self:erase()
    end
    snake.can_move_to_func = function(tile)
        return true
    end
    field:spawn(snake,tile)
    return snake
end

cmonsnake.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
    action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        local actor = self:get_actor()
        local orig_speed = actor:get_animation():get_playback_speed()
        actor:get_animation():set_playback_speed(0)
        
		local facing = user:get_facing()
        local field = user:get_field()
		local team = user:get_team()
        
        local snakes = {}
        local x_start = 1
        local x_end = field:width()
        local x_mid = 1
        local widthNumber = 1
        if facing == Direction.Right then
            x_start = field:width()
            x_end = 1
            x_mid = -1
            widthNumber = field:width()
        end
        for x=x_start, x_end, x_mid do
            for y=1, field:height() do
                local tile = field:tile_at(x,y)
                if tile:get_team() == team and tile:is_hole() and not tile:is_edge() and not check_obstacles(tile) and not check_characters_true(tile) then
                    snakes["x"..x] = snakes["x"..x] or {}
                    table.insert(snakes["x"..x],tile)
                    table.insert(snakes,tile)
                end
            end
        end

		local step1 = Battle.Step.new()
		self.frames = 1
        step1.update_func = function()
            --print(self.frames)
            if #snakes>0 then
                if widthNumber<=0 then
                    if self.frames >= 50 then
                        user:get_animation():set_playback_speed(orig_speed)
                        step1:complete_step()
                    end
                    self.frames = self.frames + 1
                    return
                end
                if snakes["x"..widthNumber] and #snakes["x"..widthNumber]>0 then
                    for i=1,#snakes["x"..widthNumber] do
                        if self.frames == 1+8*(i-1) then
                            create_snake(user, props, facing, field, team, snakes["x"..widthNumber][i])
                        end
                        if self.frames == 1+8*i+20 then
                            if widthNumber+x_mid <= 0 then
                                widthNumber=widthNumber+x_mid
                            else
                                repeat
                                    widthNumber=widthNumber+x_mid
                                until snakes["x"..widthNumber]
                            end
		                    self.frames = 1
                            return
                        end
                    end
                else
                    if widthNumber+x_mid <= 0 then
                        widthNumber=widthNumber+x_mid
                    else
                        repeat
                            widthNumber=widthNumber+x_mid
                        until snakes["x"..widthNumber]
                    end
		            self.frames = 1
                    return
                end
            else
                if self.frames >= 50 then
                    user:get_animation():set_playback_speed(orig_speed)
                    step1:complete_step()
                end
            end
            self.frames = self.frames + 1
        end
		self:add_step(step1)
    end
    return action
end

-- Checks for non-zero-health Obstacles.
function check_obstacles(tile)
    local ob = tile:find_obstacles(function(o)
        if o:get_animation():has_state("PASS_THROUGH") or o:get_name() == "CANTINTERACT" then
            return false
        else
            return true
        end
        return o:get_health() > 0
    end)
    return #ob > 0 
end

-- Checks for unfriendly Characters.
function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)
    return #characters > 0
end

-- Checks for any Characters.
function check_characters_true(tile)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0
    end)
    return #characters > 0
end

function check_characters_true_team(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_tile():get_team() == self:get_tile():get_team()
    end)
    return #characters > 0
end

return cmonsnake