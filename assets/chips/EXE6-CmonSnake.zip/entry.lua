local cmonsnake = include("cmonsnake/cmonsnake.lua")

local DAMAGE = 30

cmonsnake.codes = {"H","M","L"}
cmonsnake.shortname = "CmonSnke"
cmonsnake.damage = DAMAGE
cmonsnake.time_freeze = true
cmonsnake.element = Element.None
cmonsnake.description = "Call snks\nfrom hole\nin area!"
cmonsnake.long_description = "Snakes come from hole squares in your area!"
cmonsnake.can_boost = true
cmonsnake.card_class = CardClass.Standard
cmonsnake.limit = 3
cmonsnake.mb = 34

function package_init(package)
    package:declare_package_id("com.OFC.card.EXE6-103-CmonSnake")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes(cmonsnake.codes)

    local props = package:get_card_props()
    props.shortname = cmonsnake.shortname
    props.damage = cmonsnake.damage
    props.time_freeze = cmonsnake.time_freeze
    props.element = cmonsnake.element
    props.description = cmonsnake.description
    props.long_description = cmonsnake.long_description
    props.can_boost = cmonsnake.can_boost
	props.card_class = cmonsnake.card_class
	props.limit = cmonsnake.limit
end

card_create_action = cmonsnake.card_create_action