local print_debug = false

local STEAL_TEXTURE = Engine.load_texture(_folderpath.."gfx/steal.grayscaled.png")
local STEAL_ANIMPATH = _folderpath.."gfx/steal.animation"

local GRAB_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_206.ogg", true)
local LIFT_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_89.ogg", true)
local CONSUME_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_311.ogg", true)

local function debug_print(text)
    if print_debug then
        print("[ColorPoint] "..text)
    end
end

local colorpoint = {}

--(Function by Alrysc)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function give_boost(user,count)
    local player = Battle.Player.from(user)
    local handle = player:get_held_card_handle()
    if not handle then return end
    local p = handle:copy_modded_props()
    if not p.can_boost then return end
    local damage_boost = handle:read_mod(PropsMod.damage, "DarkPlus")
    if damage_boost == nil then
        damage_boost = colorpoint.point*count
        handle:write_mod(PropsMod.damage, "ColorPoint", damage_boost)
    end
end

colorpoint.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
    action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        local actor = self:get_actor()
        local orig_speed = actor:get_animation():get_playback_speed()
        actor:get_animation():set_playback_speed(0)

		local facing_away = user:get_facing_away()
		local facing = user:get_facing()
        local field = user:get_field()
		local team = user:get_team()

        local colorpoints = {}
        local x_start = 1
        local x_end = field:width()
        local x_mid = 1
        if facing == Direction.Left then
            x_start = field:width()
            x_end = 1
            x_mid = -1
        end
        for y=1, field:height() do
            for x=x_start, x_end, x_mid do
                local tile = field:tile_at(x,y)
                if not check_obstacles(tile) and not check_characters_true(tile) and tile:get_team() == team and tile:get_tile(facing,1):get_team() ~= team and tile:get_tile(facing_away,1) ~= team and not tile:get_tile(facing_away,1):is_edge() then
                    table.insert(colorpoints,{t=tile,p=nil})
                end
            end
        end

        local other_team = Team.Blue
        if team == Team.Blue then
            other_team = Team.Red
        end

        local base_offset = user:get_offset() -- Add to starting offset away from dest_tile
        local mfacing = 1
        if facing == Direction.Left then 
            mfacing = -1
        end
		local step1 = Battle.Step.new()
		self.frames = 1
        step1.update_func = function()
            if #colorpoints>0 then
                if self.frames == 1 then
		        	Engine.play_audio(GRAB_AUDIO, AudioPriority.Immediate)
                    for i=1,#colorpoints do
                        local palette = Engine.load_texture(_folderpath.."gfx/palette/"..colorpoint.color..".png")
                        local point = graphic_init("spell", 0, 0, STEAL_TEXTURE, palette, STEAL_ANIMPATH, -3, "1", Playback.Once, user, facing, true)
                        field:spawn(point,colorpoints[i].t)
			    	    colorpoints[i].t:set_team(other_team, false)
                    end
                end
                if self.frames == 19 then
		        	Engine.play_audio(LIFT_AUDIO, AudioPriority.Immediate)
                    for i=1,#colorpoints do  
                        local palette = Engine.load_texture(_folderpath.."gfx/palette/"..colorpoint.color..".png")
                        local point = graphic_init("spell", 0, 0, STEAL_TEXTURE, palette, STEAL_ANIMPATH, -3, "0", Playback.Loop, user, facing)
                        local start_tile = colorpoints[i].t
                        local dest_tile = user:get_tile()
                        point.dist_x = dest_tile:x() - start_tile:x()
                        point.dist_y = dest_tile:y() - start_tile:y()
                        if point.dist_x == 0 then
                            point.offset_x = 0
                        else
                            point.offset_x = base_offset.x + point.dist_x * start_tile:width()
                        end
                        if point.dist_y == 0 then
                            point.offset_y = 0
                        else
                            point.offset_y = base_offset.y + (point.dist_y * (start_tile:height()-start_tile:height()/6)) * -1
                        end
                        --print("Base offset is ", offset_x, offset_y)
                        point.offset_x = point.offset_x * -1 
                        point.dest_x = point.offset_x + start_tile:width()/2 * mfacing
                        --print(dest_x)
                        point.cur_time = 0
                        point.time = 24
                        point.can_move_to_func = function(t)
                            return true
                        end
                        field:spawn(point,colorpoints[i].t)
                        colorpoints[i].p = point
                    end
                end
                for j=20,23 do
                    if self.frames == j then
                        for i=1,#colorpoints do
                            colorpoints[i].p:set_elevation(colorpoints[i].p:get_elevation()+4*2)
                        end
                    end
                end
                --[[
                if self.frames == 41 then
                    for i=1,#colorpoints do
                        colorpoints[i].p:slide(user:get_tile(), frames(23), frames(0), ActionOrder.Voluntary)
                    end
                end]]
                for j=41,62 do
                    if self.frames == j then
                        for i=1,#colorpoints do
                            if j==41 then
                                colorpoints[i].p:teleport(user:get_tile(), ActionOrder.Voluntary)
                            end
                            if colorpoints[i].p.dist_x ~= 0 then
                                local x = math.floor(colorpoints[i].p.offset_x - (colorpoints[i].p.dest_x * colorpoints[i].p.cur_time/colorpoints[i].p.time)/14)
                                colorpoints[i].p.offset_x = (x + x % 2)
                            end
                            if colorpoints[i].p.dist_y ~= 0 then
                                local mod = colorpoints[i].p.cur_time/colorpoints[i].p.time
                                local y = math.floor(colorpoints[i].p.offset_y - (colorpoints[i].p.offset_y * mod)/14)
                                colorpoints[i].p.offset_y = (y + y % 2)
                            end
                            colorpoints[i].p:set_offset(colorpoints[i].p.offset_x,colorpoints[i].p.offset_y)
                            --print(i,x,y)
                            colorpoints[i].p.cur_time = colorpoints[i].p.cur_time + 1
                        end
                    end
                end
                if self.frames == 63 then
		        	Engine.play_audio(CONSUME_AUDIO, AudioPriority.Immediate)
                    give_boost(user,#colorpoints)
                    for i=1,#colorpoints do
                        colorpoints[i].p:delete()
                    end
                end
                if self.frames == 67 then
                    user:get_animation():set_playback_speed(orig_speed)
                    step1:complete_step()
                end
            else
                user:get_animation():set_playback_speed(orig_speed)
                step1:complete_step()
            end
            self.frames = self.frames + 1
        end
		self:add_step(step1)
    end
    return action
end

-- Checks for non-zero-health Obstacles.
function check_obstacles(tile)
    local ob = tile:find_obstacles(function(o)
        if o:get_animation():has_state("PASS_THROUGH") or o:get_name() == "CANTINTERACT" then
            return false
        else
            return true
        end
        return o:get_health() > 0
    end)
    return #ob > 0 
end

-- Checks for unfriendly Characters.
function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)
    return #characters > 0
end

-- Checks for any Characters.
function check_characters_true(tile)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0
    end)
    return #characters > 0
end

function check_characters_true_team(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_tile():get_team() == self:get_tile():get_team()
    end)
    return #characters > 0
end

return colorpoint