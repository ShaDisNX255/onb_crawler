local colorpoint = include("colorpoint/colorpoint.lua")

local DAMAGE = 0

colorpoint.color = "cyan"
colorpoint.point = 10

colorpoint.codes = {"*"}
colorpoint.shortname = "ClrPoint"
colorpoint.damage = DAMAGE
colorpoint.time_freeze = true
colorpoint.element = Element.Plus
colorpoint.description = "NextChip:\n+10 for\nyour pnls"
colorpoint.long_description = "Sacrificing your area increases attack of the next chip by 10"
colorpoint.can_boost = false
colorpoint.card_class = CardClass.Standard
colorpoint.limit = 3
colorpoint.mb = 31

function package_init(package) 
    package:declare_package_id("com.OFC.card.EXE6-199-ColorPoint")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(colorpoint.codes)

    local props = package:get_card_props()
    props.shortname = colorpoint.shortname
    props.damage = colorpoint.damage
    props.time_freeze = colorpoint.time_freeze
    props.element = colorpoint.element
    props.description = colorpoint.description
    props.long_description = colorpoint.long_description
    props.can_boost = colorpoint.can_boost
	props.card_class = colorpoint.card_class
	props.limit = colorpoint.limit
end

card_create_action = colorpoint.card_create_action