local print_debug = false

local ELEMENTMAN_TEXTURE = Engine.load_texture(_folderpath.."gfx/elementman.grayscaled.png")
local ELEMENTMAN_PALETTE_N = Engine.load_texture(_folderpath.."gfx/palette/battle-none.png")
local ELEMENTMAN_PALETTE_F = Engine.load_texture(_folderpath.."gfx/palette/battle-fire.png")
local ELEMENTMAN_PALETTE_A = Engine.load_texture(_folderpath.."gfx/palette/battle-aqua.png")
local ELEMENTMAN_PALETTE_E = Engine.load_texture(_folderpath.."gfx/palette/battle-elec.png")
local ELEMENTMAN_PALETTE_W = Engine.load_texture(_folderpath.."gfx/palette/battle-wood.png")
local ELEMENTMAN_ANIMPATH = _folderpath.."gfx/elementman.animation"

local CIRCLE_TEXTURE = Engine.load_texture(_folderpath.."gfx/circle.grayscaled.png")
local CIRCLE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/circle.png")
local CIRCLE_ANIMPATH = _folderpath.."gfx/circle.animation"

local METEOR_TEXTURE = Engine.load_texture(_folderpath.."gfx/meteor.grayscaled.png")
local METEOR_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/meteor.png")
local METEOR_ANIMPATH = _folderpath.."gfx/meteor.animation"
local SPARKLE_TEXTURE = Engine.load_texture(_folderpath.."gfx/sparkle.grayscaled.png")
local SPARKLE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/sparkle.png")
local SPARKLE_ANIMPATH = _folderpath.."gfx/sparkle.animation"
local THUNDER_TEXTURE = Engine.load_texture(_folderpath.."gfx/thunder.grayscaled.png")
local THUNDER_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/thunder.png")
local THUNDER_ANIMPATH = _folderpath.."gfx/thunder.animation"
local WOODYTOWER_TEXTURE = Engine.load_texture(_folderpath.."gfx/woodytower.grayscaled.png")
local WOODYTOWER_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/woodytower.png")
local WOODYTOWER_ANIMPATH = _folderpath.."gfx/woodytower.animation"

local BOOM_TEXTURE = Engine.load_texture(_folderpath.."gfx/boom.grayscaled.png")
local BOOM_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/boom.png")
local BOOM_ANIMPATH = _folderpath.."gfx/boom.animation"
local GRASSSMOKE_TEXTURE = Engine.load_texture(_folderpath.."gfx/grasssmoke.grayscaled.png")
local GRASSSMOKE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/grasssmoke.png")
local GRASSSMOKE_ANIMPATH = _folderpath.."gfx/grasssmoke.animation"

local EFFECT2_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect2.grayscaled.png")
local EFFECT2_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect2.png")
local EFFECT2_ANIMPATH = _folderpath.."gfx/effect2.animation"
local EFFECT3_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect3.grayscaled.png")
local EFFECT3_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect3.png")
local EFFECT3_ANIMPATH = _folderpath.."gfx/effect3.animation"
local EFFECT4_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect4.grayscaled.png")
local EFFECT4_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect4.png")
local EFFECT4_ANIMPATH = _folderpath.."gfx/effect4.animation"
local EFFECT5_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect5.grayscaled.png")
local EFFECT5_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect5.png")
local EFFECT5_ANIMPATH = _folderpath.."gfx/effect5.animation"

local SPAWN_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_65.ogg", true)
local CHANGING_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_145.ogg", true)
local CHANGED_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_119.ogg", true)
local METEOR_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_221.ogg", true)
local ICE_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_162.ogg", true)
local THUNDER_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_31.ogg", true)
local GRASS_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_35.ogg", true)
local WOODYTOWER_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_209.ogg", true)

local function debug_print(text)
    if print_debug then
        print("[ElementMan] "..text)
    end
end

local elementman = {}

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function create_tallesttree(user, finalized_damage, facing, field, tile)
    local spawn_next
    spawn_next = function()
        if not tile or tile:is_edge() or tile:is_hole() then return end
        local woodytower = graphic_init("spell", 0, 0, WOODYTOWER_TEXTURE, WOODYTOWER_PALETTE, WOODYTOWER_ANIMPATH, -3, "0", Playback.Once, user, facing, true, true)
        woodytower:set_hit_props(
            HitProps.new()
            :dmg(finalized_damage)
            :impact()
            :flinch()
            :pierce_ground()
            :retangible()
            :no_counter()
            :elem(Element.Wood)
            :from(user:get_context())
        )
        woodytower.frames = 0
        woodytower:get_animation():on_frame(6, function()
            tile = tile:get_tile(facing, 1)
            spawn_next()
        end)
        woodytower.on_spawn_func = function()
            debug_print("attack spawned on tile ("..tile:x()..";"..tile:y()..")")
            Engine.play_audio(WOODYTOWER_AUDIO, AudioPriority.Immediate)
        end
        woodytower.update_func = function(self)
            self.frames = self.frames + 1
            if self.frames == 2 then
                tile:attack_entities(self)
            end
        end
        woodytower.attack_func = function(self, other, judge)
            debug_print("attacked tile ("..self:get_tile():x()..";"..self:get_tile():y()..")")
            if not judge:hint_spawn_gfx() then return end
            local offset_y = math.random(-8,5)
            local offset_x = math.random(-7,6)
            local hit_fx = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT5_TEXTURE, EFFECT5_PALETTE, EFFECT5_ANIMPATH, -999, "0", Playback.Once, user, facing, true, true, true)
            field:spawn(hit_fx, self:get_tile())
        end
        woodytower.battle_end_func = function(self)
            self:delete()
        end
        woodytower.delete_func = function(self)
            self:erase()
        end
        field:spawn(woodytower, tile)
    end
    spawn_next()
end

local function create_grass(user, facing, field)
    for x=1, field:width() do
        for y=1, field:height() do
            local grass_tile = field:tile_at(x,y)
            if grass_tile and not grass_tile:is_edge() and not grass_tile:is_hole() then
                local grass = graphic_init("artifact", 0, 0, GRASSSMOKE_TEXTURE, GRASSSMOKE_PALETTE, GRASSSMOKE_ANIMPATH, -3, "0", Playback.Once, user, facing, true, true, true)
                grass.on_spawn_func = function()
                    debug_print("grass spawned on tile ("..grass_tile:x()..";"..grass_tile:y()..")")
                    Engine.play_audio(GRASS_AUDIO, AudioPriority.Immediate)
                    grass_tile:set_state(TileState.Grass)
                end
                field:spawn(grass, grass_tile)
            end
        end
    end
end

local function create_lightningdrive(user, finalized_damage, facing, field, tile)
    local thunder = graphic_init("spell", 0, 0, THUNDER_TEXTURE, THUNDER_PALETTE, THUNDER_ANIMPATH, -3, "0", Playback.Once, user, facing, true, true)
    thunder:set_hit_props(
        HitProps.new()
        :dmg(finalized_damage)
        :impact()
        :flinch()
        :flash()
        :pierce_ground()
        :retangible()
        :no_counter()
        :elem(Element.Elec)
        :from(user:get_context())
    )
    local query = function(e)
        return (Battle.Character.from(e) ~= nil or Battle.Player.from(e) ~= nil or Battle.Obstacle.from(e) ~= nil) and e:get_health() > 0
    end
    thunder.frames = 1
    thunder.on_spawn_func = function()
        debug_print("attack spawned on tile ("..tile:x()..";"..tile:y()..")")
        Engine.play_audio(THUNDER_AUDIO, AudioPriority.Immediate)
    end
    thunder.update_func = function(self)
        if self.frames == 1 then
            if not tile:is_walkable() or tile:is_reserved({}) or #tile:find_entities(query) > 0 then
                tile:set_state(TileState.Cracked)
            else
                tile:set_state(TileState.Broken)
            end
        end
        if self.frames == 2 then
            tile:attack_entities(self)
        end
        self.frames = self.frames + 1
    end
    thunder.attack_func = function(self, other, judge)
        debug_print("attacked tile ("..self:get_tile():x()..";"..self:get_tile():y()..")")
        if not judge:hint_spawn_gfx() then return end
        local offset_y = math.random(-6,7)
        local offset_x = math.random(-9,8)
        local hit_fx = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT4_TEXTURE, EFFECT4_PALETTE, EFFECT4_ANIMPATH, -999, "0", Playback.Once, user, facing, true, true, true)
        field:spawn(hit_fx, self:get_tile())
    end
    thunder.battle_end_func = function(self)
        self:delete()
    end
    thunder.delete_func = function(self)
        self:erase()
    end
    field:spawn(thunder, tile)
end

local function create_diamonddust(user, finalized_damage, facing, field)
    local dir_table = 
    {
        [1] = Direction.join(facing, Direction.Up),
        [2] = facing,
        [3] = Direction.join(facing, Direction.Down)
    }
    for i=1, #dir_table do
        local ice_tile = user:get_tile(dir_table[i], 1)
        if ice_tile then
            local ice = graphic_init("spell", 0, 0, SPARKLE_TEXTURE, SPARKLE_PALETTE, SPARKLE_ANIMPATH, -3, "0", Playback.Once, user, facing, true)
            ice:set_hit_props(
                HitProps.new()
                :dmg(finalized_damage)
                :impact()
                :freeze()
                :no_counter()
                :elem(Element.Aqua)
                :from(user:get_context())
            )
            ice.frames = 1
            ice.on_spawn_func = function()
                debug_print("attack spawned on tile ("..ice_tile:x()..";"..ice_tile:y()..")")
                Engine.play_audio(ICE_AUDIO, AudioPriority.Immediate)
            end
            ice.update_func = function(self)
                if ice_tile:is_edge() or ice_tile:get_state() == TileState.Empty or ice_tile:get_state() == TileState.Hidden then
                else
                    if self.frames == 1 then
                        if ice_tile:get_state() ~= TileState.Broken then
                            ice_tile:set_state(TileState.Ice)
                        end
                    end
                    if self.frames >= 2 then
                        ice_tile:attack_entities(self)
                    end
                end
                self.frames = self.frames + 1
            end
            ice.attack_func = function(self, other, judge)
                debug_print("attacked tile ("..self:get_tile():x()..";"..self:get_tile():y()..")")
                if not judge:hint_spawn_gfx() then return end
                local offset_y = math.random(-14,1)
                local offset_x = math.random(-9,8)
                local hit_fx = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT3_TEXTURE, EFFECT3_PALETTE, EFFECT3_ANIMPATH, -999, "0", Playback.Once, user, facing, true, true, true)
                field:spawn(hit_fx, self:get_tile())
            end
            ice.battle_end_func = function(self)
                self:delete()
            end
            ice.delete_func = function(self)
                self:erase()
            end
            field:spawn(ice, ice_tile)
        end
    end
end

local function create_meteorite(user, finalized_damage, facing, field, tile)
    local offset_x = -11*2
    if facing == Direction.Left then offset_x = -offset_x end
    local meteor = graphic_init("spell", offset_x*21, 0, METEOR_TEXTURE, METEOR_PALETTE, METEOR_ANIMPATH, -3, "0", Playback.Once, user, facing)
    meteor:set_elevation((11*2)*21)
    meteor:set_hit_props(
        HitProps.new()
        :dmg(finalized_damage)
        :impact()
        :flinch()
        :flash()
        :pierce_ground()
        :retangible()
        :no_counter()
        :elem(Element.Fire)
        :from(user:get_context())
    )
    meteor.frames = 1
    meteor.on_spawn_func = function()
        debug_print("attack spawned on tile ("..tile:x()..";"..tile:y()..")")
        Engine.play_audio(METEOR_AUDIO, AudioPriority.Immediate)
    end
    meteor.update_func = function(self)
        self:highlight_tile(Highlight.Flash)
        if self:get_elevation() <= 0 then
            if not tile:is_hole() then
                local offset_y = -5
                local offset_x = -5
                local boom_fx = graphic_init("artifact", (offset_x*2), (offset_y*2), BOOM_TEXTURE, BOOM_PALETTE, BOOM_ANIMPATH, -99, "0", Playback.Once, user, facing, true, true)
                field:spawn(boom_fx, tile)
                tile:attack_entities(self)
            end
            self:delete()
        else
            self:set_offset(self:get_offset().x+(-offset_x), self:get_offset().y)
            self:set_elevation(self:get_elevation()-(11*2))
        end
        self.frames = self.frames + 1
    end
    meteor.attack_func = function(self, other, judge)
        debug_print("attacked tile ("..self:get_tile():x()..";"..self:get_tile():y()..")")
        if not judge:hint_spawn_gfx() then return end
        local offset_y = math.random(-8,5)
        local offset_x = math.random(-7,6)
        local hit_effect = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT2_TEXTURE, EFFECT2_PALETTE, EFFECT2_ANIMPATH, -999, "0", Playback.Once, user, facing, true, true, true)
        field:spawn(hit_effect, self:get_tile())
    end
    meteor.battle_end_func = function(self)
        self:delete()
    end
    meteor.delete_func = function(self)
        self:erase()
    end
    field:spawn(meteor, tile)
end

elementman.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_MOVE")
    local frame_sequence = make_frame_data({
        {1,0.0}, {2,0.017}, {3,0.017}, {4,0.483}, {4,0.017}, {4,0.533}, {4,0.017}, {3,0.017}, {2,0.017}, {1,0.4}
    })
    action:override_animation_frames(frame_sequence)
	action:set_lockout(make_animation_lockout())
    local read_voice_input = true
    local use_voice = false
    action.update_func = function(self)
        if read_voice_input and user:input_has(Input.Held.Special) then
            use_voice = true
            read_voice_input = false
        end
    end
	action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        local actor = self:get_actor()
        local facing = user:get_facing()
        local field = user:get_field()
        local team = user:get_team()

        local navi = nil
        local navi_anim = nil
        local circle = nil
        local circle_anim = nil
        self:add_anim_action(4, function()
            actor:hide()
        end)
        self:add_anim_action(5, function()
            read_voice_input = false
            actor:get_animation():set_playback_speed(0)
            
            circle = graphic_init("artifact", 0, 0, CIRCLE_TEXTURE, CIRCLE_PALETTE, CIRCLE_ANIMPATH, 0, "0", Playback.Once, user, facing)
            circle_anim = circle:get_animation()

            navi = graphic_init("artifact", 0, 0, ELEMENTMAN_TEXTURE, ELEMENTMAN_PALETTE_N, ELEMENTMAN_ANIMPATH, -1, "0", Playback.Once, user, facing)
            navi_anim = navi:get_animation()
            navi.state = "SPAWN"
            navi.frames = 0
            navi.change_time = 0
            navi.change_number = 0
            navi.timeout = 360

            local dir_table = 
            {
                [1] = ELEMENTMAN_PALETTE_F,
                [2] = ELEMENTMAN_PALETTE_A,
                [3] = ELEMENTMAN_PALETTE_E,
                [4] = ELEMENTMAN_PALETTE_W
            }
            dir_table.index = 0

            local user_tile = user:get_tile()
            if user_tile:is_hole() then
                navi.state = "HOLE"
            end
            local enemy_table = {}
            local query = function(c)
                return c and c:get_id() ~= user:get_id() and not c:is_team(user:get_team()) and c:get_health() > 0
            end

            local base_damage = props.damage
            local panel_damage = 0
            local finalized_damage = 0
            if elementman.holy_boost then
                base_damage = 140
                local holy_query = function(o)
                    return o and o:get_state() == TileState.Holy and o:get_team() == team
                end
                local find_holy = field:find_tiles(holy_query)
                if find_holy[1] ~= nil then
                    if #find_holy > 10 then
                        panel_damage = (10 * 10)
                    else
                        panel_damage = (10 * #find_holy)
                    end
                end
                debug_print("base damage is "..base_damage..".")
                local multiplied_damage = props.damage
                if multiplied_damage ~= 777 then
                    if multiplied_damage % 2 == 0 then
                        debug_print("multiplied pre-damage is an EVEN number.")
                        if multiplied_damage / 2 < 777 then
                            finalized_damage = math.floor((base_damage + panel_damage + ((multiplied_damage) - 777)))
                            if not print_debug then
                                print("ElementMan: "..base_damage.."+"..panel_damage.."+"..math.floor(multiplied_damage - 777).." = "..finalized_damage)
                            end
                        else
                            finalized_damage = math.floor((base_damage + panel_damage + ((multiplied_damage / 2) - 777))*2)
                            if not print_debug then
                                print("ElementMan: ("..base_damage.."+"..panel_damage.."+"..math.floor((multiplied_damage / 2) - 777)..")*2 = "..finalized_damage)
                            end
                        end
                    else
                        debug_print("multiplied pre-damage is an ODD number.")
                        finalized_damage = math.floor(base_damage + panel_damage + (multiplied_damage - 777))
                        if not print_debug then
                            print("ElementMan: "..base_damage.."+"..panel_damage.."+"..math.floor(multiplied_damage - 777).." = "..finalized_damage)
                        end
                    end
                else
                    debug_print("multiplied pre-damage is NOT multiplied at all.")
                    finalized_damage = math.floor(base_damage + panel_damage)
                    if not print_debug then
                        print("ElementMan: "..base_damage.."+"..panel_damage.."+0 = "..finalized_damage)
                    end
                end
                debug_print("finalized damage is "..finalized_damage..".")
            else
                finalized_damage = base_damage
            end

            navi.on_spawn_func = function(self)
                debug_print("spawned on tile ("..user_tile:x()..";"..user_tile:y()..")")
                Engine.play_audio(SPAWN_AUDIO, AudioPriority.Immediate)
            end
            navi.update_func = function(self)
                self.frames = self.frames + 1
                if self.state == "HOLE" then
                    if navi_anim:get_state() == "0" then
                        navi_anim:on_complete(function()
                            self.state = "DESPAWN"
                            self.frames = 0
                            navi_anim:set_state("3")
                            navi_anim:refresh(navi:sprite())
                            circle_anim:set_state("3")
                            circle_anim:refresh(circle:sprite())
                        end)
                    end
                elseif self.state == "SPAWN" then
                    if self.frames >= 14 then
                        self.state = "CHANGE"
                        self.frames = 0
                    end
                    if navi_anim:get_state() == "0" then
                        navi_anim:on_complete(function()
                            navi_anim:set_state("1")
                            navi_anim:refresh(navi:sprite())
                            circle_anim:set_state("1")
                            circle_anim:set_playback(Playback.Loop)
                            circle_anim:refresh(circle:sprite())
                        end)
                    end
                elseif self.state == "CHANGE" then
                    if user:input_has(Input.Pressed.Use) then
                        self.state = "ATTACK"
                        self.frames = 0
                        navi_anim:set_state("2")
                        navi_anim:refresh(navi:sprite())
                        circle_anim:set_state("2")
                        circle_anim:refresh(circle:sprite())
                        Engine.play_audio(CHANGED_AUDIO, AudioPriority.Immediate)
                    end
                    self.change_time = self.change_time + 1
                    if self.change_time == 1 then
                        dir_table.index = dir_table.index + 1
                        if dir_table.index > #dir_table then
                            dir_table.index = 1
                        end
                        self.change_number = self.change_number + 1
                        if self.change_number >= 21 then
                            self.state = "ATTACK"
                            self.frames = 0
                            navi_anim:set_state("2")
                            navi_anim:refresh(navi:sprite())
                            circle_anim:set_state("2")
                            circle_anim:refresh(circle:sprite())
                            dir_table.index = math.random(1,#dir_table)
                        end
                        navi:set_palette(dir_table[dir_table.index])
                        Engine.play_audio(CHANGING_AUDIO, AudioPriority.Immediate)
                    elseif self.change_time >= elementman.change_time then
                        self.change_time = 0
                    end
                elseif self.state == "ATTACK" then
                    if dir_table.index == 1 then
                        if self.frames == 1 then
                            for i=field:height(), 1, -1 do
                                if facing == Direction.Right then
                                    for j=field:width(), 1, -1 do
                                        local enemy_tile = field:tile_at(j,i)
                                        if #enemy_tile:find_characters(query) > 0 then
                                            table.insert(enemy_table, enemy_tile)
                                        end
                                    end
                                else
                                    for j=1, field:width() do
                                        local enemy_tile = field:tile_at(j,i)
                                        if #enemy_tile:find_characters(query) > 0 then
                                            table.insert(enemy_table, enemy_tile)
                                        end
                                    end
                                end
                            end
                        end
                        if enemy_table[1] ~= nil then
                            for i=1, #enemy_table+1 do
                                if i == #enemy_table+1 then
                                    if self.frames == (37+(12*(i-1)))+4 then
                                        self.state = "DESPAWN"
                                        self.frames = 0
                                        navi_anim:set_state("3")
                                        navi_anim:refresh(navi:sprite())
                                        circle_anim:set_state("3")
                                        circle_anim:refresh(circle:sprite())
                                    end
                                else
                                    if self.frames == 37+(12*(i-1)) then
                                        create_meteorite(user, finalized_damage, facing, field, enemy_table[i])
                                    end
                                end
                            end
                        end
                    elseif dir_table.index == 2 then
                        if self.frames == 37 then
                            create_diamonddust(user, finalized_damage, facing, field)
                        end
                        if self.frames >= 82 then
                            self.state = "DESPAWN"
                            self.frames = 0
                            navi_anim:set_state("3")
                            navi_anim:refresh(navi:sprite())
                            circle_anim:set_state("3")
                            circle_anim:refresh(circle:sprite())
                        end
                    elseif dir_table.index == 3 then
                        for i=1, field:height()+1 do
                            if i == field:height()+1 then
                                if self.frames == (38+(16*(i-1)))-1 then
                                    self.state = "DESPAWN"
                                    self.frames = 0
                                    navi_anim:set_state("3")
                                    navi_anim:refresh(navi:sprite())
                                    circle_anim:set_state("3")
                                    circle_anim:refresh(circle:sprite())
                                end
                            else
                                if self.frames == 38+(16*(i-1)) then
                                    local atk_tile = field:tile_at(user_tile:x()+3, i)
                                    if facing == Direction.Left then atk_tile = field:tile_at(user_tile:x()-3, i) end
                                    create_lightningdrive(user, finalized_damage, facing, field, atk_tile)
                                end
                            end
                        end
                    elseif dir_table.index == 4 then
                        if self.frames == 1 then
                            create_grass(user, facing, field)
                        end
                        if self.frames == 38 then
                            create_tallesttree(user, finalized_damage, facing, field, user:get_tile(facing, 1))
                        end
                        if self.frames >= 113 then
                            self.state = "DESPAWN"
                            self.frames = 0
                            navi_anim:set_state("3")
                            navi_anim:refresh(navi:sprite())
                            circle_anim:set_state("3")
                            circle_anim:refresh(circle:sprite())
                        end
                    end
                elseif self.state == "DESPAWN" then
                    if navi_anim:get_state() == "3" then
                        navi_anim:on_complete(function()
                            navi_anim:set_state("4")
                            navi_anim:refresh(navi:sprite())
                            circle_anim:set_state("4")
                            circle_anim:refresh(circle:sprite())
                        end)
                    end
                    if navi_anim:get_state() == "4" then
                        navi_anim:on_complete(function()
                            circle:delete()
                            self:delete()
                        end)
                    end
                end
            end
            navi.can_move_to_func = function(tile)
                return true
            end
            navi.delete_func = function()
                actor:get_animation():set_playback_speed(1)
            end
            field:spawn(circle, user_tile)
            field:spawn(navi, user_tile)
        end)
        self:add_anim_action(7, function()
            actor:reveal()
        end)
    end
    action.action_end_func = function(self)
        local actor = self:get_actor()
        actor:reveal()
    end
	return action
end

return elementman