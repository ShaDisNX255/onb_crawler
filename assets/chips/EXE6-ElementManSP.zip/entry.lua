local elementman = include("elementman/elementman.lua")

local DAMAGE = 240
elementman.holy_boost = false

elementman.change_time = 12

elementman.codes = {"E"}
elementman.shortname = "ElmntMnSP"
elementman.damage = DAMAGE
elementman.time_freeze = true
elementman.element = Element.None
elementman.description = "Hit A whn\nclr chngs\nelem attk"
elementman.long_description = "Press A to stop the color change of the element attack"
elementman.can_boost = true
elementman.card_class = CardClass.Mega
elementman.limit = 1
elementman.mb = 66

function package_init(package) 
    package:declare_package_id("com.OFC.card.EXE6-272-ElementManSP")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(elementman.codes)

    local props = package:get_card_props()
    props.shortname = elementman.shortname
    props.damage = elementman.damage
    props.time_freeze = elementman.time_freeze
    props.element = elementman.element
    props.description = elementman.description
    props.long_description = elementman.long_description
    props.can_boost = elementman.can_boost
	props.card_class = elementman.card_class
	props.limit = elementman.limit
    props.meta_classes = {"Navi"}
end

card_create_action = elementman.card_create_action