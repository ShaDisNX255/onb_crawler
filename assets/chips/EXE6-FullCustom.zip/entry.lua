local fullcustom = include("fullcustom/fullcustom.lua")

local DAMAGE = 0

fullcustom.codes = {"*"}
fullcustom.shortname = "FullCust"
fullcustom.damage = DAMAGE
fullcustom.time_freeze = false
fullcustom.element = Element.None
fullcustom.description = "CustGauge\ninstantly\nrefills!"
fullcustom.long_description = "Refills CustomGauge instantly and easily!"
fullcustom.can_boost = false
fullcustom.card_class = CardClass.Standard
fullcustom.limit = 1
fullcustom.mb = 50

function package_init(package)
    package:declare_package_id("com.OFC.card.EXE6-176-FullCustom")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(fullcustom.codes)

    local props = package:get_card_props()
    props.shortname = fullcustom.shortname
    props.damage = fullcustom.damage
    props.time_freeze = fullcustom.time_freeze
    props.element = fullcustom.element
    props.description = fullcustom.description
    props.long_description = fullcustom.long_description
    props.can_boost = fullcustom.can_boost
	props.card_class = fullcustom.card_class
	props.limit = fullcustom.limit
end

card_create_action = fullcustom.card_create_action