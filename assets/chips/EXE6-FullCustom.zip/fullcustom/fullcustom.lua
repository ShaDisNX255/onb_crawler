local print_debug = false

local function debug_print(text)
    if print_debug then
        print("[FullCustom] "..text)
    end
end

local fullcustom = {}

fullcustom.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
	action:set_lockout(make_async_lockout(0.167))
    local frame_sequence = make_frame_data({{1,0.0}})
	action:override_animation_frames(frame_sequence)
    action.execute_func = function(self, user)
		debug_print("in custom card action execute_func()!")
		Battle.set_cust_gauge_time(frames(math.floor(Battle.get_cust_gauge_max_time())))
    end
    return action
end

return fullcustom