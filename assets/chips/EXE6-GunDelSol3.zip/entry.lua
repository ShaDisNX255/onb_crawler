local gundelsol = include("gundelsol/gundelsol.lua")

local DAMAGE = 0

gundelsol.type = 3
gundelsol.duration = 121

gundelsol.codes = {"N","Q","W"}
gundelsol.shortname = "GunDSol3"
gundelsol.damage = DAMAGE
gundelsol.time_freeze = false
gundelsol.element = Element.None
gundelsol.description = "Hits row\n2sqr ahd\nw/sunshne"
gundelsol.long_description = "Shines sunlight on 3 vertical squares 2 squares ahead!"
gundelsol.can_boost = false
gundelsol.card_class = CardClass.Standard
gundelsol.limit = 3
gundelsol.mb = 38

function package_init(package) 
    package:declare_package_id("com.OFC.card.EXE6-017-GunDelSol3")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(gundelsol.codes)

    local props = package:get_card_props()
    props.shortname = gundelsol.shortname
    props.damage = gundelsol.damage
    props.time_freeze = gundelsol.time_freeze
    props.element = gundelsol.element
    props.description = gundelsol.description
    props.long_description = gundelsol.long_description
    props.can_boost = gundelsol.can_boost
	props.card_class = gundelsol.card_class
	props.limit = gundelsol.limit
end

card_create_action = gundelsol.card_create_action