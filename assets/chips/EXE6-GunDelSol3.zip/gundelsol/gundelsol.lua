local print_debug = false

local GUNDELSOL_TEXTURE --= Engine.load_texture(_folderpath.."gfx/gundelsol.grayscaled.png")
local GUNDELSOL_ANIMPATH = _folderpath.."gfx/gundelsol.animation"
local TAIYOU1_TEXTURE = Engine.load_texture(_folderpath.."gfx/taiyou1.png")
local TAIYOU1_ANIMPATH = _folderpath.."gfx/taiyou1.animation"
local TAIYOU2_TEXTURE = Engine.load_texture(_folderpath.."gfx/taiyou2.png")
local TAIYOU2_ANIMPATH = _folderpath.."gfx/taiyou2.animation"

local CLICK_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_19.ogg", true)
local TAIYOU_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_37.ogg", true)

local function debug_print(text)
    if print_debug then
        print("[GunDelSol] "..text)
    end
end

local gundelsol = {}

--(Function by Alrysc)
local function graphic_init(g_type, x, y, texture, animation, state, anim_playback, layer, user, facing, flip)
    flip = flip or false
    facing = facing or nil
    
    local graphic = nil
    if g_type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif g_type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    end

    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then
        graphic:set_facing(facing)
    end
    --[[
    if user:get_facing() == Direction.Left then 
        x = x * -1
    end]]
    graphic:set_offset(x, y)
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    graphic:get_animation():refresh(graphic:sprite())
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end

    return graphic
end

local function spell_damage_summon(user, tile)
    if not tile or tile:is_edge() then return end
    local spell_damage = Battle.Spell.new(user:get_team())
    local damage = 2
    if tile:get_state() == TileState.Holy then damage = damage*2 end
    spell_damage:set_hit_props(
        HitProps.new(
            damage,
            Hit.Pierce | Hit.Retangible,
            Element.None,
            user:get_context(),
            Drag.None
        )
    )
    local o_query = function(o)
        return o and o:get_health() > 0
    end
    spell_damage.update_func = function(self, dt)
        if #self:get_tile():find_obstacles(o_query) <= 0 then
            self:get_tile():attack_entities(self)
        end
        self:delete()
    end
    spell_damage.can_move_to_func = function(tile)
        return true
    end
    user:get_field():spawn(spell_damage, tile)
    return spell_damage
end

local function summon_sun(user)
    local spell = graphic_init("spell", 0, 0, false, false, false, false, false, user, user:get_facing())
    spell.frames = 0

    local taiyou_texture = TAIYOU1_TEXTURE
    local taiyou_animpath = TAIYOU1_ANIMPATH
    if gundelsol.type == 4 then
        taiyou_texture = TAIYOU2_TEXTURE
        taiyou_animpath = TAIYOU2_ANIMPATH
    end
    local taiyou = user:create_node()
    --taiyou:set_facing(taiyou_texture)
    taiyou:set_texture(taiyou_texture)
    taiyou:set_layer(-9)
    local offset_x = user:get_tile():width()--/2
    --if user:get_facing() == Direction.Left then offset_x = -offset_x end
    taiyou:set_offset(offset_x,0)
    local taiyou_anim = Engine.Animation.new(taiyou_animpath)
    taiyou_anim:set_state("0")
    taiyou_anim:set_playback(Playback.Loop)
    taiyou_anim:refresh(taiyou)
    local animate_component = Battle.Component.new(user, Lifetimes.Battlestep)
    animate_component.update_func = function(user, dt)
        taiyou_anim:update(dt, taiyou)
    end
    user:register_component(animate_component)

    spell.update_func = function(self)
        self.frames = self.frames + 1
        if self.frames > gundelsol.duration then
            self:delete()
        else
            if (self.frames-(math.floor(self.frames*0.1)*10)) == 1 then
                Engine.play_audio(TAIYOU_AUDIO, AudioPriority.Low)
            end
            if self.frames ~= 1 then
                spell_damage_summon(user, user:get_tile(user:get_facing(), 2))
                spell_damage_summon(user, user:get_tile(user:get_facing(), 2):get_tile(Direction.Up, 1))
                spell_damage_summon(user, user:get_tile(user:get_facing(), 2):get_tile(Direction.Down, 1))
                if gundelsol.type == 4 then
                    spell_damage_summon(user, user:get_tile(user:get_facing(), 3))
                    spell_damage_summon(user, user:get_tile(user:get_facing(), 3):get_tile(Direction.Up, 1))
                    spell_damage_summon(user, user:get_tile(user:get_facing(), 3):get_tile(Direction.Down, 1))
                end
            end
        end
    end
    spell.delete_func = function(self)
        animate_component:eject()
        user:sprite():remove_node(taiyou)
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    return spell
end

gundelsol.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
    local frame1 = {1,0.017}
    local frame2 = {1,0.05}
    local frame3 = {1,0.017}
    local frame4 = {1,0.167}
    local round = function(n) return n >= 0.0 and n-n%-1 or n-n% 1 end
    local frame_to_sec = round(((gundelsol.duration-11)/60)*1000)*0.001 -- Converts frames to seconds.
    local frame5 = {1,frame_to_sec} -- 61/91/121/121
    local frame6 = {1,0.2} -- Stay posed for 11 frames.
    local frame_sequence = make_frame_data({frame1,frame2,frame3,frame4,frame3,frame5,frame6})
    action:override_animation_frames(frame_sequence)
    action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        local buster = self:add_attachment("BUSTER")
        local buster_sprite = buster:sprite()
        buster_sprite:set_texture(Engine.load_texture(_folderpath.."gfx/gundelsol"..gundelsol.type..".png"), true)
        buster_sprite:set_layer(-1)
        local buster_anim = buster:get_animation()
        buster_anim:load(GUNDELSOL_ANIMPATH)
        buster_anim:set_state("0")
        buster_anim:refresh(buster_sprite)
		user:toggle_counter(true)
        Engine.play_audio(CLICK_AUDIO, AudioPriority.Low)
        self:add_anim_action(4, function()
            buster_anim:set_state("1")
            buster_anim:set_playback(Playback.Loop)
            buster_anim:refresh(buster_sprite)
            self.taiyou = summon_sun(user)
            user:get_field():spawn(self.taiyou, user:get_tile())
        end)
        self:add_anim_action(5, function()
            user:toggle_counter(false)
        end)
        self:add_anim_action(7, function()
            buster_anim:set_state("2")
            buster_anim:refresh(buster_sprite)
        end)
    end
    action.action_end_func = function(self)
        debug_print("in custom card action action_end_func()!")
        if self.taiyou and not self.taiyou:is_deleted() then self.taiyou:delete() end
		user:toggle_counter(false)
    end
    return action
end

return gundelsol