local hellsburner = include("hellsburner/hellsburner.lua")

local DAMAGE = 110

hellsburner.codes = {"S","T","U"}
hellsburner.shortname = "HlsBrnr2"
hellsburner.damage = DAMAGE
hellsburner.time_freeze = false
hellsburner.element = Element.Fire
hellsburner.description = "Crcks 3sq\nahd with\nhellfire!"
hellsburner.long_description = "Hellfire attack 3 squares ahead! Cracks panels!"
hellsburner.can_boost = true
hellsburner.card_class = CardClass.Standard
hellsburner.limit = 4
hellsburner.mb = 21

function package_init(package) 
    package:declare_package_id("com.OFC.card.EXE6-020-HellsBurner2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(hellsburner.codes)

    local props = package:get_card_props()
    props.shortname = hellsburner.shortname
    props.damage = hellsburner.damage
    props.time_freeze = hellsburner.time_freeze
    props.element = hellsburner.element
    props.description = hellsburner.description
    props.long_description = hellsburner.long_description
    props.can_boost = hellsburner.can_boost
	props.card_class = hellsburner.card_class
	props.limit = hellsburner.limit
end

card_create_action = hellsburner.card_create_action