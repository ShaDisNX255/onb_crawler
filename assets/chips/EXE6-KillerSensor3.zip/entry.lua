local killersensor = include("killersensor/killersensor.lua")

local DAMAGE = 160

killersensor.sensor_name = "KillerSensor3"
killersensor.sensor_health = 40
killersensor.sensor_palette = "v3"

killersensor.codes = {"I","K","Q"}
killersensor.shortname = "KlrSnsr3"
killersensor.damage = DAMAGE
killersensor.time_freeze = true
killersensor.element = Element.Elec
killersensor.description = "KillrsEye\nbeam attk\nwhen trig"
killersensor.long_description = "Beam attack when triggered by the KillersEye sensor"
killersensor.can_boost = true
killersensor.card_class = CardClass.Standard
killersensor.limit = 3
killersensor.mb = 38

function package_init(package)
    package:declare_package_id("com.OFC.card.EXE6-118-KillerSensor3")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(killersensor.codes)

    local props = package:get_card_props()
    props.shortname = killersensor.shortname
    props.damage = killersensor.damage
    props.time_freeze = killersensor.time_freeze
    props.element = killersensor.element
    props.description = killersensor.description
    props.long_description = killersensor.long_description
    props.can_boost = killersensor.can_boost
	props.card_class = killersensor.card_class
	props.limit = killersensor.limit
end

card_create_action = killersensor.card_create_action