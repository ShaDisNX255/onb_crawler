local lifesynchro = include("lifesynchro/lifesynchro.lua")

local DAMAGE = 0

lifesynchro.codes = {"*"}
lifesynchro.shortname = "LifeSync"
lifesynchro.damage = DAMAGE
lifesynchro.time_freeze = true
lifesynchro.element = Element.Cursor
lifesynchro.description = "Crsr 2sq!\nHP same\nas enemy"
lifesynchro.long_description = "Cursor to the enemy 2 squares ahead! Makes HP same as the enemy's"
lifesynchro.can_boost = false
lifesynchro.card_class = CardClass.Standard
lifesynchro.limit = 5
lifesynchro.mb = 12

function package_init(package)
    package:declare_package_id("com.OFC.card.EXE6-195-LifeSynchro")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(lifesynchro.codes)

    local props = package:get_card_props()
    props.shortname = lifesynchro.shortname
    props.damage = lifesynchro.damage
    props.time_freeze = lifesynchro.time_freeze
    props.element = lifesynchro.element
    props.description = lifesynchro.description
    props.long_description = lifesynchro.long_description
    props.can_boost = lifesynchro.can_boost
	props.card_class = lifesynchro.card_class
	props.limit = lifesynchro.limit
end

card_create_action = lifesynchro.card_create_action