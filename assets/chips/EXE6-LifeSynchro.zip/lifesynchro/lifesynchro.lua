local print_debug = false

local camera_to_tile_x = 20*2
local camera_to_tile_y = 87*2

local CURSOR_TEXTURE = Engine.load_texture(_folderpath.."gfx/cursor.grayscaled.png")
local CURSOR_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/cursor.png")
local CURSOR_ANIMPATH = _folderpath.."gfx/cursor.animation"
local POINT_TEXTURE = Engine.load_texture(_folderpath.."gfx/point.grayscaled.png")
local POINT_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/point.png")
local POINT_ANIMPATH = _folderpath.."gfx/point.animation"

local LOCKON_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_103.ogg", true)
local POINT_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_335.ogg", true)
local BUSTERUP_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_28.ogg", true)
local LIFESYNCHRO_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_196.ogg", true) -- Has a higher priority over the Buster Up SFX.

local function debug_print(text)
    if print_debug then
        print("[LifeSynchro] "..text)
    end
end

local lifesynchro = {}

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function create_pointer(user, field, tile)
    local pointer = graphic_init("artifact", 0, 0, POINT_TEXTURE, POINT_PALETTE, POINT_ANIMPATH, -999, "0", Playback.Loop, user, Direction.Right, false, false, true)
    pointer.frames = 1
    pointer.update_func = function(self)
        for i=1, 49, 16 do
    		if self.frames == i then
    			Engine.play_audio(POINT_AUDIO, AudioPriority.Immediate)
            end
        end
        if self.frames == 62 then
            self:delete()
        end
        self.frames = self.frames + 1
    end
    pointer.battle_end_func = function(self)
        self:delete()
    end
    pointer.delete_func = function(self)
        self:erase()
    end
    field:spawn(pointer, tile)
end

lifesynchro.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
	action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        local actor = self:get_actor()
        local orig_speed = actor:get_animation():get_playback_speed()
        actor:get_animation():set_playback_speed(0)

        local facing_away = user:get_facing_away()
        local facing = user:get_facing()
        local field = user:get_field()
        local team = user:get_team()
        --
        -- Cursor uses unique offsets for every Character.
		self.cursor = graphic_init("artifact", 0, 0, CURSOR_TEXTURE, CURSOR_PALETTE, CURSOR_ANIMPATH, -3, "0", Playback.Once, user, facing_away)
        self.cursor.frames = 1
        self.cursor.update_func = function(c)
            if c.frames == 99 then
                c:delete()
            end
            c.frames = c.frames + 1
        end
        self.cursor.battle_end_func = function(c)
            c:delete()
        end
        self.cursor.delete_func = function(c)
            c:erase()
        end
        --
        local query_pe = function(c)
            return Battle.Player.from(c) ~= nil and not c:is_team(team)
        end
        local player_enemies = field:find_characters(query_pe)
        local query0 = function(c)
            return c:get_name() == "SummonedCharacter" or c:get_animation():has_state("NO_LIFESYNC")
        end
        local query1 = function(c)
            return c:get_health() > 0 and not c:is_team(team)
        end
		self.frames = 1
		self.target_found = 0
		self.target_hp = 0
        self.target_tile = nil
        local query2 = function(c)
            return c:get_tile() ~= self.target_tile and c:get_health() > 0 and not c:is_team(team)
        end
		self.enemies_t = nil
		self.enemies = nil
        self.synchro_sound = nil
		local step1 = Battle.Step.new()
		step1.update_func = function()
            for i=11, 59, 16 do
				if self.frames == i then
                end
            end
            if #player_enemies == 0 then
                if self.target_found == 0 then
			        Engine.play_audio(LOCKON_AUDIO, AudioPriority.Immediate)
                end
			    if self.frames == 1 then
                    local tile = user:get_tile(facing,2)
                    if tile and not tile:is_edge() then
                        local enemies_t = tile:find_characters(query1)
                        if #enemies_t>0 then
                            self.target_hp = enemies_t[1]:get_health()
                            self.target_tile = enemies_t[1]:get_tile()
                            local anim = enemies_t[1]:get_animation()
                            local origin = anim:point("ORIGIN")
                            --print(origin.x,origin.y)
                            local origin_b = anim:point("COPYDAMAGE")
                            --print(origin_b.x,origin_b.y)
                            local offset_x = (origin_b.x-origin.x)*2
                            --print(offset_x)
                            local offset_y = (origin_b.y-origin.y)*2
                            --print(offset_y)
                            if origin_b.x == 0 and origin_b.y == 0 then
                                offset_x = 0
                                offset_y = -enemies_t[1]:get_height()/2
                            end
                            if facing_away == Direction.Left then 
                                offset_x = -offset_x
                            end
                            self.cursor:set_offset(offset_x,0)
                            self.cursor:set_elevation(-offset_y)
                            self.target_found = 1
                        end
                        field:spawn(self.cursor, tile)
                    end
                end
                if self.target_found == 1 then
			        if self.frames == 23 then
                        local charas = field:find_characters(query0)
                        if #charas>0 then
                            self.target_found = -1
                        else
                            self.enemies_t = field:find_tiles(function(t)
                                return t and not t:is_edge() and t ~= self.target_tile and #t:find_characters(query1)>0
                            end)
                            self.enemies = field:find_characters(query1)
                            if #self.enemies>=2 and #self.enemies_t>0 then
                                for i=1,#self.enemies_t do
                                    create_pointer(user, field, self.enemies_t[i])
                                end
                            else
                                self.target_found = -1
                            end
                        end
                    end
			        if self.frames == 81 then
                        self.cursor:delete()
                    end
			        if self.frames == 83 then
                        self.enemies = field:find_characters(query2)
                        for i=1,#self.enemies do
                            if self.enemies[i]:get_health() < self.target_hp then
                                self.synchro_sound = BUSTERUP_AUDIO
                            else
                                self.synchro_sound = LIFESYNCHRO_AUDIO
                                break
                            end
                        end
                        Engine.play_audio(self.synchro_sound, AudioPriority.Immediate)
                        for i=1,#self.enemies do
                            self.enemies[i]:set_health(self.target_hp)
                        end
                    end
                else
                    if self.frames == 20 then
                        self.target_found = -1
                    end
                end
            end
			if (self.frames == 51 and self.target_found ~= 1) or (self.frames == 116 and self.target_found == 1) then
                actor:get_animation():set_playback_speed(orig_speed)
				step1:complete_step()
            end
			self.frames = self.frames + 1
		end
		self:add_step(step1)
	end
	return action
end

return lifesynchro