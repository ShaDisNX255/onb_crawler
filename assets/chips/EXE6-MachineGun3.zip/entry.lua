local machinegun = include("machinegun/machinegun.lua")

local DAMAGE = 70

machinegun.codes = {"B","F","M"}
machinegun.shortname = "MchnGun3"
machinegun.damage = DAMAGE
machinegun.time_freeze = false
machinegun.element = Element.Cursor
machinegun.description = "Fire 9sts\nat row w/\nclst enmy"
machinegun.long_description = "Fire 9 shots at the row with the closest enemy!"
machinegun.can_boost = true
machinegun.card_class = CardClass.Standard
machinegun.limit = 3
machinegun.mb = 36

function package_init(package) 
    package:declare_package_id("com.OFC.card.EXE6-057-MachineGun3")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(machinegun.codes)

    local props = package:get_card_props()
    props.shortname = machinegun.shortname
    props.damage = machinegun.damage
    props.time_freeze = machinegun.time_freeze
    props.element = machinegun.element
    props.description = machinegun.description
    props.long_description = machinegun.long_description
    props.can_boost = machinegun.can_boost
	props.card_class = machinegun.card_class
	props.limit = machinegun.limit
end

card_create_action = machinegun.card_create_action