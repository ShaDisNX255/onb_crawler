local print_debug = false

local AUDIO_DAMAGE_ENEMY = Engine.load_audio(_folderpath.."sfx/EXE6_50.ogg", true)
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."sfx/EXE6_131.ogg", true)

local CANNON_TEXTURE --= Engine.load_texture(_folderpath.."gfx/cannon.grayscaled.png")
local CANNON_ANIMPATH = _folderpath.."gfx/cannon.animation"
local BOOM_TEXTURE = Engine.load_texture(_folderpath.."gfx/boom.png")
local BOOM_ANIMPATH = _folderpath.."gfx/boom.animation"

local CANNON_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_278.ogg", true)

local function debug_print(text)
    if print_debug then
        print("[Cannon] "..text)
    end
end

local cannon = {}

--(Function by Alrysc)
local function graphic_init(g_type, x, y, texture, animation, state, anim_playback, layer, user, facing, flip)
    flip = flip or false
    facing = facing or nil
    
    local graphic = nil
    if g_type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif g_type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    end

    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then
        graphic:set_facing(facing)
    end
    
    if user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    graphic:get_animation():refresh(graphic:sprite())
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end

    return graphic
end

local function create_attack(user, props, tile)
	local spell = Battle.Spell.new(user:get_team())
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            props.element,
            user:get_context(),
            Drag.None
        )
    )
	spell.slide_started = false
	spell.on_spawn_func = function()
		debug_print("attack spawned at tile ("..tile:x()..";"..tile:y()..")")
	end
	spell.update_func = function(self) 
        self:get_tile():attack_entities(self)
        if not self:is_sliding() then
            if self:get_tile():is_edge() and self.slide_started then 
                self:erase()
            end 
            local dest = self:get_tile(self:get_facing(), 1)
            local ref = self
            self:slide(dest, frames(0), frames(0), ActionOrder.Voluntary, function()
                ref.slide_started = true 
            end)
        end
    end
	spell.collision_func = function(self)
		self:erase()
	end
    spell.attack_func = function(self, other)
		debug_print("attacked tile ("..other:get_tile():x()..";"..other:get_tile():y()..")")
		local offset_x = math.random(-8,7)
		local offset_y = math.random(-32,-20)
		local hit_effect = graphic_init("artifact", (offset_x*2), (offset_y*2), BOOM_TEXTURE, BOOM_ANIMPATH, "0", Playback.Once, -999, user, Direction.Right, true)
		hit_effect:get_animation():on_complete(function() hit_effect:erase() end)
		user:get_field():spawn(hit_effect, other:get_tile())
		if Battle.Obstacle.from(other) == nil then
			if Battle.Player.from(user) ~= nil then
				Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
			end
		else
			Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		end
	end
    spell.can_move_to_func = function(tile)
        return true
    end
	user:get_field():spawn(spell, tile)
	return spell
end
--[[
local function end_action(user, props)
    debug_print("in create_card_action()!")
    local action
	local frame_sequence
	if user:get_animation():has_state("PLAYER_THROW52") then
		action = Battle.CardAction.new(user, "PLAYER_THROW52")
		frame_sequence = make_frame_data({{6,0.017}, {7,0.05}})
	else
		action = Battle.CardAction.new(user, "PLAYER_THROW")
		frame_sequence = make_frame_data({{5,0.05}})
	end
	action:override_animation_frames(frame_sequence)
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
	end
	action.action_end_func = function()
        debug_print("in custom card action action_end_func()!")
	end
    return action
end
]]
cannon.card_create_action = function(user, props)
--local function cannon_action(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
	local frame1 = {1,0.033} -- (+)1 frame
	local frame2 = {1,0.017}
	local frame3 = {1,0.083}
	local frame4 = {2,0.017}
	local frame5 = {2,0.017}
	local frame6 = {3,0.017}
	local frame7 = {3,0.067}
	local frame8 = {3,0.15} -- (-)1 frame
	--local frame8 = {3,0.017} -- (-)1 frame
	local frame_sequence = make_frame_data({frame1, frame2, frame3, frame4, frame5, frame6, frame7, frame8})
	local original_offset = user:get_offset()
	action:override_animation_frames(frame_sequence)
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(Engine.load_texture(_folderpath.."gfx/cannon"..cannon.type..".png"), true)
		--buster:sprite():set_texture(CANNON_TEXTURE)
        --buster:sprite():set_palette(Engine.load_texture(cannon.palette))
		buster:sprite():set_layer(-1)
		local buster_anim = buster:get_animation()
		buster_anim:load(CANNON_ANIMPATH)
		buster_anim:set_state("0")
		user:toggle_counter(true)
		self:add_anim_action(4, function()
			Engine.play_audio(CANNON_AUDIO, AudioPriority.Low)
			if user:get_facing() == Direction.Right then
				user:set_offset(original_offset.x - 4*2, original_offset.y)
			else
				user:set_offset(original_offset.x + 4*2, original_offset.y)
			end
		end)
		self:add_anim_action(5, function()
			if user:get_facing() == Direction.Right then
				user:set_offset(original_offset.x - 5*2, original_offset.y)
			else
				user:set_offset(original_offset.x + 5*2, original_offset.y)
			end
		end)
		self:add_anim_action(6, function()
			if user:get_facing() == Direction.Right then
				user:set_offset(original_offset.x - 6*2, original_offset.y)
			else
				user:set_offset(original_offset.x + 6*2, original_offset.y)
			end
			create_attack(user, props, user:get_tile(user:get_facing(), 1))
		end)
		self:add_anim_action(7, function()
			if user:get_facing() == Direction.Right then
				user:set_offset(original_offset.x - 8*2, original_offset.y)
			else
				user:set_offset(original_offset.x + 8*2, original_offset.y)
			end
		end)
		self:add_anim_action(8, function()
			user:toggle_counter(false)
		end)
		--[[
		self:add_anim_action(8, function()
			local action2 = end_action(user, props)
			user:card_action_event(action2, ActionOrder.Immediate)
		end)
		]]
	end
	action.action_end_func = function()
        debug_print("in custom card action action_end_func()!")
		user:toggle_counter(false)
		user:set_offset(original_offset.x, original_offset.y)
	end
    return action
end
--[[
cannon.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action
	local frame_sequence
    local action_frame = 0
	if user:get_animation():has_state("PLAYER_THROW52") then
		action = Battle.CardAction.new(user, "PLAYER_THROW52")
		frame_sequence = make_frame_data({{7,0.017}, {6,0.033}, {6,0.017}})
		action_frame = 3
	else
		action = Battle.CardAction.new(user, "PLAYER_THROW")
		frame_sequence = make_frame_data({{5,0.05}, {5,0.017}})
		action_frame = 2
	end
	action:override_animation_frames(frame_sequence)
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
		user:toggle_counter(true)
		self:add_anim_action(action_frame, function()
			local action2 = cannon_action(user, props)
			user:card_action_event(action2, ActionOrder.Immediate)
		end)
	end
	action.action_end_func = function()
        debug_print("in custom card action action_end_func()!")
		user:toggle_counter(false)
	end
    return action
end
]]
return cannon