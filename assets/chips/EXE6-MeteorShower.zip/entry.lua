local ryuuseigun = include("ryuuseigun/ryuuseigun.lua")

local DAMAGE = 40

ryuuseigun.codes = {"R"}
ryuuseigun.shortname = "MteoShwr"
ryuuseigun.damage = DAMAGE
ryuuseigun.time_freeze = true
ryuuseigun.element = Element.Fire
ryuuseigun.description = "Drop many\nmeteor on\nenmy area"
ryuuseigun.long_description = "Numerous meteors rain down on the enemy area!"
ryuuseigun.can_boost = true
ryuuseigun.card_class = CardClass.Standard
ryuuseigun.limit = 1
ryuuseigun.mb = 73

function package_init(package)
    package:declare_package_id("com.OFC.card.EXE6-111-Ryuuseigun")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes(ryuuseigun.codes)

    local props = package:get_card_props()
    props.shortname = ryuuseigun.shortname
    props.damage = ryuuseigun.damage
    props.time_freeze = ryuuseigun.time_freeze
    props.element = ryuuseigun.element
    props.description = ryuuseigun.description
    props.long_description = ryuuseigun.long_description
    props.can_boost = ryuuseigun.can_boost
	props.card_class = ryuuseigun.card_class
	props.limit = ryuuseigun.limit
end

card_create_action = ryuuseigun.card_create_action