local print_debug = false

local METEOR_TEXTURE = Engine.load_texture(_folderpath.."gfx/meteor.grayscaled.png")
local METEOR_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/meteor.png")
local METEOR_ANIMPATH = _folderpath.."gfx/meteor.animation"
local BOOM_TEXTURE = Engine.load_texture(_folderpath.."gfx/boom.grayscaled.png") -- flip for Player 2?
local BOOM_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/boom.png")
local BOOM_ANIMPATH = _folderpath.."gfx/boom.animation"
local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect.grayscaled.png") -- flip for Player 2?
local EFFECT_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect.png")
local EFFECT_ANIMPATH = _folderpath.."gfx/effect.animation"

local METEOR_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_221.ogg", true)
local BOOM_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_132.ogg", true)

local function debug_print(text)
    if print_debug then
        print("[Ryuuseigun] "..text)
    end
end

local ryuuseigun = {}

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function create_boom(user, props, team, facing, field, tile)
    local query = function(e)
        return e:get_health() > 0 and not e:is_team(team)
    end
    if not tile or (tile:is_hole() and (#tile:find_characters(query) <= 0 and #tile:find_obstacles(query) <= 0)) then return end
	Engine.play_audio(BOOM_AUDIO, AudioPriority.Immediate)
    local boom_fx = graphic_init("artifact", 0, 0, BOOM_TEXTURE, BOOM_PALETTE, BOOM_ANIMPATH, -99, "0", Playback.Once, user, facing, true, true, true)
    field:spawn(boom_fx, tile)
    local boom_hit = Battle.Spell.new(team)
    boom_hit:set_facing(facing)
    boom_hit:set_hit_props(
        HitProps.new()
        :dmg(props.damage)
        :impact()
        :flinch()
        :flash()
        :pierce_ground()
        :retangible()
        :no_counter()
        :elem(props.element)
        :from(user:get_context())
    )
    boom_hit.update_func = function(self)
        self:get_tile():attack_entities(self)
	    self:shake_camera(10, 0.233)
        self:delete()
    end
    boom_hit.attack_func = function(self, other, judge)
		debug_print("attacked tile ("..other:get_tile():x()..";"..other:get_tile():y()..")")
        if not judge:hint_spawn_gfx() then return end
        local offset_y = math.random(-8,5)
        local offset_x = math.random(-7,6)
        local hit_effect = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT_TEXTURE, EFFECT_PALETTE, EFFECT_ANIMPATH, -999, "0", Playback.Once, user, facing, true, true, true)
        field:spawn(hit_effect, other:get_tile())
	end
    boom_hit.battle_end_func = function(self)
        self:delete()
    end
    boom_hit.delete_func = function(self)
        self:erase()
    end
    field:spawn(boom_hit, tile)
end

local function create_meteor(user, props, team, facing, field, tile)
    if not tile or tile:is_edge() then return end
    local meteor = graphic_init("spell", -((16*2)*16), -((16*2)*16), METEOR_TEXTURE, METEOR_PALETTE, METEOR_ANIMPATH, -3, "0", Playback.Loop, user, facing, false, true)
    meteor.frames = 0
    meteor.falling = false
    meteor.x_speed = (16*2)
    if facing == Direction.Left then meteor.x_speed = -meteor.x_speed end
    meteor.update_func = function(self)
        self:highlight_tile(Highlight.Flash)
        self.frames = self.frames + 1
        if self.frames == 37-1 then
			Engine.play_audio(METEOR_AUDIO, AudioPriority.Immediate)
            self.falling = true
        end
        if self.falling then
            if self:get_offset().y >= 0 then
                create_boom(user, props, team, facing, field, tile)
                self:delete()
            else
                self:set_offset(self:get_offset().x+self.x_speed, self:get_offset().y+(16*2))
            end
        end
    end
    meteor.battle_end_func = function(self)
        self:delete()
    end
    meteor.delete_func = function(self)
        self:erase()
    end
    field:spawn(meteor, tile)
    return meteor
end

ryuuseigun.card_create_action = function(user, props) --3, 13
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
    action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        local actor = self:get_actor()
        local orig_speed = actor:get_animation():get_playback_speed()
        actor:get_animation():set_playback_speed(0)
        
		local facing = user:get_facing()
        local field = user:get_field()
		local team = user:get_team()
		local a_frames = 1
		local step1 = Battle.Step.new()

        local tile = field:tile_at(1,1)
		if facing == Direction.Right then tile = field:tile_at(field:width(),1) end
        local tile_array = {}
        local tile_array_n = 0
		local tile_front = nil
		local tile_down = nil
		local check1 = false
		local check_front = false
		local check_down = false
		local stop = true

        for i=1, field:width() do
            tile_front = tile:get_tile(Direction.reverse(facing), i)
            for j=1, field:height() do
                tile_down = tile_front:get_tile(Direction.Down, j-1)
                check_down = tile_down and not tile_down:is_edge() and user:is_team(tile_down:get_team())
                if check_down and stop then
                    tile_array_n = tile_array_n + 1
                    if j == field:height() and tile_array_n == field:height() then
                        table.insert(tile_array, tile_front)
                        stop = false
                        break
                    end
                end
            end
            debug_print("tile at ("..tile_front:x().."x, "..tile_front:y().."y) has been skipped")
        end

        local meteor_array = {}
        local scan_start = 1
        local scan_end = field:width()
        local scan_mid = 1
        if facing == Direction.Right then
            scan_start = field:width()
            scan_end = 1
            scan_mid = -1
        end
        local scan_pause = false
        for i=1, 30 do
            for i=scan_start, scan_end, scan_mid do
                if i==scan_start then scan_pause = false end
                for j=1, field:height() do
                    local target_tile = field:tile_at(i,j)
                    tile_check = target_tile and not target_tile:is_edge() and not user:is_team(target_tile:get_team())
                    if tile_array[1] ~= nil and target_tile == tile_array[1] then scan_pause = true end
                    if tile_check and not scan_pause then
                        debug_print("TILE("..target_tile:x()..";"..target_tile:y()..") TARGETED")
                        table.insert(meteor_array, target_tile)
                    end
                end
		    end
        end

        step1.update_func = function(self)
            for i=1, 30 do
                if a_frames == 1+((i-1)*10) then
                    create_meteor(user, props, team, facing, field, meteor_array[i])
                end
            end
            if a_frames >= 400 then
                actor:get_animation():set_playback_speed(orig_speed)
                self:complete_step()
            end
            a_frames = a_frames + 1
        end
		self:add_step(step1)
    end
    return action
end

return ryuuseigun