local print_debug = false

local POINT_TEXTURE = Engine.load_texture(_folderpath.."gfx/point.grayscaled.png")
local POINT_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/point.png")
local POINT_ANIMPATH = _folderpath.."gfx/point.animation"
local POINT_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_335.ogg", true)

local function debug_print(text)
    if print_debug then
        print("[CustomGauge] "..text)
    end
end

local customgauge = {}

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

customgauge.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
	action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        local actor = self:get_actor()
        local orig_speed = actor:get_animation():get_playback_speed()
        actor:get_animation():set_playback_speed(0)

		local field = user:get_field()
		self.frames = 1
		self.point = nil
		local step1 = Battle.Step.new()
		step1.update_func = function()
            for i=11, 59, 16 do
				if self.frames == i then
					Engine.play_audio(POINT_AUDIO, AudioPriority.Immediate)
                end
            end
			if self.frames == 1 then
                local tile = field:tile_at(field:width()+1,field:height()+1)
                local x = -(tile:width()*3+tile:width()/2)
                local y = -(tile:height()*5-3*2)
                self.point = graphic_init("artifact", x, y, POINT_TEXTURE, POINT_PALETTE, POINT_ANIMPATH, -999, "0", Playback.Loop, user, Direction.Right, false, false, true)
                field:spawn(self.point, tile)
            end
			if self.frames == 73 then
                self.point:erase()
		        Battle.set_cust_gauge_max_time(frames(customgauge.time_frames))
                user:get_animation():set_playback_speed(orig_speed)
				step1:complete_step()
            end
			self.frames = self.frames + 1
		end
		self:add_step(step1)
	end
	return action
end

return customgauge