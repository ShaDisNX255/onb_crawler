local customgauge = include("customgauge/customgauge.lua")

local DAMAGE = 0

customgauge.time_frames = 256

customgauge.codes = {"E","M","R","*"}
customgauge.shortname = "QckGauge"
customgauge.damage = DAMAGE
customgauge.time_freeze = true
customgauge.element = Element.None
customgauge.description = "CustGauge\nspeed-up"
customgauge.long_description = "Increases CustomGauge's speed"
customgauge.can_boost = false
customgauge.card_class = CardClass.Standard
customgauge.limit = 2
customgauge.mb = 48

function package_init(package)
    package:declare_package_id("com.OFC.card.EXE6-175-QuickGauge")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(customgauge.codes)

    local props = package:get_card_props()
    props.shortname = customgauge.shortname
    props.damage = customgauge.damage
    props.time_freeze = customgauge.time_freeze
    props.element = customgauge.element
    props.description = customgauge.description
    props.long_description = customgauge.long_description
    props.can_boost = customgauge.can_boost
	props.card_class = customgauge.card_class
	props.limit = customgauge.limit
end

card_create_action = customgauge.card_create_action