local print_debug = false

local RECOVERY_TEXTURE = Engine.load_texture(_folderpath.."gfx/recovery.grayscaled.png") -- flip for player 2
local RECOVERY_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/recovery.png")
local RECOVERY_ANIMPATH = _folderpath.."gfx/recovery.animation"
local RECOVERY_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_108.ogg", true)

local function debug_print(text)
    if print_debug then
        print("[Recovery] "..text)
    end
end

local recovery = {}

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

recovery.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
    action:set_lockout(make_async_lockout(0.5))
    local frame_sequence = make_frame_data({{1,0}})
	action:override_animation_frames(frame_sequence)
    action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        local facing = user:get_facing()
        local field = user:get_field()
        local tile = user:get_tile()
        local heal_fx = graphic_init("artifact", 0, 0, RECOVERY_TEXTURE, RECOVERY_PALETTE, RECOVERY_ANIMPATH, -999, "0", Playback.Once, user, facing, true, true, true)
        field:spawn(heal_fx, tile)
        user:set_health(user:get_health() + recovery.recover_hp)
        Engine.play_audio(RECOVERY_AUDIO, AudioPriority.Immediate)
	end
    return action
end

return recovery