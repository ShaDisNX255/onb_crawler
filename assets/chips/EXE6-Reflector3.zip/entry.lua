local reflecmet = include("reflecmet/reflecmet.lua")

local DAMAGE = 200

reflecmet.shield_type1 = "2"
reflecmet.shield_type2 = "3"
reflecmet.shield_palette = "metguard3"

reflecmet.codes = {"E","F","O","*"}
reflecmet.shortname = "RflecMt3"
reflecmet.damage = DAMAGE
reflecmet.time_freeze = false
reflecmet.element = Element.None
reflecmet.description = "Bounce an\nattk back\nat enemy!"
reflecmet.long_description = "Guard against enemy attacks and bounce them back in a shockwave!"
reflecmet.can_boost = true
reflecmet.card_class = CardClass.Standard
reflecmet.limit = 4
reflecmet.mb = 25

function package_init(package)
    package:declare_package_id("com.OFC.card.EXE6-093-ReflecMet3")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes(reflecmet.codes)

    local props = package:get_card_props()
    props.shortname = reflecmet.shortname
    props.damage = reflecmet.damage
    props.time_freeze = reflecmet.time_freeze
    props.element = reflecmet.element
    props.description = reflecmet.description
    props.long_description = reflecmet.long_description
    props.can_boost = reflecmet.can_boost
	props.card_class = reflecmet.card_class
	props.limit = reflecmet.limit
end

card_create_action = reflecmet.card_create_action