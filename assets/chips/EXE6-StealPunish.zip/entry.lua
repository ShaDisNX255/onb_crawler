local stealpunish = include("stealpunish/stealpunish.lua")

local DAMAGE = 0

stealpunish.ball_damage = 20

stealpunish.codes = {"B","M","S"}
stealpunish.shortname = "StelPnsh"
stealpunish.damage = DAMAGE
stealpunish.time_freeze = true
stealpunish.element = Element.None
stealpunish.description = "20 damage\nfor every\nstolen sq"
stealpunish.long_description = "20 damage to the opponent for every stolen panel!"
stealpunish.can_boost = false
stealpunish.card_class = CardClass.Standard
stealpunish.limit = 4
stealpunish.mb = 24

function package_init(package) 
    package:declare_package_id("com.OFC.card.EXE6-166-StealPunish")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(stealpunish.codes)

    local props = package:get_card_props()
    props.shortname = stealpunish.shortname
    props.damage = stealpunish.damage
    props.time_freeze = stealpunish.time_freeze
    props.element = stealpunish.element
    props.description = stealpunish.description
    props.long_description = stealpunish.long_description
    props.can_boost = stealpunish.can_boost
	props.card_class = stealpunish.card_class
	props.limit = stealpunish.limit
end

card_create_action = stealpunish.card_create_action