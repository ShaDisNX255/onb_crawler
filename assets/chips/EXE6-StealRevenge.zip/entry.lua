local stealpunish = include("stealpunish/stealpunish.lua")

local DAMAGE = 0

stealpunish.ball_damage = 40

stealpunish.codes = {"I","Q","Z"}
stealpunish.shortname = "StelRvng"
stealpunish.damage = DAMAGE
stealpunish.time_freeze = true
stealpunish.element = Element.None
stealpunish.description = "40 damage\nfor every\nstolen sq"
stealpunish.long_description = "40 damage to the opponent for every stolen panel!"
stealpunish.can_boost = false
stealpunish.card_class = CardClass.Standard
stealpunish.limit = 1
stealpunish.mb = 50

function package_init(package) 
    package:declare_package_id("com.OFC.card.EXE6-167-StealRevenge")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(stealpunish.codes)

    local props = package:get_card_props()
    props.shortname = stealpunish.shortname
    props.damage = stealpunish.damage
    props.time_freeze = stealpunish.time_freeze
    props.element = stealpunish.element
    props.description = stealpunish.description
    props.long_description = stealpunish.long_description
    props.can_boost = stealpunish.can_boost
	props.card_class = stealpunish.card_class
	props.limit = stealpunish.limit
end

card_create_action = stealpunish.card_create_action