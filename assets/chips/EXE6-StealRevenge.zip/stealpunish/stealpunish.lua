local print_debug = false

local STEAL_TEXTURE = Engine.load_texture(_folderpath.."gfx/steal.grayscaled.png")
local STEAL_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/steal.png")
local STEAL_ANIMPATH = _folderpath.."gfx/steal.animation"

local STEAL_AUDIO_START = Engine.load_audio(_folderpath.."sfx/EXE6_134.ogg", true)
local STEAL_AUDIO_END = Engine.load_audio(_folderpath.."sfx/EXE6_242.ogg", true)
local POINT_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_335.ogg", true)

local FieldHelper = include("FieldHelper.lua")

local function debug_print(text)
    if print_debug then
        print("[StealPunish] "..text)
    end
end

local stealpunish = {}

--(Function by Alrysc)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function create_reclaimer(user, team, field, s_tile, e_tile, m_tile)
    local spell = Battle.Spell.new(team)
    local query = function(targ)
        return targ:get_health() > 0 and not targ:is_team(team)
    end
    spell.update_func = function(self)
        local t_numb = 0
        local t_mult = 0
        for i=s_tile:x(), e_tile:x(), m_tile do
            t_mult = t_mult + 1
            for j=1, field:height() do
                local n_tile = field:tile_at(i,j)
                if #n_tile:find_characters(query) <= 0 and #n_tile:find_obstacles(query) <= 0 then
                    --print("Tile START: "..s_tile:x()..";"..s_tile:y())
                    t_numb = t_numb + 1
                end
            end
        end
        if t_numb >= field:height()*t_mult then
            for i=s_tile:x(), e_tile:x(), m_tile do
                for j=1, field:height() do
                    local n_tile = field:tile_at(i,j)
                    if #n_tile:find_characters(query) <= 0 and #n_tile:find_obstacles(query) <= 0 then
                        --print("Tile START: "..s_tile:x()..";"..s_tile:y())
                        n_tile:set_team(team, true)
                    end
                end
            end
            self:delete()
        end
    end
    spell.delete_func = function(self)
        self:erase()
    end
    field:spawn(spell, s_tile)
    return spell
end

local function reclaim_area(user, team, field)
    local check_row = 2
    local check_row_end = 3
    local check_row_mid = 1
    if user:get_facing() == Direction.Left then
        check_row = 5
        check_row_end = 4
        check_row_mid = -1
    end
    create_reclaimer(user, team, field, user:get_field():tile_at(check_row, 1), user:get_field():tile_at(check_row, 1), check_row_mid)
    create_reclaimer(user, team, field, user:get_field():tile_at(check_row, 1), user:get_field():tile_at(check_row_end, 1), check_row_mid)
end

local function create_hitbox_flash_yes(user, team, tile)
    local spell = Battle.Spell.new(team)
	spell:set_hit_props(
        HitProps.new()
        :dmg(0)
        :flinch()
        :flash()
        :no_counter()
        :from(user:get_context())
    )
    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end
    spell.delete_func = function(self)
        self:erase()
    end
    user:get_field():spawn(spell, tile)
    return spell
end

local function create_hitbox_flash_no(user, team, tile)
    local spell = Battle.Spell.new(team)
	spell:set_hit_props(
        HitProps.new()
        :dmg(0)
        :flinch()
        :pierce()
        :retangible()
        :no_counter()
        :from(user:get_context())
    )
    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end
    spell.delete_func = function(self)
        self:erase()
    end
    user:get_field():spawn(spell, tile)
    return spell
end

local function create_noflasher(user, facing, team, tile, target)
    local spell = Battle.Spell.new(team)
    spell:set_facing(facing)
    if not target then
        print("NO TARGET")
    end
    spell.update_func = function(self)
        if target:is_sliding() then
            print("sliding")
            create_hitbox_flash_no(user, team, target:get_tile())
        else
            print("NO sliding")
            create_hitbox_flash_yes(user, team, target:get_tile())
            self:delete()
        end
        --[[
        if target.can_move_to_func(self:get_tile(self:get_facing(), 1)) then
            create_hitbox_flash_no(user, team, target:get_tile())
        else
            if not target:is_sliding() then
                create_hitbox_flash_yes(user, team, target:get_tile())
                self:delete()
            end
        end
        ]]
        if self:get_tile() ~= target:get_tile() then
            self:teleport(target:get_tile(), ActionOrder.Immediate)
        end
    end
    spell.delete_func = function(self)
        print("stop NOFLASH")
        self:erase()
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    user:get_field():spawn(spell, tile)
    return spell
end

local function create_hitbox(user, props, facing, field, team, tile, targeting)
    local spell = Battle.Spell.new(team)
    spell:set_facing(facing)
	spell:set_hit_props(
        HitProps.new()
        :dmg(stealpunish.ball_damage)
        :impact()
        :flinch()
        :flash()
        :pierce()
        :pierce_ground()
        :retangible()
        :no_counter()
        :drg(Drag.new(facing, field:width()))
        :from(user:get_context())
    )
    spell.update_func = function(self, other)
        self:get_tile():attack_entities(self)
        self:delete()
    end
    spell.attack_func = function(self, other)
        if targeting then
            --create_noflasher(user, facing, team, tile, other)
        end
    end
    spell.delete_func = function(self)
        self:erase()
    end
    field:spawn(spell, tile)
    return spell
end

local function MakeTileSplash(user, props, facing, field, team, tile, targeting)
    local artifact = graphic_init("artifact", 0, -432, STEAL_TEXTURE, STEAL_PALETTE, STEAL_ANIMPATH, -3, "0", Playback.Loop, user, facing, false, false, true)
	local doOnce = false
	artifact.update_func = function(self, dt)
		if self:get_offset().y >= 0 then
			if not doOnce then
				self:set_offset(0,0)
				self:get_animation():set_state("1")
                self:get_animation():refresh(self:sprite())
                self:get_animation():set_playback(Playback.Once)
				self:get_animation():on_frame(1, function()
					Engine.play_audio(STEAL_AUDIO_END, AudioPriority.Immediate)
				end)
				create_hitbox(user, props, facing, field, team, tile, targeting)
				doOnce = true
			end
			self:get_animation():on_complete(function()
				self:delete()
			end)
		else
			self:set_offset(0, self:get_offset().y + (8*2))
		end
	end
	artifact.delete_func = function(self)
		self:erase()
	end
    field:spawn(artifact, tile)
	return artifact
end

stealpunish.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
    action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        local actor = self:get_actor()
        local orig_speed = actor:get_animation():get_playback_speed()
        actor:get_animation():set_playback_speed(0)
        
		local facing = user:get_facing()
        local field = user:get_field()
		local team = user:get_team()
		local a_frames = 1
		local step1 = Battle.Step.new()

        local enemy_curtile = nil
        local user_tiles = FieldHelper.get_stolen_tiles(user)

        step1.update_func = function(self)
            if a_frames == 1 then
                if user_tiles[1] ~= nil then
                    Engine.play_audio(POINT_AUDIO, AudioPriority.Immediate)
                    for i=1, #user_tiles do
                        local marker = graphic_init("artifact", 0, 0, STEAL_TEXTURE, STEAL_PALETTE, STEAL_ANIMPATH, -3, "1", Playback.Once, user, facing, false, false, true)
                        marker:get_animation():on_complete(function() marker:erase() end)
                        field:spawn(marker, user_tiles[i])
                    end
                else
                    actor:get_animation():set_playback_speed(orig_speed)
                    self:complete_step()
                end
            elseif a_frames >= 32*#user_tiles+32*2 then
                if FieldHelper.is_userarea_disadvantaged(user) then
                    reclaim_area(user, team, field)
                end
                actor:get_animation():set_playback_speed(orig_speed)
                self:complete_step()
            end
            for i=32, 32*#user_tiles, 32 do
                if a_frames == i then
                    local target = field:find_nearest_characters(user, function(t)
                        return t and t:get_health() > 0 and not t:is_team(team)
                    end)
                    if target[1] ~= nil then
                        enemy_curtile = target[1]:get_tile()
                    end
                    if enemy_curtile ~= nil then
                        Engine.play_audio(STEAL_AUDIO_START, AudioPriority.Immediate)
                        if a_frames == 32*#user_tiles then
                            MakeTileSplash(user, props, facing, field, team, enemy_curtile, true)
                        else
                            MakeTileSplash(user, props, facing, field, team, enemy_curtile)
                        end
                    end
                end
            end
            a_frames = a_frames + 1
        end
		self:add_step(step1)
    end
    return action
end

return stealpunish