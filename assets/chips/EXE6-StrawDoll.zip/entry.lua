local waraningyou = include("waraningyou/waraningyou.lua")

local DAMAGE = 0

waraningyou.codes = {"F","N","S","*"}
waraningyou.shortname = "StrawDol"
waraningyou.damage = DAMAGE
waraningyou.time_freeze = false
waraningyou.element = Element.Summon
waraningyou.description = "Throw a\ncrsd doll\n3sq ahead"
waraningyou.long_description = "Throw a frightening cursed straw doll 3 squares ahead"
waraningyou.can_boost = false
waraningyou.card_class = CardClass.Standard
waraningyou.limit = 3
waraningyou.mb = 39

function package_init(package) 
    package:declare_package_id("com.OFC.card.EXE6-153-WaraNingyou")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(waraningyou.codes)

    local props = package:get_card_props()
    props.shortname = waraningyou.shortname
    props.damage = waraningyou.damage
    props.time_freeze = waraningyou.time_freeze
    props.element = waraningyou.element
    props.description = waraningyou.description
    props.long_description = waraningyou.long_description
    props.can_boost = waraningyou.can_boost
	props.card_class = waraningyou.card_class
	props.limit = waraningyou.limit
end

card_create_action = waraningyou.card_create_action