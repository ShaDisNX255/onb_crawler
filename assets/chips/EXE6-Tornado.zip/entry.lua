local tornado = include("tornado/tornado.lua")

local DAMAGE = 20

tornado.type = "Tornado"

tornado.codes = {"L","R","T"}
tornado.shortname = "Tornado"
tornado.damage = DAMAGE
tornado.time_freeze = false
tornado.element = Element.Wind
tornado.description = "Create 8-\nhit tornd\n2sq ahd!"
tornado.long_description = "Creates an 8-hit tornado 2 squares ahead!"
tornado.can_boost = true
tornado.card_class = CardClass.Standard
tornado.limit = 5
tornado.mb = 16

function package_init(package)
    package:declare_package_id("com.OFC.card.EXE6-053-Tornado")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes(tornado.codes)

    local props = package:get_card_props()
    props.shortname = tornado.shortname
    props.damage = tornado.damage
    props.time_freeze = tornado.time_freeze
    props.element = tornado.element
    props.description = tornado.description
    props.long_description = tornado.long_description
    props.can_boost = tornado.can_boost
	props.card_class = tornado.card_class
	props.limit = tornado.limit
end

card_create_action = tornado.card_create_action