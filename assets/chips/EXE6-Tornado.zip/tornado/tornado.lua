local print_debug = false

local BUSTER_TEXTURE = Engine.load_texture(_folderpath.."gfx/buster.png")
local BUSTER_TEXTURE_DARK = Engine.load_texture(_folderpath.."gfx/buster_dark.png")
local BUSTER_ANIMPATH = _folderpath.."gfx/buster.animation"
local TORNADO_TEXTURE = Engine.load_texture(_folderpath.."gfx/tornado.grayscaled.png")
local TORNADO_ANIMPATH = _folderpath.."gfx/tornado.animation"
local EFFECT0_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect0.grayscaled.png")
local EFFECT0_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect0.png")
local EFFECT0_ANIMPATH = _folderpath.."gfx/effect0.animation"

local TORNADO_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_292.ogg", true)

local function debug_print(text)
    if print_debug then
        print("[Tornado] "..text)
    end
end

local tornado = {}

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip, team)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    team = team or user:get_team()
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(team)
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(team)
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function create_hitbox(user, hit_props, facing, field, team, tile)
    local spell = Battle.Spell.new(team)
    spell:set_facing(facing)
    spell:set_name(tornado.type)
    spell:set_hit_props(hit_props)
    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end
    spell.attack_func = function(self, other, judge)
        if not judge:hint_spawn_gfx() then return end
        local offset_x = math.random(-6,5)
        local offset_y = math.random(-5,6)
        local hit_fx = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT0_TEXTURE, EFFECT0_PALETTE, EFFECT0_ANIMPATH, -999, "0", Playback.Once, self, facing, true, true, true, team)
        field:spawn(hit_fx, self:get_tile())
    end
    spell.battle_end_func = function(self)
        self:delete()
    end
    spell.delete_func = function(self)
        self:erase()
    end
    field:spawn(spell, tile)
    return spell
end
--[[

    Poison? -> NO

]]--
local function create_tornado(user, props, facing, field, team, tile)
    if not tile or tile:is_edge() then return end
    local damage = props.damage
    local palette = Engine.load_texture(_folderpath.."gfx/palette/tornado-none.png")
    local elemental_index = 0
    if tornado.type == "Tornado" then
        local elementals = {
            [1] = {state=TileState.Ice,     palette="ice"},
            [2] = {state=TileState.Grass,   palette="kusamura"},
            [3] = {state=TileState.Lava,    palette="magma"},
            [4] = {state=TileState.Sand,    palette="arijigoku"},
            [5] = {state=TileState.Antlion, palette="arijigoku"},
            [6] = {state=TileState.Sea,     palette="ice"},
        }
        for i=1,#elementals do
            if tile:get_state() == elementals[i].state then
                elemental_index = i
                tile:set_state(TileState.Normal)
                palette = Engine.load_texture(_folderpath.."gfx/palette/tornado-"..elementals[elemental_index].palette..".png")
                break
            end
        end
        if elemental_index ~= 0 then damage = damage*2 end
    elseif tornado.type == "NoiseStorm" then
        palette = Engine.load_texture(_folderpath.."gfx/palette/tornado-dark.png")
    end
    local spell = graphic_init("spell", 0, 0, TORNADO_TEXTURE, palette, TORNADO_ANIMPATH, -3, "0", Playback.Loop, user, facing, false, false, false, team)
    spell:set_name(tornado.type)
    local hit_props = HitProps.new()
    :dmg(damage)
    :impact()
    :flinch()
    :elem(props.element)
    :from(user:get_context())
    spell.hits = 8
    spell.frames = 1
    spell.on_spawn_func = function(self)
		Engine.play_audio(TORNADO_AUDIO, AudioPriority.Immediate)
        create_hitbox(user, hit_props, facing, field, team, tile)
	end
    spell.update_func = function(self)
        for i=1, self.hits-1 do
            if self.frames==4*i then
                create_hitbox(user, hit_props, facing, field, team, tile)
            end
        end
        if self.frames == 32 then
            self:delete()
        end
        self.frames = self.frames + 1
	end
    spell.battle_end_func = function(self)
        self:delete()
    end
    spell.delete_func = function(self)
        self:erase()
    end
    field:spawn(spell, tile)
    return spell
end

tornado.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
    local frame1 = {1,0.15}  --(+)1 frame
    local frame2 = {1,0.05}
    local frame3 = {1,0.033}
    local frame4 = {1,0.35}  --(-)1 frame
    local frame_sequence = make_frame_data({
        frame1,
        frame2, frame2, frame2, frame2, frame2, frame2, frame2, frame2, frame2, frame2,
        frame3, frame4
    })
    action:override_animation_frames(frame_sequence)
	action:set_lockout(make_animation_lockout())
    -----------------------
    -- Counterable Timer --
    local counter_timer = 1
    action.update_func = function(self)
        if counter_timer == 17 then
			user:toggle_counter(false)
        end
        counter_timer = counter_timer + 1
        --return action
	end
    -----------------------
    action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        local facing = user:get_facing()
        local field = user:get_field()
		local team = user:get_team()
        user:toggle_counter(true)
        local buster = self:add_attachment("BUSTER")
        local buster_sprite = buster:sprite()
        if tornado.type == "Tornado" then
            buster_sprite:set_texture(BUSTER_TEXTURE, true)
        elseif tornado.type == "NoiseStorm" then
            buster_sprite:set_texture(BUSTER_TEXTURE_DARK, true)
        end
        buster_sprite:set_layer(-2)
        buster_sprite:enable_parent_shader(true)
        local buster_anim = buster:get_animation()
        buster_anim:load(BUSTER_ANIMPATH)
        buster_anim:set_state("0")
        buster_anim:refresh(buster_sprite)
        for i=2,12 do
		    self:add_anim_action(i, function()
                if i==2 then
                    local tile = user:get_tile(facing,2)
                    create_tornado(user, props, facing, field, team, tile)
                    if tornado.type == "NoiseStorm" then
                        if user:get_health() <= math.floor(user:get_max_health()*0.5) then
                            create_tornado(user, props, facing, field, team, tile:get_tile(facing,1))
                        end
                        if user:get_health() <= math.floor(user:get_max_health()*0.25) then
                            create_tornado(user, props, facing, field, team, tile:get_tile(Direction.Up,1))
                            create_tornado(user, props, facing, field, team, tile:get_tile(Direction.Down,1))
                        end
                        if user:get_health() == 1 then
                            create_tornado(user, props, facing, field, team, tile:get_tile(facing,1):get_tile(Direction.Up,1))
                            create_tornado(user, props, facing, field, team, tile:get_tile(facing,1):get_tile(Direction.Down,1))
                        end
                    end
                end
                buster_anim:set_state("1")
                buster_anim:refresh(buster_sprite)
            end)
        end
		self:add_anim_action(13, function()
            buster_anim:set_state("0")
            buster_anim:refresh(buster_sprite)
        end)
	end
	action.action_end_func = function()
		user:toggle_counter(false)
	end
    return action
end

return tornado