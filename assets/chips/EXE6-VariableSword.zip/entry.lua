local variablesword = include("variablesword/variablesword.lua")

local DAMAGE = 160

variablesword.type = 0

variablesword.codes = {"K","V","W"}
variablesword.shortname = "VarSword"
variablesword.damage = DAMAGE
variablesword.time_freeze = false
variablesword.element = Element.Sword
variablesword.description = "Shifting\ntechnical\nsword"
variablesword.long_description = "A shifting technical sword"
variablesword.can_boost = true
variablesword.card_class = CardClass.Standard
variablesword.limit = 4
variablesword.mb = 28

function package_init(package)
    package:declare_package_id("com.OFC.card.EXE6-081-VariableSword")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes(variablesword.codes)

    local props = package:get_card_props()
    props.shortname = variablesword.shortname
    props.damage = variablesword.damage
    props.time_freeze = variablesword.time_freeze
    props.element = variablesword.element
    props.description = variablesword.description
    props.long_description = variablesword.long_description
    props.can_boost = variablesword.can_boost
	props.card_class = variablesword.card_class
	props.limit = variablesword.limit
end

card_create_action = variablesword.card_create_action