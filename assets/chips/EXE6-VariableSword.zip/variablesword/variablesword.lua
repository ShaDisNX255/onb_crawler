local print_debug = false

local AUDIO_DAMAGE_ENEMY = Engine.load_audio(_folderpath.."sfx/EXE6_50.ogg", true)
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."sfx/EXE6_131.ogg", true)

local SWORD_TEXTURE = Engine.load_texture(_folderpath.."gfx/sword.png")
local SWORD_ANIMPATH = _folderpath.."gfx/sword.animation"
local SLASH_TEXTURE = Engine.load_texture(_folderpath.."gfx/slash.grayscaled.png")
local SLASH_PALETTE_SWORD = Engine.load_texture(_folderpath.."gfx/palette/slash_sword.png")
local SLASH_PALETTE_DREAM = Engine.load_texture(_folderpath.."gfx/palette/slash_dream.png")
local SLASH_ANIMPATH = _folderpath.."gfx/slash.animation"
local DREAM_TEXTURE = Engine.load_texture(_folderpath.."gfx/dream.grayscaled.png")
local DREAM_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/dream.png")
local DREAM_ANIMPATH = _folderpath.."gfx/dream.animation"
local CROSS_TEXTURE = Engine.load_texture(_folderpath.."gfx/cross.grayscaled.png")
local CROSS_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/cross.png")
local CROSS_ANIMPATH = _folderpath.."gfx/cross.animation"

local SLASH_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_247.ogg", true)
local SUCCESS_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_327.ogg", true)
local DREAM_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_184.ogg", true)

local function debug_print(text)
    if print_debug then
        print("[VariableSword] "..text)
    end
end

local variablesword = {}

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function create_sonicboom(user, props, tile, palette, super)
    if not tile or tile:is_edge() then return end
    local facing = user:get_facing()
    local field = user:get_field()
    local team = user:get_team()
	local spell = graphic_init("spell", 0, -16*2, SLASH_TEXTURE, palette, SLASH_ANIMPATH, -3, "0", Playback.Once, user, facing, false, true)
    spell:get_animation():set_playback_speed(0)
    if super then
        spell:set_hit_props(
	    	HitProps.new()
	    	:dmg(props.damage)
            :impact()
            :flinch()
            :elem2(Element.Sword)
            :from(user:get_context())
	    )
    else
        spell:set_hit_props(
	    	HitProps.new()
	    	:dmg(props.damage)
            :impact()
            :flinch()
            :flash()
            :elem2(Element.Sword)
            :from(user:get_context())
	    )
    end
    spell.on_spawn_func = function()
        debug_print("attack spawned at tile ("..tile:x()..";"..tile:y()..")")
    end
	spell.update_func = function(self)
		self:get_tile():attack_entities(self)
        local tile2 = self:get_tile():get_tile(Direction.Up, 1)
        if tile2 and not tile2:is_edge() then
            tile2:attack_entities(self)
        end
        local tile3 = self:get_tile():get_tile(Direction.Down, 1)
        if tile3 and not tile3:is_edge() then
            tile3:attack_entities(self)
        end
		if not self:is_sliding() then
            if self:get_tile():is_edge() then
                self:erase()
            end
            local dest = self:get_tile(self:get_facing(), 1)
            self:slide(dest, frames(4), frames(0), ActionOrder.Voluntary)  
        end
	end
    spell.collision_func = function(self, other)
        if not super then
		    self:erase()
        end
    end
    spell.attack_func = function(self, other)
        if not other:get_animation():has_state("HITSOUND_N") and #other:sprite():find_child_nodes_with_tags({"IS_BARRIER"}) <= 0 then
            if not other:get_animation():has_state("HITSOUND_C") and not other:get_animation():has_state("HITSOUND_O") then
    	        if Battle.Obstacle.from(other) == nil then
                    if Battle.Player.from(user) ~= nil then
    	            	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
    	            end
                else
    	        	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
    	        end
            else
                if other:get_animation():has_state("HITSOUND_C") then
    	            if Battle.Player.from(user) ~= nil then
    	            	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
    	            end
    	        end
    	        if other:get_animation():has_state("HITSOUND_O") then
    	        	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
    	        end
            end
    	end
    end
    spell.can_move_to_func = function(tile)
        return true
    end
	user:get_field():spawn(spell, tile)
	return spell
end

local function create_hitbox(user, props, tile, sword_type, super, double)
    if not tile or tile:is_edge() then return end
    local facing = user:get_facing()
    local field = user:get_field()
    local team = user:get_team()
	local spell = Battle.Spell.new(team)
    spell:set_facing(facing)
    local damage = props.damage
    if double then damage = damage*2 end
    if super then
        spell:set_hit_props(
            HitProps.new()
            :dmg(damage)
            :impact()
            :flinch()
            :elem2(Element.Sword)
            :from(user:get_context())
        )
    else
        spell:set_hit_props(
            HitProps.new()
            :dmg(damage)
            :impact()
            :flinch()
            :flash()
            :elem2(Element.Sword)
            :from(user:get_context())
        )
    end
    spell.on_spawn_func = function()
        debug_print("attack spawned at tile ("..tile:x()..";"..tile:y()..")")
    end
	spell.update_func = function(self)
        if sword_type ~= 5 then
		    tile:attack_entities(self)
            if sword_type == 1 then         -- Wide Sword
                local tile2 = tile:get_tile(Direction.Up, 1)
                if tile2 and not tile2:is_edge() then
                    tile2:attack_entities(self)
                end
                local tile3 = tile:get_tile(Direction.Down, 1)
                if tile3 and not tile3:is_edge() then
                    tile3:attack_entities(self)
                end
            elseif sword_type == 2 then     -- Long Sword
                local tile2 = tile:get_tile(facing, 1)
                if tile2 and not tile2:is_edge() then
                    tile2:attack_entities(self)
                end
            elseif sword_type == 3 then     -- Fighter Sword
                local tile2 = tile:get_tile(facing, 1)
                if tile2 and not tile2:is_edge() then
                    tile2:attack_entities(self)
                end
                local tile3 = tile:get_tile(facing, 2)
                if tile3 and not tile3:is_edge() then
                    tile3:attack_entities(self)
                end
            elseif sword_type == 4 then     -- Dream Sword
                local tile2 = tile:get_tile(Direction.Up, 1)
                if tile2 and not tile2:is_edge() then
                    tile2:attack_entities(self)
                end
                local tile3 = tile:get_tile(Direction.join(facing, Direction.Up), 1)
                if tile3 and not tile3:is_edge() then
                    tile3:attack_entities(self)
                end
                local tile4 = tile:get_tile(facing, 1)
                if tile4 and not tile4:is_edge() then
                    tile4:attack_entities(self)
                end
                local tile5 = tile:get_tile(Direction.join(facing, Direction.Down), 1)
                if tile5 and not tile5:is_edge() then
                    tile5:attack_entities(self)
                end
                local tile6 = tile:get_tile(Direction.Down, 1)
                if tile6 and not tile6:is_edge() then
                    tile6:attack_entities(self)
                end
            end
        else     -- Cross Sword
            local tile1 = tile:get_tile(Direction.UpLeft, 1)
            if tile1 and not tile1:is_edge() then
                tile1:attack_entities(self)
            end
            local tile2 = tile:get_tile(Direction.UpRight, 1)
            if tile2 and not tile2:is_edge() then
                tile2:attack_entities(self)
            end
            local tile3 = tile:get_tile(Direction.DownLeft, 1)
            if tile3 and not tile3:is_edge() then
                tile3:attack_entities(self)
            end
            local tile4 = tile:get_tile(Direction.DownRight, 1)
            if tile4 and not tile4:is_edge() then
                tile4:attack_entities(self)
            end
        end
        self:erase()
	end
    spell.attack_func = function(self, other)
        if not other:get_animation():has_state("HITSOUND_N") and #other:sprite():find_child_nodes_with_tags({"IS_BARRIER"}) <= 0 then
            if not other:get_animation():has_state("HITSOUND_C") and not other:get_animation():has_state("HITSOUND_O") then
    	        if Battle.Obstacle.from(other) == nil then
                    if Battle.Player.from(user) ~= nil then
    	            	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
    	            end
                else
    	        	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
    	        end
            else
                if other:get_animation():has_state("HITSOUND_C") then
    	            if Battle.Player.from(user) ~= nil then
    	            	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
    	            end
    	        end
    	        if other:get_animation():has_state("HITSOUND_O") then
    	        	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
    	        end
            end
    	end
    end
	field:spawn(spell, tile)
	return spell
end

local function create_slash(user, props, tile, state, texture, animpath, palette)
    if not tile or tile:is_edge() then return end
    local facing = user:get_facing()
    local field = user:get_field()
	local slash = graphic_init("artifact", 0, (-16*2), texture, palette, animpath, -3, state, Playback.Once, user, facing, true, true)
	field:spawn(slash, tile)
	return slash
end

local function take_action_super(user, props)
    debug_print("in take_action_super()!")
    local action = Battle.CardAction.new(user, "PLAYER_SWORD")
    local frame1 = {1,0.117} --(+)1 frame
    local frame2 = {2,0.017}
    local frame3 = {2,0.017}
    local frame4 = {3,0.033}
    local frame5 = {4,0.067}
    local frame6 = {4,0.2} --(-)1 frame
    local frame_sequence = make_frame_data({frame1, frame2, frame3, frame4, frame5, frame6})
    action:override_animation_frames(frame_sequence)
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        Engine.play_audio(SLASH_AUDIO, AudioPriority.Low)
        user:toggle_counter(true)
		self:add_anim_action(2, function()
            local hilt = self:add_attachment("HILT")
            local hilt_sprite = hilt:sprite()
            hilt_sprite:set_texture(user:get_texture(), true)
            hilt_sprite:set_layer(-1)
            hilt_sprite:enable_parent_shader(true)
            local hilt_anim = hilt:get_animation()
            hilt_anim:copy_from(user:get_animation())
            hilt_anim:set_state("HILT")
            hilt_anim:refresh(hilt_sprite)
            local blade = hilt:add_attachment("ENDPOINT")
            local blade_sprite = blade:sprite()
            blade_sprite:set_texture(SWORD_TEXTURE, true)
            blade_sprite:set_layer(-2)
            local blade_anim = blade:get_animation()
            blade_anim:load(SWORD_ANIMPATH)
            blade_anim:set_state("0")
            blade_anim:refresh(blade_sprite)
        end)
		self:add_anim_action(3, function()
            local tile = user:get_tile(user:get_facing(), 1)
            create_sonicboom(user, props, tile, SLASH_PALETTE_DREAM, true)
		end)
		self:add_anim_action(6, function()
			user:toggle_counter(false)
		end)
	end
	action.action_end_func = function(self)
        debug_print("in custom card action action_end_func()!")
		user:toggle_counter(false)
	end
	user:card_action_event(action, ActionOrder.Involuntary)
end

local function take_action_double(user, props)
    debug_print("in take_action_double()!")
    local action = Battle.CardAction.new(user, "PLAYER_SWORD")
    local frame1 = {1,0.117} --(+)1 frame
    local frame2 = {2,0.017}
    local frame3 = {2,0.017}
    local frame4 = {3,0.033}
    local frame5 = {4,0.067}
    local frame6 = {4,0.1}
    local frame7 = {1,0.133}
    local frame8 = {4,0.2} --(-)1 frame
    local frame_sequence = make_frame_data({
        frame1, frame2, frame3, frame4, frame5, frame6,
        frame7, frame2, frame3, frame4, frame5, frame8
    })
    action:override_animation_frames(frame_sequence)
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        Engine.play_audio(DREAM_AUDIO, AudioPriority.Low)
        user:toggle_counter(true)
        local hilt
        local hilt_sprite
        local hilt_anim
        local blade
        local blade_sprite
        local blade_anim
		self:add_anim_action(2, function()
            hilt = self:add_attachment("HILT")
            hilt_sprite = hilt:sprite()
            hilt_sprite:set_texture(user:get_texture(), true)
            hilt_sprite:set_layer(-1)
            hilt_sprite:enable_parent_shader(true)
            hilt_anim = hilt:get_animation()
            hilt_anim:copy_from(user:get_animation())
            hilt_anim:set_state("HILT")
            hilt_anim:refresh(hilt_sprite)
            blade = hilt:add_attachment("ENDPOINT")
            blade_sprite = blade:sprite()
            blade_sprite:set_texture(SWORD_TEXTURE, true)
            blade_sprite:set_layer(-2)
            blade_anim = blade:get_animation()
            blade_anim:load(SWORD_ANIMPATH)
            blade_anim:set_state("0")
            blade_anim:refresh(blade_sprite)
        end)
		self:add_anim_action(3, function()
            local tile = user:get_tile(user:get_facing(), 1)
            create_slash(user, props, tile, "0", DREAM_TEXTURE, DREAM_ANIMPATH, DREAM_PALETTE)
            create_hitbox(user, props, tile, 4, true)
		end)
		self:add_anim_action(6, function()
			user:toggle_counter(false)
		end)
		self:add_anim_action(7, function()
            Engine.play_audio(DREAM_AUDIO, AudioPriority.Low)
		end)
		self:add_anim_action(8, function()
            hilt_sprite = hilt:sprite()
            hilt_anim = hilt:get_animation()
            hilt_anim:copy_from(user:get_animation())
            hilt_anim:set_state("HILT")
            hilt_anim:refresh(hilt_sprite)
            blade_sprite = blade:sprite()
            blade_anim = blade:get_animation()
            blade_anim:load(SWORD_ANIMPATH)
            blade_anim:set_state("0")
            blade_anim:refresh(blade_sprite)
        end)
		self:add_anim_action(9, function()
            local tile = user:get_tile(user:get_facing(), 1)
            create_slash(user, props, tile, "0", DREAM_TEXTURE, DREAM_ANIMPATH, DREAM_PALETTE)
            create_hitbox(user, props, tile, 4, true)
		end)
	end
	action.action_end_func = function(self)
        debug_print("in custom card action action_end_func()!")
		user:toggle_counter(false)
	end
	user:card_action_event(action, ActionOrder.Involuntary)
end

local function take_action_cross(user, props)
    debug_print("in take_action_cross()!")
    local action = Battle.CardAction.new(user, "PLAYER_SWORD")
    local frame1 = {1,0.117} --(+)1 frame
    local frame2 = {2,0.017}
    local frame3 = {2,0.017}
    local frame4 = {3,0.033}
    local frame5 = {4,0.067}
    local frame6 = {4,0.2} --(-)1 frame
    local frame_sequence = make_frame_data({frame1, frame2, frame3, frame4, frame5, frame6})
    action:override_animation_frames(frame_sequence)
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        Engine.play_audio(SLASH_AUDIO, AudioPriority.Low)
        user:toggle_counter(true)
		self:add_anim_action(2, function()
            local hilt = self:add_attachment("HILT")
            local hilt_sprite = hilt:sprite()
            hilt_sprite:set_texture(user:get_texture(), true)
            hilt_sprite:set_layer(-1)
            hilt_sprite:enable_parent_shader(true)
            local hilt_anim = hilt:get_animation()
            hilt_anim:copy_from(user:get_animation())
            hilt_anim:set_state("HILT")
            hilt_anim:refresh(hilt_sprite)
            local blade = hilt:add_attachment("ENDPOINT")
            local blade_sprite = blade:sprite()
            blade_sprite:set_texture(SWORD_TEXTURE, true)
            blade_sprite:set_layer(-2)
            local blade_anim = blade:get_animation()
            blade_anim:load(SWORD_ANIMPATH)
            blade_anim:set_state("0")
            blade_anim:refresh(blade_sprite)
        end)
		self:add_anim_action(3, function()
            local tile = user:get_tile(user:get_facing(), 1)
            create_slash(user, props, tile, "0", CROSS_TEXTURE, CROSS_ANIMPATH, CROSS_PALETTE)
            create_hitbox(user, props, tile, 0, false, true)
            create_hitbox(user, props, tile, 5)
		end)
		self:add_anim_action(6, function()
			user:toggle_counter(false)
		end)
	end
	action.action_end_func = function(self)
        debug_print("in custom card action action_end_func()!")
		user:toggle_counter(false)
	end
	user:card_action_event(action, ActionOrder.Involuntary)
end

local function take_action_sonic(user, props)
    debug_print("in take_action_sonic()!")
    local action = Battle.CardAction.new(user, "PLAYER_SWORD")
    local frame1 = {1,0.117} --(+)1 frame
    local frame2 = {2,0.017}
    local frame3 = {2,0.017}
    local frame4 = {3,0.033}
    local frame5 = {4,0.067}
    local frame6 = {4,0.2} --(-)1 frame
    local frame_sequence = make_frame_data({frame1, frame2, frame3, frame4, frame5, frame6})
    action:override_animation_frames(frame_sequence)
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        Engine.play_audio(SLASH_AUDIO, AudioPriority.Low)
        user:toggle_counter(true)
		self:add_anim_action(2, function()
            local hilt = self:add_attachment("HILT")
            local hilt_sprite = hilt:sprite()
            hilt_sprite:set_texture(user:get_texture(), true)
            hilt_sprite:set_layer(-1)
            hilt_sprite:enable_parent_shader(true)
            local hilt_anim = hilt:get_animation()
            hilt_anim:copy_from(user:get_animation())
            hilt_anim:set_state("HILT")
            hilt_anim:refresh(hilt_sprite)
            local blade = hilt:add_attachment("ENDPOINT")
            local blade_sprite = blade:sprite()
            blade_sprite:set_texture(SWORD_TEXTURE, true)
            blade_sprite:set_layer(-2)
            local blade_anim = blade:get_animation()
            blade_anim:load(SWORD_ANIMPATH)
            blade_anim:set_state("0")
            blade_anim:refresh(blade_sprite)
        end)
		self:add_anim_action(3, function()
            local tile = user:get_tile(user:get_facing(), 1)
            create_sonicboom(user, props, tile, SLASH_PALETTE_SWORD)
		end)
		self:add_anim_action(6, function()
			user:toggle_counter(false)
		end)
	end
	action.action_end_func = function(self)
        debug_print("in custom card action action_end_func()!")
		user:toggle_counter(false)
	end
	user:card_action_event(action, ActionOrder.Involuntary)
end

local function take_action_dream(user, props)
    debug_print("in take_action_dream()!")
    local action = Battle.CardAction.new(user, "PLAYER_SWORD")
    local frame1 = {1,0.117} --(+)1 frame
    local frame2 = {2,0.017}
    local frame3 = {2,0.017}
    local frame4 = {3,0.033}
    local frame5 = {4,0.067}
    local frame6 = {4,0.2} --(-)1 frame
    local frame_sequence = make_frame_data({frame1, frame2, frame3, frame4, frame5, frame6})
    action:override_animation_frames(frame_sequence)
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        Engine.play_audio(DREAM_AUDIO, AudioPriority.Low)
        user:toggle_counter(true)
		self:add_anim_action(2, function()
            local hilt = self:add_attachment("HILT")
            local hilt_sprite = hilt:sprite()
            hilt_sprite:set_texture(user:get_texture(), true)
            hilt_sprite:set_layer(-1)
            hilt_sprite:enable_parent_shader(true)
            local hilt_anim = hilt:get_animation()
            hilt_anim:copy_from(user:get_animation())
            hilt_anim:set_state("HILT")
            hilt_anim:refresh(hilt_sprite)
            local blade = hilt:add_attachment("ENDPOINT")
            local blade_sprite = blade:sprite()
            blade_sprite:set_texture(SWORD_TEXTURE, true)
            blade_sprite:set_layer(-2)
            local blade_anim = blade:get_animation()
            blade_anim:load(SWORD_ANIMPATH)
            blade_anim:set_state("0")
            blade_anim:refresh(blade_sprite)
        end)
		self:add_anim_action(3, function()
            local tile = user:get_tile(user:get_facing(), 1)
            create_slash(user, props, tile, "0", DREAM_TEXTURE, DREAM_ANIMPATH, DREAM_PALETTE)
            create_hitbox(user, props, tile, 4)
		end)
		self:add_anim_action(6, function()
			user:toggle_counter(false)
		end)
	end
	action.action_end_func = function(self)
        debug_print("in custom card action action_end_func()!")
		user:toggle_counter(false)
	end
	user:card_action_event(action, ActionOrder.Involuntary)
end

local function take_action_fighter(user, props)
    debug_print("in take_action_fighter()!")
    local action = Battle.CardAction.new(user, "PLAYER_SWORD")
    local frame1 = {1,0.117} --(+)1 frame
    local frame2 = {2,0.017}
    local frame3 = {2,0.017}
    local frame4 = {3,0.033}
    local frame5 = {4,0.067}
    local frame6 = {4,0.2} --(-)1 frame
    local frame_sequence = make_frame_data({frame1, frame2, frame3, frame4, frame5, frame6})
    action:override_animation_frames(frame_sequence)
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        Engine.play_audio(SLASH_AUDIO, AudioPriority.Low)
        user:toggle_counter(true)
		self:add_anim_action(2, function()
            local hilt = self:add_attachment("HILT")
            local hilt_sprite = hilt:sprite()
            hilt_sprite:set_texture(user:get_texture(), true)
            hilt_sprite:set_layer(-1)
            hilt_sprite:enable_parent_shader(true)
            local hilt_anim = hilt:get_animation()
            hilt_anim:copy_from(user:get_animation())
            hilt_anim:set_state("HILT")
            hilt_anim:refresh(hilt_sprite)
            local blade = hilt:add_attachment("ENDPOINT")
            local blade_sprite = blade:sprite()
            blade_sprite:set_texture(SWORD_TEXTURE, true)
            blade_sprite:set_layer(-2)
            local blade_anim = blade:get_animation()
            blade_anim:load(SWORD_ANIMPATH)
            blade_anim:set_state("0")
            blade_anim:refresh(blade_sprite)
        end)
		self:add_anim_action(3, function()
            local tile = user:get_tile(user:get_facing(), 1)
            create_slash(user, props, tile, "3", SLASH_TEXTURE, SLASH_ANIMPATH, SLASH_PALETTE_SWORD)
            create_hitbox(user, props, tile, 3)
		end)
		self:add_anim_action(6, function()
			user:toggle_counter(false)
		end)
	end
	action.action_end_func = function(self)
        debug_print("in custom card action action_end_func()!")
		user:toggle_counter(false)
	end
	user:card_action_event(action, ActionOrder.Involuntary)
end

local function take_action_long(user, props)
    debug_print("in take_action_long()!")
    local action = Battle.CardAction.new(user, "PLAYER_SWORD")
    local frame1 = {1,0.117} --(+)1 frame
    local frame2 = {2,0.017}
    local frame3 = {2,0.017}
    local frame4 = {3,0.033}
    local frame5 = {4,0.067}
    local frame6 = {4,0.2} --(-)1 frame
    local frame_sequence = make_frame_data({frame1, frame2, frame3, frame4, frame5, frame6})
    action:override_animation_frames(frame_sequence)
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        Engine.play_audio(SLASH_AUDIO, AudioPriority.Low)
        user:toggle_counter(true)
		self:add_anim_action(2, function()
            local hilt = self:add_attachment("HILT")
            local hilt_sprite = hilt:sprite()
            hilt_sprite:set_texture(user:get_texture(), true)
            hilt_sprite:set_layer(-1)
            hilt_sprite:enable_parent_shader(true)
            local hilt_anim = hilt:get_animation()
            hilt_anim:copy_from(user:get_animation())
            hilt_anim:set_state("HILT")
            hilt_anim:refresh(hilt_sprite)
            local blade = hilt:add_attachment("ENDPOINT")
            local blade_sprite = blade:sprite()
            blade_sprite:set_texture(SWORD_TEXTURE, true)
            blade_sprite:set_layer(-2)
            local blade_anim = blade:get_animation()
            blade_anim:load(SWORD_ANIMPATH)
            blade_anim:set_state("0")
            blade_anim:refresh(blade_sprite)
        end)
		self:add_anim_action(3, function()
            local tile = user:get_tile(user:get_facing(), 1)
            create_slash(user, props, tile, "1", SLASH_TEXTURE, SLASH_ANIMPATH, SLASH_PALETTE_SWORD)
            create_hitbox(user, props, tile, 2)
		end)
		self:add_anim_action(6, function()
			user:toggle_counter(false)
		end)
	end
	action.action_end_func = function(self)
        debug_print("in custom card action action_end_func()!")
		user:toggle_counter(false)
	end
	user:card_action_event(action, ActionOrder.Involuntary)
end

local function take_action_wide(user, props)
    debug_print("in take_action_wide()!")
    local action = Battle.CardAction.new(user, "PLAYER_SWORD")
    local frame1 = {1,0.117} --(+)1 frame
    local frame2 = {2,0.017}
    local frame3 = {2,0.017}
    local frame4 = {3,0.033}
    local frame5 = {4,0.067}
    local frame6 = {4,0.2} --(-)1 frame
    local frame_sequence = make_frame_data({frame1, frame2, frame3, frame4, frame5, frame6})
    action:override_animation_frames(frame_sequence)
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        Engine.play_audio(SLASH_AUDIO, AudioPriority.Low)
        user:toggle_counter(true)
		self:add_anim_action(2, function()
            local hilt = self:add_attachment("HILT")
            local hilt_sprite = hilt:sprite()
            hilt_sprite:set_texture(user:get_texture(), true)
            hilt_sprite:set_layer(-1)
            hilt_sprite:enable_parent_shader(true)
            local hilt_anim = hilt:get_animation()
            hilt_anim:copy_from(user:get_animation())
            hilt_anim:set_state("HILT")
            hilt_anim:refresh(hilt_sprite)
            local blade = hilt:add_attachment("ENDPOINT")
            local blade_sprite = blade:sprite()
            blade_sprite:set_texture(SWORD_TEXTURE, true)
            blade_sprite:set_layer(-2)
            local blade_anim = blade:get_animation()
            blade_anim:load(SWORD_ANIMPATH)
            blade_anim:set_state("0")
            blade_anim:refresh(blade_sprite)
        end)
		self:add_anim_action(3, function()
            local tile = user:get_tile(user:get_facing(), 1)
            create_slash(user, props, tile, "0", SLASH_TEXTURE, SLASH_ANIMPATH, SLASH_PALETTE_SWORD)
            create_hitbox(user, props, tile, 1)
		end)
		self:add_anim_action(6, function()
			user:toggle_counter(false)
		end)
	end
	action.action_end_func = function(self)
        debug_print("in custom card action action_end_func()!")
		user:toggle_counter(false)
	end
	user:card_action_event(action, ActionOrder.Involuntary)
end

local function take_action_sword(user, props)
    debug_print("in take_action_sword()!")
    local action = Battle.CardAction.new(user, "PLAYER_SWORD")
    local frame1 = {1,0.117} --(+)1 frame
    local frame2 = {2,0.017}
    local frame3 = {2,0.017}
    local frame4 = {3,0.033}
    local frame5 = {4,0.067}
    local frame6 = {4,0.2} --(-)1 frame
    local frame_sequence = make_frame_data({frame1, frame2, frame3, frame4, frame5, frame6})
    action:override_animation_frames(frame_sequence)
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        Engine.play_audio(SLASH_AUDIO, AudioPriority.Low)
        user:toggle_counter(true)
		self:add_anim_action(2, function()
            local hilt = self:add_attachment("HILT")
            local hilt_sprite = hilt:sprite()
            hilt_sprite:set_texture(user:get_texture(), true)
            hilt_sprite:set_layer(-1)
            hilt_sprite:enable_parent_shader(true)
            local hilt_anim = hilt:get_animation()
            hilt_anim:copy_from(user:get_animation())
            hilt_anim:set_state("HILT")
            hilt_anim:refresh(hilt_sprite)
            local blade = hilt:add_attachment("ENDPOINT")
            local blade_sprite = blade:sprite()
            blade_sprite:set_texture(SWORD_TEXTURE, true)
            blade_sprite:set_layer(-2)
            local blade_anim = blade:get_animation()
            blade_anim:load(SWORD_ANIMPATH)
            blade_anim:set_state("0")
            blade_anim:refresh(blade_sprite)
        end)
		self:add_anim_action(3, function()
            local tile = user:get_tile(user:get_facing(), 1)
            create_slash(user, props, tile, "2", SLASH_TEXTURE, SLASH_ANIMPATH, SLASH_PALETTE_SWORD)
            create_hitbox(user, props, tile, 0)
		end)
		self:add_anim_action(6, function()
			user:toggle_counter(false)
		end)
	end
	action.action_end_func = function(self)
        debug_print("in custom card action action_end_func()!")
		user:toggle_counter(false)
	end
	user:card_action_event(action, ActionOrder.Involuntary)
end

local recipes1 = {
    {
        name = "long",
        pattern = {
            {"down"},
            {"down","right"},
            {"right"}
        }
    },
    {
        name = "wide",
        pattern = {
            {"up"},
            {"right"},
            {"down"}
        }
    },
    {
        name = "fighter",
        pattern = {
            {"left"},
            {"down","left"},
            {"down"},
            {"down","right"},
            {"right"}
        }
    },
    {
        name = "dream",
        pattern = {
            {"down"},
            {"left"},
            {"up"},
            {"right"},
            {"down"}
        }
    },
    {
        name = "sonic",
        pattern = {
            {"left"},
            {"b"},
            {"right"},
            {"b"}
        }
    },
}
local recipes2 = {
    {
        name = "cross",
        pattern = {
            {"down"},
            {"right"},
            {"up"}
        }
    },
    {
        name = "super",
        pattern = {
            {"left"},
            {"right"},
            {"left"},
            {"b"}
        }
    },
    {
        name = "double",
        pattern = {
            {"up"},
            {"b"},
            {"down"},
            {"b"},
            {"up"},
            {"b"}
        }
    },
}

local function deep_clone(t)
	if type(t) ~= "table" then
		return t
	end

	local o = {}
	for k, v in pairs(t) do
		o[k] = deep_clone(v)
	end
	return o
end

local function contains(t, value)
	for k, v in ipairs(t) do
		if v == value then
			return true
		end
	end
	return false
end

local function get_first_completed_recipe(matching)
	for _, recipe in ipairs(matching) do
		if recipe.current_step > #recipe.pattern then
			Engine.play_audio(SUCCESS_AUDIO, AudioPriority.Low)
			return recipe.name
		end
	end

	return nil
end

variablesword.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
	local matching
    if variablesword.type == 1 then
	    matching = deep_clone(recipes2)
    else
	    matching = deep_clone(recipes1)
    end

	for _, recipe in ipairs(matching) do
		recipe.current_step = 1
	end

	local action = Battle.CardAction.new(user, "IDLE")
	action:set_lockout(make_sequence_lockout())

	local remaining_time = 50 -- 50 frame timer

	local step1 = Battle.Step.new()

	step1.update_func = function()
		remaining_time = remaining_time - 1

		if remaining_time < 0 or not user:input_has(Input.Pressed.Use) and not user:input_has(Input.Held.Use) or
			get_first_completed_recipe(matching) ~= nil then
			step1:complete_step()
			return
		end
		local drop_list = {}
		local inputs = {
			up = user:input_has(Input.Pressed.Up) or user:input_has(Input.Held.Up),
			down = user:input_has(Input.Pressed.Down) or user:input_has(Input.Held.Down),
			left = user:input_has(Input.Pressed.Left) or user:input_has(Input.Held.Left),
			right = user:input_has(Input.Pressed.Right) or user:input_has(Input.Held.Right),
			b = user:input_has(Input.Pressed.Shoot) or user:input_has(Input.Held.Shoot)
		}

		local function inputs_fail(required_inputs)
			-- has an input that should not be held
			for name, held in pairs(inputs) do
				if held and not contains(required_inputs, name) then
					return true
				end
			end
			return false
		end

		local function inputs_match(required_inputs)
			for _, name in ipairs(required_inputs) do
				if not inputs[name] then
					return false
				end
			end
			return true
		end

		for i, recipe in ipairs(matching) do
			local last_required_inputs = recipe.pattern[recipe.current_step - 1]
			local required_inputs = recipe.pattern[math.min(recipe.current_step, #recipe.pattern)]
			local fails_current_requirements = inputs_fail(required_inputs)

			if fails_current_requirements and (not last_required_inputs or inputs_fail(last_required_inputs)) then
				-- has an input that failed to match the current + previous requirements
				drop_list[#drop_list + 1] = i
			elseif not fails_current_requirements and recipe.current_step <= #recipe.pattern and inputs_match(required_inputs) then
				-- has all of the required inputs to continue
				recipe.current_step = recipe.current_step + 1
			end
		end

		for i, v in ipairs(drop_list) do
			table.remove(matching, v - i + 1)
		end
	end
	action:add_step(step1)

	local step2 = Battle.Step.new()
	step2.update_func = function()
		local attack_name = get_first_completed_recipe(matching)
        if attack_name then
		    print("Success! combo = "..attack_name)
        end
        if variablesword.type == 1 then
            if attack_name == "cross" then
                take_action_cross(user, props)
            elseif attack_name == "super" then
                take_action_super(user, props)
            elseif attack_name == "double" then
                take_action_double(user, props)
            else
                take_action_sword(user, props)
            end
        else
            if attack_name == "long" then
                take_action_long(user, props)
            elseif attack_name == "wide" then
                take_action_wide(user, props)
            elseif attack_name == "fighter" then
                take_action_fighter(user, props)
            elseif attack_name == "dream" then
                take_action_dream(user, props)
            elseif attack_name == "sonic" then
                take_action_sonic(user, props)
            else
                take_action_sword(user, props)
            end
        end
		step2:complete_step()
	end
	action:add_step(step2)

	return action
end

return variablesword