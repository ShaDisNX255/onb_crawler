local forestbomb = include("forestbomb/forestbomb.lua")

local DAMAGE = 90

forestbomb.towers = 4

forestbomb.codes = {"E","K","O"}
forestbomb.shortname = "ForstBm2"
forestbomb.damage = DAMAGE
forestbomb.time_freeze = false
forestbomb.element = Element.Wood
forestbomb.description = "Creates svrl rndm WoodTwrs!"
forestbomb.long_description = "Throws a seed 3 squares ahead! Attack with WoodyTowers anywhere in the enemy area!"
forestbomb.can_boost = true
forestbomb.card_class = CardClass.Standard
forestbomb.limit = 4
forestbomb.mb = 35

function package_init(package)
    package:declare_package_id("com.OFC.card.EXEPoN-035-ForestBomb2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes(forestbomb.codes)

    local props = package:get_card_props()
    props.shortname = forestbomb.shortname
    props.damage = forestbomb.damage
    props.time_freeze = forestbomb.time_freeze
    props.element = forestbomb.element
    props.description = forestbomb.description
    props.long_description = forestbomb.long_description
    props.can_boost = forestbomb.can_boost
	props.card_class = forestbomb.card_class
	props.limit = forestbomb.limit
end

card_create_action = forestbomb.card_create_action