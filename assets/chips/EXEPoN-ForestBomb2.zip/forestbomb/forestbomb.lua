local DAMAGE = 60

local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."EXE4_270.ogg")
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."EXE4_221.ogg")
local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."effect.png")
local EFFECT_ANIMPATH = _folderpath.."effect.animation"
local TESTDOT_TEXTURE = Engine.load_texture(_folderpath.."testdot.png")
local TESTDOT_ANIMPATH = _folderpath.."testdot.animation"

local attachment_texture = Engine.load_texture(_folderpath.."attachment.png")
local attachment_animation_path = _folderpath.."attachment.animation"
local throw_sfx = Engine.load_audio(_folderpath.."EXE4_150.ogg")
local shadow_texture = Engine.load_texture(_folderpath.."shadow.png")
local shadow_animation_path = _folderpath.."shadow.animation"
local smoke_texture = Engine.load_texture(_folderpath.."smoke.png")
local smoke_animation_path = _folderpath.."smoke.animation"
local WOODYTOWER_TEXTURE = Engine.load_texture(_folderpath.."woodytower.png")
local WOODYTOWER_ANIMPATH = _folderpath.."woodytower.animation"
local WOODYTOWER_AUDIO = Engine.load_audio(_folderpath.."EXE4_287.ogg")

local SHOW_DEBUG_TEXT = false

local forestbomb = {
    towers = 3,

    codes = {"B","T","V"},
    shortname = "CannBall",
    damage = DAMAGE,
    time_freeze = false,
    element = Element.None,
    description = "Breaks 3rd panel ahead",
    long_description = "Throws a CannonBall 3 squares ahead! Breaks panel!",
    can_boost = true,
    card_class = CardClass.Standard,
    limit = 4,
    mb = 33
}

forestbomb.card_create_action = function(actor, props)
    print("in card_create_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_THROW")
	local original_offset = actor:get_offset()
    local override_frames = {
        {1,0.083},{2,0.067},{3,0.050},{4,0.083},{5,0.067}
    }
    local frame_data = make_frame_data(override_frames)
	action:set_lockout(make_animation_lockout())
    action:override_animation_frames(frame_data)
    action.execute_func = function(self, user)
        print("in custom card action execute_func()!")
        local facing = user:get_facing()
        local field = user:get_field()
        local team = user:get_team()
        local self_tile = user:get_current_tile()
        local self_X = self_tile:x()
        --local props = self:copy_metadata()
        local attachment = self:add_attachment("HAND")
        local attachment_sprite = attachment:sprite()
        attachment_sprite:set_texture(attachment_texture)
        attachment_sprite:set_layer(-2)

        local attachment_animation = attachment:get_animation()
        attachment_animation:load(attachment_animation_path)
        attachment_animation:set_state("0")

        self:add_anim_action(3,function()
            attachment_sprite:hide()
            --self.remove_attachment(attachment)
            local tiles_ahead = 3
            local frames_in_air = 40
            local toss_height = 70
            local field = user:get_field()
            local target_tile = user:get_tile(facing,tiles_ahead)
            if not target_tile then
                return
            end
            local tiles_number = 0
            local tile_array = {}
            local tile_check = false
            local cycle0_end = true
            local cycle1_end = false
            action.on_landing = function()
                if target_tile:is_walkable() then
                    while cycle0_end do
                        if facing == Direction.Right then
                            for i = 7, 0, -1 do
                                for j = 1, 3, 1 do
                                    if self_X <= i then
                                        local target_tile = field:tile_at(i, j)
                                        tile_check = target_tile and not user:is_team(target_tile:get_team()) and not target_tile:is_edge() and target_tile:is_walkable()
                                        if tile_check then
                                            if SHOW_DEBUG_TEXT then
                                                print("TILE ("..target_tile:x()..";"..target_tile:y()..") TARGETED")
                                            end
                                            tiles_number = tiles_number + 1
                                            --print("tiles_number: "..tiles_number)
                                            table.insert(tile_array, target_tile)
                                        end
                                    else
                                        shuffle(tile_array)
                                        cycle0_end = false
                                        cycle1_end = true
                                        break
                                    end
                                end
                            end
                        else
                            for i = 0, 7, 1 do
                                for j = 1, 3, 1 do
                                    if self_X >= i then
                                        local target_tile = field:tile_at(i, j)
                                        tile_check = target_tile and not user:is_team(target_tile:get_team()) and not target_tile:is_edge() and target_tile:is_walkable()
                                        if tile_check then
                                            if SHOW_DEBUG_TEXT then
                                                print("TILE ("..target_tile:x()..";"..target_tile:y()..") TARGETED")
                                            end
                                            tiles_number = tiles_number + 1
                                            --print("tiles_number: "..tiles_number)
                                            table.insert(tile_array, target_tile)
                                        end
                                    else
                                        shuffle(tile_array)
                                        cycle0_end = false
                                        cycle1_end = true
                                        break
                                    end
                                end
                            end
                        end
                    end
                    while cycle1_end do
                        if tiles_number >= forestbomb.towers then
                            --print("towers: "..forestbomb.towers)
                            for k = 1, forestbomb.towers+1, 1 do
                                if k ~= forestbomb.towers+1 then
                                    create_woodytower(user, props, team, facing, field, tile_array[k])
                                else
                                    cycle1_end = false
                                    break
                                end
                            end
                        else
                            --print("towers: "..tiles_number)
                            for k = 1, tiles_number+1, 1 do
                                if k ~= tiles_number+1 then
                                    create_woodytower(user, props, team, facing, field, tile_array[k])
                                else
                                    cycle1_end = false
                                    break
                                end
                            end
                        end
                    end
                else
                    create_effect(facing, smoke_texture, smoke_animation_path, "0", 0.0, -((3.0)*2), true, -9, field, target_tile)
                end
            end
            toss_spell(user,toss_height,attachment_texture,attachment_animation_path,target_tile,frames_in_air,action.on_landing)
            toss_spell_shadow(user, toss_height, frames_in_air, target_tile)
            toss_spell_hitbox(user, props, toss_height, frames_in_air, target_tile)
		end)

        Engine.play_audio(throw_sfx, AudioPriority.Low)
		actor:set_offset(original_offset.x, original_offset.y)
    end
	action.action_end_func = function(self, user)
		print("in custom card action action_end_func()!")
		actor:set_offset(original_offset.x, original_offset.y)
	end
    return action
end

function toss_spell(tosser,toss_height,texture,animation_path,target_tile,frames_in_air,arrival_callback)
    local starting_height = -110
    local start_tile = tosser:get_current_tile()
    local field = tosser:get_field()
    local spell = Battle.Spell.new(tosser:get_team())
    local spell_animation = spell:get_animation()
    spell_animation:load(animation_path)
    spell_animation:set_state("0")
    if tosser:get_height() > 1 then
        starting_height = -(tosser:get_height()*2)
    end

    spell.jump_started = false
    spell.starting_y_offset = starting_height
    spell.starting_x_offset = 10
    if tosser:get_facing() == Direction.Left then
        spell.starting_x_offset = -10
    end
    spell.y_offset = spell.starting_y_offset
    spell.x_offset = spell.starting_x_offset
    local sprite = spell:sprite()
    sprite:set_texture(texture)
    spell:set_offset(spell.x_offset,spell.y_offset)

    spell.update_func = function(self)
        if not spell.jump_started then
            self:jump(target_tile, toss_height, frames(frames_in_air), frames(frames_in_air), ActionOrder.Voluntary)
            self.jump_started = true
        end
        if self.y_offset < 0 then
            self.y_offset = self.y_offset + math.abs(self.starting_y_offset/frames_in_air)
            self.x_offset = self.x_offset - math.abs(self.starting_x_offset/frames_in_air)
            self:set_offset(self.x_offset,self.y_offset)
        else
            arrival_callback()
            self:delete()
        end
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    field:spawn(spell, start_tile)
end

function toss_spell_shadow(tosser, toss_height, frames_in_air, target_tile)
    local starting_height = -110
    local start_tile = tosser:get_current_tile()
    local field = tosser:get_field()
    local spell = Battle.Spell.new(tosser:get_team())
    local spell_animation = spell:get_animation()
    spell_animation:load(shadow_animation_path)
    spell_animation:set_state("0")
    if tosser:get_height() > 1 then
        starting_height = -(tosser:get_height())
    end

    spell.slide_started = false

    spell.jump_started = false
    spell.starting_y_offset = starting_height
    spell.starting_x_offset = 10
    if tosser:get_facing() == Direction.Left then
        spell.starting_x_offset = -10
    end
    spell.y_offset = spell.starting_y_offset
    spell.x_offset = spell.starting_x_offset
    local sprite = spell:sprite()
    sprite:set_texture(shadow_texture)
    spell:set_offset(spell.x_offset,0)

    spell.update_func = function(self)
        if not spell.jump_started then
            self:jump(target_tile, 0, frames(frames_in_air), frames(frames_in_air), ActionOrder.Voluntary)
            self.jump_started = true
        end
        if self.y_offset < 0 then
            self.y_offset = self.y_offset + math.abs(self.starting_y_offset/frames_in_air)
            self.x_offset = self.x_offset - math.abs(self.starting_x_offset/frames_in_air)
            self:set_offset(self.x_offset,0)
        else
            self:delete()
        end
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    field:spawn(spell, start_tile)
end

function toss_spell_hitbox(tosser, props, toss_height, frames_in_air, target_tile)
    local starting_height = -110
    local start_tile = tosser:get_current_tile()
    local field = tosser:get_field()
    local spell = Battle.Spell.new(tosser:get_team())
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch,
            props.element,
            tosser:get_id(),
            Drag.None
        )
    )
    spell.attacking = false
    local spell_animation = spell:get_animation()
    spell_animation:load(TESTDOT_ANIMPATH)
    spell_animation:set_state("0")
    spell_animation:set_playback_speed(0)
    spell_animation:on_complete(function()
		spell:erase()
	end)
    if tosser:get_height() > 1 then
        starting_height = -(tosser:get_height())
    end

    spell.slide_started = false

    spell.jump_started = false
    spell.starting_y_offset = starting_height
    spell.starting_x_offset = 10
    if tosser:get_facing() == Direction.Left then
        spell.starting_x_offset = -10
    end
    spell.y_offset = spell.starting_y_offset
    spell.x_offset = spell.starting_x_offset
    local sprite = spell:sprite()
    sprite:set_texture(shadow_texture)
    sprite:hide()
    spell:set_offset(spell.x_offset,spell.y_offset)

    spell.update_func = function(self)
        if self.attacking then
            self:get_current_tile():attack_entities(self)
        end
        if not spell.jump_started then
            self:jump(target_tile, 0, frames(frames_in_air), frames(frames_in_air), ActionOrder.Voluntary)
            self.jump_started = true
        end
        if self.y_offset < 0 then
            self.y_offset = self.y_offset + math.abs(self.starting_y_offset/frames_in_air)
            self.x_offset = self.x_offset - math.abs(self.starting_x_offset/frames_in_air)
            self:set_offset(self.x_offset,self.y_offset)
        else
            spell_animation:set_playback_speed(1)
            self.attacking = true
            --self:delete()
        end
        if not target_tile:is_walkable() then
            self:erase()
        end
    end
    spell.attack_func = function(self, ent)
        create_effect(tosser:get_facing(), EFFECT_TEXTURE, EFFECT_ANIMPATH, "0", math.random(-30,30), math.random(-50,-30), true, -999999, field, ent:get_current_tile())
        if Battle.Obstacle.from(ent) == nil then
            if Battle.Player.from(tosser) ~= nil then
                Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
            end
        else
            Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
        end
    end
    spell.collision_func = function(self)
        self:erase()
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    field:spawn(spell, start_tile)
end

function create_woodytower(user, props, team, facing, field, tile)
	local spell = Battle.Spell.new(team)
	spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch | Hit.Flash, 
            props.element,
            user:get_context(), 
            Drag.None
        )
    )
	spell:set_facing(facing)
    spell:never_flip(true)
    spell:set_offset(0, 3*2*-1)
    spell.attacking = false
	local sprite = spell:sprite()
    sprite:set_texture(WOODYTOWER_TEXTURE, true)
	sprite:set_layer(-3)
    local anim = spell:get_animation()
	anim:load(WOODYTOWER_ANIMPATH)
    anim:set_state("0")
    anim:refresh(sprite)
    anim:on_frame(2, function()
		if spell:get_current_tile():is_walkable() then
		    Engine.play_audio(WOODYTOWER_AUDIO, AudioPriority.Low)
            spell.attacking = true
        else
            spell:delete()
        end
    end)
    anim:on_complete(function()
        spell:delete()
    end)
	spell.update_func = function(self)
        local ref = self
        if ref.attacking then
            self:get_current_tile():attack_entities(self)
        end
        anim:on_frame(1, function()
            tile:highlight(Highlight.Flash)
        end)
    end
	spell.collision_func = function(self, ent)
		--
	end
    spell.attack_func = function(self, ent)
        if Battle.Obstacle.from(ent) == nil then
            if Battle.Player.from(user) ~= nil then
                Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
            end
        else
            Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
        end
    end
	spell.battle_end_func = function(self)
		self:delete()
	end
	spell.can_move_to_func = function(tile)
        return true
    end
    spell.delete_func = function(self)
		self:erase()
    end
	field:spawn(spell, tile)
    return spell
end

function shuffle(tbl)
    for i = #tbl, 2, -1 do
        local j = math.random(i)
        tbl[i], tbl[j] = tbl[j], tbl[i]
    end
    return tbl
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, flip, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    hitfx:never_flip(flip)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end

return forestbomb