local paladinsword = include("paladinsword/paladinsword.lua")

local DAMAGE = 180

paladinsword.type = 4
paladinsword.palette = 0

paladinsword.codes = {"P"}
paladinsword.shortname = "PldnSwrd"
paladinsword.damage = DAMAGE
paladinsword.time_freeze = false
paladinsword.element = Element.None
paladinsword.description = "Legendary swrd cuts 3 sq!"
paladinsword.long_description = "Sword of the legendary holy knight! Cuts 3 horizontal squares!"
paladinsword.can_boost = true
paladinsword.card_class = CardClass.Mega
paladinsword.limit = 1
paladinsword.mb = 65

function package_init(package)
    package:declare_package_id("com.OFC.card.EXEPoN-129-PaladinSword")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes(paladinsword.codes)

    local props = package:get_card_props()
    props.shortname = paladinsword.shortname
    props.damage = paladinsword.damage
    props.time_freeze = paladinsword.time_freeze
    props.element = paladinsword.element
    props.description = paladinsword.description
    props.long_description = paladinsword.long_description
    props.can_boost = paladinsword.can_boost
	props.card_class = paladinsword.card_class
	props.limit = paladinsword.limit
end

card_create_action = paladinsword.card_create_action