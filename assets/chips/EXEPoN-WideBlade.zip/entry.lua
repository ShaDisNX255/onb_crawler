local sword = include("sword/sword.lua")

local DAMAGE = 140

sword.type = 2
sword.palette = 5

sword.codes = {"B","K","S"}
sword.shortname = "WideBlde"
sword.damage = DAMAGE
sword.time_freeze = false
sword.element = Element.None
sword.description = "Cuts enmy in front! Range: 3"
sword.long_description = "Cuts the enemy in front! Attack range: 3 vertical squares"
sword.can_boost = true
sword.card_class = CardClass.Standard
sword.limit = 4
sword.mb = 38

function package_init(package)
    package:declare_package_id("com.OFC.card.EXEPoN-041-WideBlade")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes(sword.codes)

    local props = package:get_card_props()
    props.shortname = sword.shortname
    props.damage = sword.damage
    props.time_freeze = sword.time_freeze
    props.element = sword.element
    props.description = sword.description
    props.long_description = sword.long_description
    props.can_boost = sword.can_boost
	props.card_class = sword.card_class
	props.limit = sword.limit
end

card_create_action = sword.card_create_action