local DAMAGE = 40

local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."EXE4_270.ogg")
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."EXE4_221.ogg")
local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."effect.png")
local EFFECT_ANIMPATH = _folderpath.."effect.animation"

local PUCK_TEXTURE = Engine.load_texture(_folderpath.."puck.png")
local PUCK_ANIMPATH = _folderpath.."puck.animation"
local MOB_MOVE_TEXTURE = Engine.load_texture(_folderpath.."mob_move.png")
local MOB_MOVE_ANIMPATH = _folderpath.."mob_move.animation"
local LAUNCH_AUDIO = Engine.load_audio(_folderpath.."EXE4_169.ogg")
local BOUNCE_AUDIO = Engine.load_audio(_folderpath.."EXE4_180.ogg")

local airhockey = {
	tile_count = 7,

	codes = {"M","N","O","*"},
	shortname = "AirHock1",
	damage = DAMAGE,
	time_freeze = false,
	element = Element.None,
	description = "Bounce AirHockey off walls",
	long_description = "Toss the AirHockey which bounces off walls!",
	can_boost = true,
	card_class = CardClass.Standard,
	limit = 4,
	mb = 20
}

local frame_data = make_frame_data({
	{1, 0.200}, {2, 0.033}, {3, 0.033}, {4, 0.417}
})

airhockey.card_create_action = function(actor, props)
    print("in card_create_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_SWORD")
	local original_offset = actor:get_offset()
	action:override_animation_frames(frame_data)
	action:set_lockout(make_animation_lockout())
	action.execute_func = function(self, user)
		print("in custom card action execute_func()!")
		local actor = self:get_actor()
		local facing = user:get_facing()
		local field = user:get_field()
		local team = user:get_team()

		self:add_anim_action(2, function()
			local hilt = self:add_attachment("HILT")
			local hilt_sprite = hilt:sprite()
			hilt_sprite:set_texture(actor:get_texture())
			hilt_sprite:set_layer(-2)
			hilt_sprite:enable_parent_shader(true)
			local hilt_anim = hilt:get_animation()
			hilt_anim:copy_from(actor:get_animation())
			hilt_anim:set_state("HAND")
			hilt_anim:refresh(hilt_sprite)
		end)
		self:add_anim_action(3, function()
			local tile = user:get_tile(facing, 1)
			create_puck(user, props, team, facing, field, tile)
		end)

		actor:set_offset(original_offset.x, original_offset.y)
	end
	action.action_end_func = function(self, user)
        print("in custom card action action_end_func()!")
        actor:set_offset(original_offset.x, original_offset.y)
    end
	return action
end

function create_puck(user, props, team, facing, field, tile)
    local spell = Battle.Spell.new(team)
	local tile_count = airhockey.tile_count
    local direction = Direction.join(facing, Direction.Down)

    local anim = spell:get_animation()
    anim:load(PUCK_ANIMPATH)
    anim:set_state("0")
    local sprite = spell:sprite()
    sprite:set_texture(PUCK_TEXTURE)
    anim:refresh(sprite)
    anim:set_playback(Playback.Loop)

    spell:highlight_tile(Highlight.Solid)

    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flinch | Hit.Breaking,
            props.element,
            user:get_id(),
            Drag.None
        )
    )

    spell.update_func = function(self, dt) 
    	local tile = self:get_current_tile()
        tile:attack_entities(self)

		if tile:is_edge() or tile:is_hole() or tile_count < 1 then
			self:delete()
		end

        if not self:is_sliding() then
            local dest
        	local play_bounce
            dest, play_bounce, direction = Bounce(tile, spell, direction, team)
            if dest then
	            self:slide(dest, frames(4), frames(0), ActionOrder.Voluntary, nil)
	            if play_bounce then
	            	Engine.play_audio(BOUNCE_AUDIO, AudioPriority.Low)
	            end
	        else
	        	self:delete()
	        end
            tile_count = tile_count - 1
        end
    end

	spell.collision_func = function(self, other)
	end

    spell.attack_func = function(self, ent)
		create_effect(facing, EFFECT_TEXTURE, EFFECT_ANIMPATH, "1", math.random(-30,30), math.random(-50,-30), true, -999999, field, self:get_current_tile())
		if Battle.Obstacle.from(ent) == nil then
			if Battle.Player.from(user) ~= nil then
				Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
			end
		else
			Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		end
    end

    spell.delete_func = function(self)
		if not self:get_current_tile():is_edge() then
			--if we're not on an edge tile, which happens mostly at the end of battle for some reason,
			--then spawn a mob move to visually vanish the puck when it deletes.
			--presentation!
			create_effect(facing, MOB_MOVE_TEXTURE, MOB_MOVE_ANIMPATH, "DEFAULT", 0, 0, true, -9, field, self:get_current_tile())
		end
		self:erase()
    end

    spell.can_move_to_func = function(tile)
		--if tile:is_edge() or tile:is_hole() then
		if tile:is_edge() then
			return false
		end
		return true
    end

	Engine.play_audio(LAUNCH_AUDIO, AudioPriority.Low)

	field:spawn(spell, tile)

    return spell
end

function Bounce(tile, spell, direction, self_team)
	local play_bounce = true
    local new_dir = direction
    local tile_team = tile:get_team()	-- this is the team of the tile we're currently on

    -- no entry if the target tile is friendly and we aren't currently on a friendly tile
    local function teamcheck(new_tile)
    	local new_tile_team = new_tile:get_team()
	    if (new_tile_team == self_team) and not (new_tile_team == tile_team) then
	    	return true
	    end
	    return false
    end
    -- wraps up all the checks into one function and returns true if we can't move to the tile
    local function bad()
    	local new_tile = tile:get_tile(new_dir, 1)
    	if teamcheck(new_tile) then return true end
    	return not spell.can_move_to_func(new_tile)
    end

    -- check if any tile is accessible, 1) no flip, 2) flip x, 3) flip y, 4) flip x and y
    -- (there's no reason to check x before y, it's arbitrary, but the order matters for the other ones)
    if bad() then
	    new_dir = Direction.flip_x(direction)
	    if bad() then
		    new_dir = Direction.flip_y(direction)
		    if bad() then
			    new_dir = Direction.reverse(direction)
			    if bad() then
			    	-- by returning false, we nil some expected returns, but it's ok cuz the puck will die immediately
			    	return false
			    end
			end
	    end
	else
		play_bounce = false
    end

    direction = new_dir
    local dest = tile:get_tile(direction, 1)
	return dest, play_bounce, direction
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, flip, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    hitfx:never_flip(flip)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end

return airhockey