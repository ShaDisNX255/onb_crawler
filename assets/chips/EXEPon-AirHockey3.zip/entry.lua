local airhockey = include("airhockey/airhockey.lua")

local DAMAGE = 60

airhockey.tile_count = 15

airhockey.codes = {"S","T","U"}
airhockey.shortname = "AirHock3"
airhockey.damage = DAMAGE
airhockey.time_freeze = false
airhockey.element = Element.None
airhockey.description = "Bounce AirHockey off walls"
airhockey.long_description = "Toss the AirHockey which bounces off walls!"
airhockey.can_boost = true
airhockey.card_class = CardClass.Standard
airhockey.limit = 4
airhockey.mb = 40

function package_init(package) 
    package:declare_package_id("com.OFC.card.EXEPoN-065-AirHockey3")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(airhockey.codes)

    local props = package:get_card_props()
    props.shortname = airhockey.shortname
    props.damage = airhockey.damage
    props.time_freeze = airhockey.time_freeze
    props.element = airhockey.element
    props.description = airhockey.description
    props.long_description = airhockey.long_description
    props.can_boost = airhockey.can_boost
	props.card_class = airhockey.card_class
	props.limit = airhockey.limit
end

card_create_action = airhockey.card_create_action