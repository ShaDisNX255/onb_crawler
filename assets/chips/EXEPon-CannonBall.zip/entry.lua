local hougan = include("hougan/hougan.lua")

local DAMAGE = 160

hougan.type = 1

hougan.codes = {"B","T","V"}
hougan.shortname = "CannBall"
hougan.damage = DAMAGE
hougan.time_freeze = false
hougan.element = Element.None
hougan.description = "Breaks 3rd panel ahead"
hougan.long_description = "Throws a CannonBall 3 squares ahead! Breaks panel!"
hougan.can_boost = true
hougan.card_class = CardClass.Standard
hougan.limit = 4
hougan.mb = 33

function package_init(package)
    package:declare_package_id("com.OFC.card.EXEPoN-027-Hougan")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes(hougan.codes)

    local props = package:get_card_props()
    props.shortname = hougan.shortname
    props.damage = hougan.damage
    props.time_freeze = hougan.time_freeze
    props.element = hougan.element
    props.description = hougan.description
    props.long_description = hougan.long_description
    props.can_boost = hougan.can_boost
	props.card_class = hougan.card_class
	props.limit = hougan.limit
end

card_create_action = hougan.card_create_action