local curseshield = include("curseshield/curseshield.lua")

local DAMAGE = 180

curseshield.type = 2

curseshield.codes = {"B","C","L"}
curseshield.shortname = "CrsShld2"
curseshield.damage = DAMAGE
curseshield.time_freeze = false
curseshield.element = Element.None
curseshield.description = "Guard and bite enmy ahead"
curseshield.long_description = "Shield bites enemy ahead after TimingGuard"
curseshield.can_boost = true
curseshield.card_class = CardClass.Standard
curseshield.limit = 4
curseshield.mb = 40

function package_init(package) 
    package:declare_package_id("com.OFC.card.EXEPoN-086-CurseShield2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(curseshield.codes)

    local props = package:get_card_props()
    props.shortname = curseshield.shortname
    props.damage = curseshield.damage
    props.time_freeze = curseshield.time_freeze
    props.element = curseshield.element
    props.description = curseshield.description
    props.long_description = curseshield.long_description
    props.can_boost = curseshield.can_boost
	props.card_class = curseshield.card_class
	props.limit = curseshield.limit
end

card_create_action = curseshield.card_create_action