local DAMAGE = 150

local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."EXE4_270.ogg")
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."EXE4_221.ogg")
local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."effect.png")
local EFFECT_ANIMPATH = _folderpath.."effect.animation"
local TESTDOT_TEXTURE = Engine.load_texture(_folderpath.."testdot.png")
local TESTDOT_ANIMPATH = _folderpath.."testdot.animation"

--local CURSESHIELD_TEXTURE = Engine.load_texture(_folderpath.."curseshield.png")
local CURSESHIELD_ANIMPATH = _folderpath.."curseshield.animation"
local SHIELD_AUDIO = Engine.load_audio(_folderpath.."EXE4_8.ogg")
local TINK_AUDIO = Engine.load_audio(_folderpath.."EXE4_49.ogg")
local BITE_AUDIO = Engine.load_audio(_folderpath.."EXE3_150.ogg")

local curseshield = {
    type = 1,

    codes = {"A","C","L","*"},
    shortname = "CrsShld1",
    damage = DAMAGE,
    time_freeze = false,
    element = Element.None,
    description = "Shield bites enmy ahd",
    long_description = "Shield bites enemy ahead after TimingGuard",
    can_boost = true,
    card_class = CardClass.Standard,
    limit = 4,
    mb = 32
}

curseshield.card_create_action = function(actor, props)
    print("in card_create_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	local original_offset = actor:get_offset()
    local override_frames = {
        {1,0.433},{1,0.117}
    }
    local frame_data = make_frame_data(override_frames)
	action:override_animation_frames(frame_data)
	action:set_lockout(make_animation_lockout())
    action.action_end_func = function(self, user)
		print("in custom card action action_end_func()!")
        actor:remove_defense_rule(action.guarding_defense_rule)
		actor:set_offset(original_offset.x, original_offset.y)
    end
    action.execute_func = function(self, user)
        local facing = user:get_facing()
        local field = user:get_field()
        local team = user:get_team()
        local self_tile = user:get_current_tile()

        --local props = self:copy_metadata()
		local guarding = false
        local guard_attachment = self:add_attachment("ORIGIN")
        --local guard_attachment = Battle.Artifact.new()
        --guard_attachment:set_facing(facing)
        local guard_sprite = guard_attachment:sprite()
        guard_sprite:set_texture(Engine.load_texture(_folderpath.."curseshield"..curseshield.type..".png"))
        guard_sprite:set_layer(-2)

        local guard_animation = guard_attachment:get_animation()
        guard_animation:load(CURSESHIELD_ANIMPATH)
        guard_animation:set_state("GUARD")
        guard_animation:refresh(guard_sprite)

        action.guarding_defense_rule = Battle.DefenseRule.new(0,DefenseOrder.Always)

		self:add_anim_action(1,function()
			guarding = true
            Engine.play_audio(SHIELD_AUDIO, AudioPriority.Highest)
		end)
		self:add_anim_action(2,function()
            guard_animation:set_state("FADE")
            guard_animation:refresh(guard_sprite)
			guarding = false
            user:remove_defense_rule(action.guarding_defense_rule)
		end)

        action.guarding_defense_rule.can_block_func = function(judge, attacker, defender)
            if not guarding then 
                return 
            end
            local attacker_hit_props = attacker:copy_hit_props()
            if attacker_hit_props.damage > 0 then
                if attacker_hit_props.flags & Hit.Breaking == Hit.Breaking then
                    --cant block breaking hits with guard
                    return
                end
                judge:block_impact()
                judge:block_damage()
                Engine.play_audio(TINK_AUDIO, AudioPriority.Highest)
                local reflected_damage = props.damage
                if not action.guarding_defense_rule.has_reflected then
                    create_effect(facing, EFFECT_TEXTURE, EFFECT_ANIMPATH, "1", math.random(-30,30), math.random(-50,-30), true, -999999, field, self_tile)
                    --spawn_shockwave(user, user:get_team(),user:get_field(),user:get_tile(direction, 1), direction,reflected_damage, wave_texture,wave_sfx,0.2)
                    create_attack(user, props, team, facing, field, user:get_tile(facing, 1))
                    guard_sprite:hide()
			        guarding = false
                    user:remove_defense_rule(action.guarding_defense_rule)

                    action.guarding_defense_rule.has_reflected = true
                end
            end
        end

        user:add_defense_rule(action.guarding_defense_rule)
        actor:set_offset(original_offset.x, original_offset.y)
    end
    return action
end

function create_attack(user, props, team, facing, field, tile)
	local spell = Battle.Spell.new(team)
	spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch | Hit.Flash, 
            props.element,
            user:get_id(), 
            Drag.None
        )
    )
	spell:set_facing(facing)
    spell.slide_started = false
    spell.attacking = false
	local sprite = spell:sprite()
    sprite:set_texture(Engine.load_texture(_folderpath.."curseshield"..curseshield.type..".png"), true)
	sprite:set_layer(-3)
    local anim = spell:get_animation()
	anim:load(CURSESHIELD_ANIMPATH)
    anim:set_state("ATTACK")
    anim:refresh(sprite)
    anim:set_playback(Playback.Loop)
    local target_locked = false
    local checkTHP = function(ent)
        if not user:is_team(ent:get_team()) and ent:get_health() > 0 then
            return true
        end
    end
    local checkC = false
    spell.on_spawn_func = function(self)
        --
    end
    local do_once = true
    local do_once2 = true
	spell.update_func = function(self)
        local ref = self
        if ref.attacking then
            self:get_current_tile():attack_entities(self)
        end
        if not target_locked then
            local dest = self:get_tile(facing, 1)
            if self:get_current_tile():is_edge() and self.slide_started then
                self:erase()
            end
            checkC = #self:get_current_tile():find_characters(checkTHP) > 0
            if checkC then
                if do_once then
                    do_once = false
                    target_locked = true
                    anim:set_state("BITE")
                    anim:refresh(sprite)
                    anim:set_playback(Playback.Once)
                    ref.slide_started = false
                end
            end
            self:slide(dest, frames(3), frames(0), ActionOrder.Voluntary, function()
                ref.slide_started = true
            end)
        else
            if anim:get_state() == "BITE" then
                anim:on_frame(4, function()
                    if do_once2 then
                        do_once2 = false
                        ref.attacking = true
                        Engine.play_audio(BITE_AUDIO, AudioPriority.Low)
                    end
                end)
                anim:on_complete(function()
                    self:erase()
                end)
            end
        end
    end
	spell.collision_func = function(self, ent)
        self:erase()
	end
    spell.attack_func = function(self, ent)
        create_effect(facing, EFFECT_TEXTURE, EFFECT_ANIMPATH, "8", math.random(-10,10), math.random(-20,-10), true, -999999, field, ent:get_current_tile())
        if Battle.Obstacle.from(ent) == nil then
            if Battle.Player.from(user) ~= nil then
                Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
            end
        else
            Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
        end
    end
	spell.battle_end_func = function(self)
		self:delete()
	end
	spell.can_move_to_func = function(tile)
        if target_locked then
            return false
        else
            return true
        end
    end
    spell.delete_func = function(self)
		self:erase()
    end
	field:spawn(spell, tile)
    return spell
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, flip, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    hitfx:never_flip(flip)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end

return curseshield