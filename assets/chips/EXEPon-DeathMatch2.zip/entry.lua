local deathmatch = include("deathmatch/deathmatch.lua")

local DAMAGE = 0

deathmatch.type = 2

deathmatch.codes = {"N","T","X"}
deathmatch.shortname = "DthMtch2"
deathmatch.damage = DAMAGE
deathmatch.time_freeze = true
deathmatch.element = Element.None
deathmatch.description = "Breaks all empty panels!"
deathmatch.long_description = "Breaks all empty squares!"
deathmatch.can_boost = false
deathmatch.card_class = CardClass.Standard
deathmatch.limit = 4
deathmatch.mb = 52

function package_init(package) 
    package:declare_package_id("com.OFC.card.EXEPoN-103-DeathMatch2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(deathmatch.codes)

    local props = package:get_card_props()
    props.shortname = deathmatch.shortname
    props.damage = deathmatch.damage
    props.time_freeze = deathmatch.time_freeze
    props.element = deathmatch.element
    props.description = deathmatch.description
    props.long_description = deathmatch.long_description
    props.can_boost = deathmatch.can_boost
	props.card_class = deathmatch.card_class
	props.limit = deathmatch.limit
end

card_create_action = deathmatch.card_create_action