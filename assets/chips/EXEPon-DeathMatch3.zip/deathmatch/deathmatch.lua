local DAMAGE

local TESTDOT_TEXTURE = Engine.load_texture(_folderpath.."testdot.png")
local TESTDOT_ANIMPATH = _folderpath.."testdot.animation"

local SMOKE_TEXTURE = Engine.load_texture(_folderpath.."smoke.png")
local SMOKE_ANIMPATH = _folderpath.."smoke.animation"
local CRACK_AUDIO = Engine.load_audio(_folderpath.."EXE4_353.ogg")
local POISON_TEXTURE = Engine.load_texture(_folderpath.."smoke_poison.png")
local POISON_ANIMPATH = _folderpath.."smoke_poison.animation"
local POISON_AUDIO = Engine.load_audio(_folderpath.."EXE4_344.ogg")

local deathmatch = {
    type = 1,

    codes = {"J","K","X"},
    shortname = "DthMtch1",
    damage = DAMAGE,
    time_freeze = true,
    element = Element.None,
    description = "Cracks all panels!",
    long_description = "Cracks all squares with panels!",
    can_boost = false,
    card_class = CardClass.Standard,
    limit = 4,
    mb = 32
}

deathmatch.card_create_action = function(actor, props)
    print("in card_create_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	local original_offset = actor:get_offset()
    action:set_lockout(make_sequence_lockout())
    action.execute_func = function(self, user)
		print("in custom card action execute_func()!")
		local actor = self:get_actor()
		local facing = user:get_facing()
		local field = user:get_field()
		local team = user:get_team()
		local self_tile = user:get_current_tile()

        local check = function(ent)
            if ent:get_height() > 0 then
			    return true
            end
        end
        local targets = {}
        local trg_count = 1
        for i = 1, 6, 1 do
            for j = 1, 3, 1 do
                if      deathmatch.type == 2 then
                    if field:tile_at(i,j) ~= nil and not field:tile_at(i,j):is_edge() and not field:tile_at(i,j):is_hole() then
                        targets[trg_count] = field:tile_at(i,j)
                        trg_count = trg_count + 1
                    end
                elseif  deathmatch.type == 3 then
                    if field:tile_at(i,j) ~= nil and not field:tile_at(i,j):is_edge() and field:tile_at(i,j):get_state() ~= TileState.Poison and not field:tile_at(i,j):is_hole() then
                        targets[trg_count] = field:tile_at(i,j)
                        trg_count = trg_count + 1
                    end
                else
                    if field:tile_at(i,j) ~= nil and not field:tile_at(i,j):is_edge() and not field:tile_at(i,j):is_cracked() and not field:tile_at(i,j):is_hole() then
                        targets[trg_count] = field:tile_at(i,j)
                        trg_count = trg_count + 1
                    end
                end
            end
        end
        shuffle(targets)
        local trg_counter = trg_count
        local trg_counter2 = trg_counter

        local step1 = Battle.Step.new()

        self.spawner = nil
        self.tile    = self_tile

        local ref = self

        local do_once = true
        step1.update_func = function(self, dt)
            if do_once then
                do_once = false
                ref.spawner = Battle.Artifact.new()
                ref.spawner:set_facing(facing)
                local anim = ref.spawner:get_animation()
                anim:load(TESTDOT_ANIMPATH)
                anim:set_state("1")
                for i = 1, trg_counter2, 1 do
                    if i ~= trg_counter then
                        --print("trg_counter: "..trg_counter)
                        --print("i: "..i)
                        anim:on_frame(i+1, function()
                            local crack_tile = field:tile_at(targets[i]:x(),targets[i]:y())
                            if deathmatch.type == 3 then
                                local poison_fx = create_effect(facing, POISON_TEXTURE, POISON_ANIMPATH, "1", 0, (2*2), true, -9, field, crack_tile)
                                poison_fx.update_func = function(self)
                                    poison_fx:set_offset(poison_fx:get_offset().x, poison_fx:get_offset().y - (2*2))
                                end
                                Engine.play_audio(POISON_AUDIO, AudioPriority.Highest)
                            else
                                create_effect(facing, SMOKE_TEXTURE, SMOKE_ANIMPATH, "1", 0, 0, true, -9, field, crack_tile)
                                Engine.play_audio(CRACK_AUDIO, AudioPriority.Highest)
                            end
                            if      deathmatch.type == 2 then
                                if #crack_tile:find_characters(check) > 0 then
                                    crack_tile:set_state(TileState.Cracked)
                                else
                                    crack_tile:set_state(TileState.Broken)
                                end
                            elseif  deathmatch.type == 3 then
                                crack_tile:set_state(TileState.Poison)
                            else
                                crack_tile:set_state(TileState.Cracked)
                            end
                            trg_counter = trg_counter - 1
                        end)
                    else
                        --print("END1")
                        anim:on_frame(trg_counter, function()
                            --print("END2")
                            anim:set_state("2")
                            anim:on_complete(function()
                                --print("END3")
                                ref.spawner:erase()
                                step1:complete_step()
                            end)
                        end)
                    end
                end
                field:spawn(ref.spawner, ref.tile)
            end
        end
        self:add_step(step1)

        actor:set_offset(original_offset.x, original_offset.y)
    end
    action.action_end_func = function(self, user)
        print("in custom card action action_end_func()!")
        actor:set_offset(original_offset.x, original_offset.y)
    end
    return action
end

function shuffle(tbl)
    for i = #tbl, 2, -1 do
        local j = math.random(i)
        tbl[i], tbl[j] = tbl[j], tbl[i]
    end
    return tbl
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, flip, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    hitfx:never_flip(flip)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end

return deathmatch