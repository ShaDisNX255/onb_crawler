local DAMAGE = 60

local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."EXE4_270.ogg")
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."EXE4_221.ogg")
local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."effect.png")
local EFFECT_ANIMPATH = _folderpath.."effect.animation"

local SHOCKWAVE_TEXTURE = Engine.load_texture(_folderpath.."shockwave.png")
local SHOCKWAVE_ANIMPATH = _folderpath.."shockwave.animation"
local SHOCKWAVE_AUDIO = Engine.load_audio(_folderpath.."EXE4_60.ogg")

local shockwave = {
    type = "0",

    codes = {"D","J","R","*"},
    shortname = "ShokWave",
    damage = DAMAGE,
    time_freeze = false,
    element = Element.None,
    description = "Shock through enemies",
    long_description = "A piercing attack that moves across the ground",
    can_boost = true,
    card_class = CardClass.Standard,
    limit = 4,
    mb = 16
}

shockwave.card_create_action = function(actor, props)
    print("in card_create_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_SWORD")
	local original_offset = actor:get_offset()
    local override_frames = {
        {1, 0.033}, {2, 0.033}, {3, 0.033}, {4, 0.417}
    }
    local frame_data = make_frame_data(override_frames)
	action:override_animation_frames(frame_data)
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
		print("in custom card action execute_func()!")
		local actor = self:get_actor()
		local facing = user:get_facing()
		local field = user:get_field()
		local team = user:get_team()

		self:add_anim_action(2, function()
			user:toggle_counter(true)
			local hilt = self:add_attachment("HILT")
			local hilt_sprite = hilt:sprite()
			hilt_sprite:set_texture(actor:get_texture())
			hilt_sprite:set_layer(-2)
			hilt_sprite:enable_parent_shader(true)
			local hilt_anim = hilt:get_animation()
			hilt_anim:copy_from(actor:get_animation())
			hilt_anim:set_state("HAND")
			hilt_anim:refresh(hilt_sprite)
		end)
				
		self:add_anim_action(3, function()
			local tile = user:get_tile(facing, 1)
			spawn_shockwave(user, props, team, facing, field, tile)
		end)

        actor:set_offset(original_offset.x, original_offset.y)
    end
    action.action_end_func = function(self, user)
		actor:set_offset(original_offset.x, original_offset.y)
	end
    return action
end

function spawn_shockwave(user, props, team, facing, field, tile)
    local spawn_next
    spawn_next = function()
        if not tile:is_walkable() then return end

        local spell = Battle.Spell.new(team)
        spell:set_facing(facing)
        spell:set_hit_props(
            HitProps.new(
                props.damage, 
                Hit.Impact | Hit.Flinch | Hit.Flash, 
                props.element, 
                user:get_id(), 
                Drag.None
            )
        )
        local sprite = spell:sprite()
        sprite:set_texture(SHOCKWAVE_TEXTURE)
        sprite:set_layer(-3)
        local animation = spell:get_animation()
        animation:load(SHOCKWAVE_ANIMPATH)
        animation:set_state(shockwave.type)
        animation:refresh(sprite)
        animation:on_frame(5, function()
            tile = tile:get_tile(facing, 1)
            spawn_next()
        end, true)
        animation:on_complete(function()
            spell:delete()
        end)

        spell.update_func = function(self)
            self:get_current_tile():attack_entities(self)
        end
        spell.attack_func = function(self, ent)
            create_effect(facing, EFFECT_TEXTURE, EFFECT_ANIMPATH, "1", math.random(-30,30), math.random(-50,-30), true, -999999, field, ent:get_current_tile())
            if Battle.Obstacle.from(ent) == nil then
				if Battle.Player.from(user) ~= nil then
					Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
				end
			else
				Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
			end
        end
        spell.battle_end_func = function(self)
            self:delete()
        end
        spell.delete_func = function(self)
            self:erase()
        end

        Engine.play_audio(SHOCKWAVE_AUDIO, AudioPriority.Low)

        field:spawn(spell, tile)
    end

    spawn_next()
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, flip, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    hitfx:never_flip(flip)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end

return shockwave