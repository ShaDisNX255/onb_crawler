local flameline = include("flameline/flameline.lua")

local DAMAGE = 100

flameline.codes = {"D","E","F"}
flameline.shortname = "FlmLine2"
flameline.damage = DAMAGE
flameline.time_freeze = false
flameline.element = Element.Fire
flameline.description = "FlamTower 2sq ahead 3sq long!"
flameline.long_description = "FlameTower attack on 3 squares vertically 2 squares ahead!"
flameline.can_boost = true
flameline.card_class = CardClass.Standard
flameline.limit = 4
flameline.mb = 36

function package_init(package) 
    package:declare_package_id("com.OFC.card.EXEPoN-055-FlameLine2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(flameline.codes)

    local props = package:get_card_props()
    props.shortname = flameline.shortname
    props.damage = flameline.damage
    props.time_freeze = flameline.time_freeze
    props.element = flameline.element
    props.description = flameline.description
    props.long_description = flameline.long_description
    props.can_boost = flameline.can_boost
	props.card_class = flameline.card_class
	props.limit = flameline.limit
end

card_create_action = flameline.card_create_action