local DAMAGE = 60

local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."EXE4_270.ogg")
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."EXE4_221.ogg")
local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."effect.png")
local EFFECT_ANIMPATH = _folderpath.."effect.animation"
local TESTDOT_TEXTURE = Engine.load_texture(_folderpath.."testdot.png")
local TESTDOT_ANIMPATH = _folderpath.."testdot.animation"

local FLAMETOWER_TEXTURE = Engine.load_texture(_folderpath.."flametower.png")
local FLAMETOWER_ANIMPATH = _folderpath.."flametower.animation"
local FLAMELINE_AUDIO = Engine.load_audio(_folderpath.."EXE4_216.ogg")

local flameline = {
    codes = {"F","G","H","*"},
    shortname = "FlmLine1",
    damage = DAMAGE,
    time_freeze = false,
    element = Element.Fire,
    description = "FlamTower 2sq ahead 3sq long!",
    long_description = "FlameTower attack on 3 squares vertically 2 squares ahead!",
    can_boost = true,
    card_class = CardClass.Standard,
    limit = 4,
    mb = 22
}

flameline.card_create_action = function(actor, props)
    print("in card_create_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_SWORD")
	local original_offset = actor:get_offset()
    local override_frames = {
        {1, 0.033}, {2, 0.033}, {3, 0.033}, {4, 0.4}
    }
    local frame_data = make_frame_data(override_frames)
	action:override_animation_frames(frame_data)
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        print("in custom card action execute_func()!")
        local actor = self:get_actor()
        local facing = user:get_facing()
        local field = user:get_field()
        local team = user:get_team()
        local self_tile = user:get_current_tile()

        self:add_anim_action(2, function()
			local hilt = self:add_attachment("HILT")
			local hilt_sprite = hilt:sprite()
			hilt_sprite:set_texture(actor:get_texture())
			hilt_sprite:set_layer(-2)
			hilt_sprite:enable_parent_shader(true)
			local hilt_anim = hilt:get_animation()
			hilt_anim:copy_from(actor:get_animation())
			hilt_anim:set_state("HAND")
			hilt_anim:refresh(hilt_sprite)
		end)
        self:add_anim_action(3, function()
            local tile = self_tile:get_tile(facing, 2)
            local tile_U = tile:get_tile(Direction.Up, 1)
            local tile_D = tile:get_tile(Direction.Down, 1)
            create_flametower(user, props, team, facing, field, tile)
            create_flametower(user, props, team, facing, field, tile_U)
            create_flametower(user, props, team, facing, field, tile_D)
        end)
		
		actor:set_offset(original_offset.x, original_offset.y)
    end
    action.action_end_func = function(self)
		print("in custom card action action_end_func()!")
		actor:set_offset(original_offset.x, original_offset.y)
    end
    return action
end

function create_flametower(user, props, team, facing, field, tile)
    local spawn_next
    spawn_next = function()
        if not tile:is_walkable() then return end

	    local spell = Battle.Spell.new(team)
	    spell:set_hit_props(
            HitProps.new(
                props.damage,
                Hit.Impact | Hit.Flinch | Hit.Flash, 
                props.element,
                user:get_id(), 
                Drag.None
            )
        )
	    spell:set_facing(facing)
        spell:never_flip(true)
        spell:set_offset(0, 3*2*-1)
        spell.attacking = false
	    local sprite = spell:sprite()
        sprite:set_texture(FLAMETOWER_TEXTURE, true)
	    sprite:set_layer(-3)
        local anim = spell:get_animation()
	    anim:load(FLAMETOWER_ANIMPATH)
        anim:set_state("0")
        anim:refresh(sprite)
        anim:on_frame(2, function()
            spell.attacking = true
        end)
        anim:on_complete(function()
            spell:delete()
        end)
        local query_TeamHP = function(ent)
            if not user:is_team(ent:get_team()) and ent:get_health() > 0 then
                return true
            end
        end
        spell.on_spawn_func = function(self)
            Engine.play_audio(FLAMELINE_AUDIO, AudioPriority.Low)
        end
	    spell.update_func = function(self)
            local self_tile = self:get_current_tile()
            local ref = self
            if ref.attacking then
                self_tile:attack_entities(self)
			    if 		props.element == Element.Aqua then
			    	if self_tile ~= nil and
			    		not self_tile:is_edge() and
			    		#self_tile:find_characters(query_TeamHP) <= 0 and 
			    		#self_tile:find_obstacles(query_TeamHP) <= 0 and 
			    		self_tile:get_state() == TileState.Lava
			    		then
			    		self_tile:set_state(TileState.Normal)
			    	end
			    elseif	props.element == Element.Fire then
			    	if self_tile ~= nil and
			    		not self_tile:is_edge() and
			    		#self_tile:find_characters(query_TeamHP) <= 0 and 
			    		#self_tile:find_obstacles(query_TeamHP) <= 0 and 
			    		self_tile:get_state() == TileState.Grass
			    		then
			    		self_tile:set_state(TileState.Normal)
			    	end
			    end
            end
        end
	    spell.collision_func = function(self, ent)
            --
	    end
        spell.attack_func = function(self, ent)
            create_effect(facing, EFFECT_TEXTURE, EFFECT_ANIMPATH, "2", math.random(-30,30), math.random(-50,-30), true, -999999, field, ent:get_current_tile())
            if Battle.Obstacle.from(ent) == nil then
                if Battle.Player.from(user) ~= nil then
                    Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
                end
            else
                Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
            end
        end
	    spell.battle_end_func = function(self)
	    	self:delete()
	    end
	    spell.can_move_to_func = function(tile)
            return true
        end
        spell.delete_func = function(self)
	    	self:erase()
        end
	    field:spawn(spell, tile)
    end
    spawn_next()
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, flip, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    hitfx:never_flip(flip)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)
    
    return hitfx
end

return flameline