local hatman = include("hatman/hatman.lua")

local DAMAGE = 90

hatman.codes = {"H"}
hatman.shortname = "HatManSP"
hatman.damage = DAMAGE
hatman.time_freeze = true
hatman.element = Element.None
hatman.description = "Attack w/ roses & swords!"
hatman.long_description = "Attack with brilliant illusion of roses and swords!"
hatman.can_boost = true
hatman.card_class = CardClass.Mega
hatman.limit = 1
hatman.mb = 80

function package_init(package) 
    package:declare_package_id("com.OFC.card.EXEPoN-175-HatManSP")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(hatman.codes)

    local props = package:get_card_props()
    props.shortname = hatman.shortname
    props.damage = hatman.damage
    props.time_freeze = hatman.time_freeze
    props.element = hatman.element
    props.description = hatman.description
    props.long_description = hatman.long_description
    props.can_boost = hatman.can_boost
	props.card_class = hatman.card_class
	props.limit = hatman.limit
end

card_create_action = hatman.card_create_action