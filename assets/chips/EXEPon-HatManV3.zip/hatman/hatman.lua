local DAMAGE = 50

local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."EXE4_270.ogg")
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."EXE4_221.ogg")

local HATMAN_TEXTURE = Engine.load_texture(_folderpath.."hatman.png")
local HATMAN_ANIMPATH = _folderpath.."hatman.animation"
local SLASH_TEXTURE = Engine.load_texture(_folderpath.."spell_sword_slashes.png")
local SLASH_ANIMPATH = _folderpath.."spell_sword_slashes.animation"
local ROSE_TEXTURE = Engine.load_texture(_folderpath.."rose.png")
local ROSE_ANIMPATH = _folderpath.."rose.animation"
local AUDIO_SPAWN = Engine.load_audio(_folderpath.."EXE4_57.ogg")
local AUDIO_SLASH = Engine.load_audio(_folderpath.."EXE4_13.ogg")
local AUDIO_ROSE = Engine.load_audio(_folderpath.."EXE4_6.ogg")

local hatman = {
    codes = {"H"},
    shortname = "HatMan",
    damage = DAMAGE,
    time_freeze = true,
    element = Element.None,
    description = "Attack w/ roses & swords!",
    long_description = "Attack with brilliant illusion of roses and swords!",
    can_boost = true,
    card_class = CardClass.Mega,
    limit = 1,
    mb = 50
}

hatman.card_create_action = function(actor, props)
    print("in card_create_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_MOVE")
	local original_offset = actor:get_offset()
    local override_frames = {
        {1, 0.0166}, {2, 0.0166}, {3, 0.5440}, {3, 0.0166}, {2, 0.0166}, {1, 0.0166}, {1, 0.5260}
    }
    local frame_data = make_frame_data(override_frames)
    action:set_lockout(make_animation_lockout())
    action:override_animation_frames(frame_data)
    action.execute_func = function(self, user)
        print("in custom card action execute_func()!")
        local actor = self:get_actor()
        local facing = user:get_facing()
        local field = user:get_field()
        local team = user:get_team()
        local self_tile = user:get_current_tile()
        local tile_array1 = {}
        local tile_array2 = {}
        local tile_array3 = {}
		local check_front1 = false
        local check_target1 = false
        local check_target11 = false
		local check_front2 = false
        local check_target2 = false
        local check_target22 = false
		local check_front3 = false
        local check_target3 = false
        local check_target33 = false

        local self_X = self_tile:x()
        local self_X_offset1 = nil
        if facing == Direction.Right then
            self_X_offset1 = self_X + 1
        else
            self_X_offset1 = self_X - 1
        end
        local self_Y = self_tile:y()

        local targeted1 = false
        local targeted2 = false
        local targeted3 = false

        local check = function(ent)
			return true
        end
        local checkT = function(ent)
            if not user:is_team(ent:get_team()) and ent:get_health() > 0 then
				return true
			end
        end
        local checkOBS = function(ent)
            if ent:get_health() > 0 then
                return true
            end
        end

        if facing == Direction.Right then
            for i = 0, 7, 1 do
                if i > self_X_offset1 then
                    if not targeted1 then
                        local tile_front1 = field:tile_at(i, 1)
                        local tile_front11 = tile_front1:get_tile(Direction.reverse(facing), 1)
                        check_target1 = #tile_front1:find_characters(checkT) > 0 or #tile_front1:find_obstacles(checkT) > 0
                        check_target11 = #tile_front11:find_characters(checkOBS) <= 0 and #tile_front11:find_obstacles(checkOBS) <= 0
                        check_front1 = tile_front1 and tile_front1 ~= nil and not tile_front1:is_edge()
                        if check_front1 and check_target1 and check_target11 then
                            targeted1 = true
                            --print("TARGETED-1")
                            table.insert(tile_array1, tile_front1)
                            break
                        end
                    end
                end
            end
            for j = 0, 7, 1 do
                if j > self_X_offset1 then
                    if not targeted2 then
                        local tile_front2 = field:tile_at(j, 2)
                        local tile_front22 = tile_front2:get_tile(Direction.reverse(facing), 1)
                        check_target2 = #tile_front2:find_characters(checkT) > 0 or #tile_front2:find_obstacles(checkT) > 0
                        check_target22 = #tile_front22:find_characters(checkOBS) <= 0 and #tile_front22:find_obstacles(checkOBS) <= 0
                        check_front2 = tile_front2 and tile_front2 ~= nil and not tile_front2:is_edge()
                        if check_front2 and check_target2 and check_target22 then
                            targeted2 = true
                            --print("TARGETED-2")
                            table.insert(tile_array2, tile_front2)
                            break
                        end
                    end
                end
            end
            for k = 0, 7, 1 do
                if k > self_X_offset1 then
                    if not targeted3 then
                        local tile_front3 = field:tile_at(k, 3)
                        local tile_front33 = tile_front3:get_tile(Direction.reverse(facing), 1)
                        check_target3 = #tile_front3:find_characters(checkT) > 0 or #tile_front3:find_obstacles(checkT) > 0
                        check_target33 = #tile_front33:find_characters(checkOBS) <= 0 and #tile_front33:find_obstacles(checkOBS) <= 0
                        check_front3 = tile_front3 and tile_front3 ~= nil and not tile_front3:is_edge()
                        if check_front3 and check_target3 and check_target33 then
                            targeted3 = true
                            --print("TARGETED-3")
                            table.insert(tile_array3, tile_front3)
                            break
                        end
                    end
                end
            end
        else
            for i = 7, 0, -1 do
                if i < self_X_offset1 then
                    if not targeted1 then
                        local tile_front1 = field:tile_at(i, 1)
                        local tile_front11 = tile_front1:get_tile(Direction.reverse(facing), 1)
                        check_target1 = #tile_front1:find_characters(checkT) > 0 or #tile_front1:find_obstacles(checkT) > 0
                        check_target11 = #tile_front11:find_characters(checkOBS) <= 0 and #tile_front11:find_obstacles(checkOBS) <= 0
                        check_front1 = tile_front1 and tile_front1 ~= nil and not tile_front1:is_edge()
                        if check_front1 and check_target1 and check_target11 then
                            targeted1 = true
                            --print("TARGETED-1")
                            table.insert(tile_array1, tile_front1)
                            break
                        end
                    end
                end
            end
            for j = 7, 0, -1 do
                if j < self_X_offset1 then
                    if not targeted2 then
                        local tile_front2 = field:tile_at(j, 1)
                        local tile_front22 = tile_front2:get_tile(Direction.reverse(facing), 1)
                        check_target2 = #tile_front2:find_characters(checkT) > 0 or #tile_front2:find_obstacles(checkT) > 0
                        check_target22 = #tile_front22:find_characters(checkOBS) <= 0 and #tile_front22:find_obstacles(checkOBS) <= 0
                        check_front2 = tile_front2 and tile_front2 ~= nil and not tile_front2:is_edge()
                        if check_front2 and check_target2 and check_target22 then
                            targeted2 = true
                            --print("TARGETED-2")
                            table.insert(tile_array2, tile_front2)
                            break
                        end
                    end
                end
            end
            for k = 7, 0, -1 do
                if k < self_X_offset1 then
                    if not targeted3 then
                        local tile_front3 = field:tile_at(k, 1)
                        local tile_front33 = tile_front3:get_tile(Direction.reverse(facing), 1)
                        check_target3 = #tile_front3:find_characters(checkT) > 0 or #tile_front3:find_obstacles(checkT) > 0
                        check_target33 = #tile_front33:find_characters(checkOBS) <= 0 and #tile_front33:find_obstacles(checkOBS) <= 0
                        check_front3 = tile_front3 and tile_front3 ~= nil and not tile_front3:is_edge()
                        if check_front3 and check_target3 and check_target33 then
                            targeted3 = true
                            --print("TARGETED-3")
                            table.insert(tile_array3, tile_front3)
                            break
                        end
                    end
                end
            end
        end

        local navi = nil
        local navi_anim = nil

        action:add_anim_action(3, function()
            actor:hide()
            actor:get_animation():set_playback_speed(0)

            navi = Battle.Artifact.new()
            navi:set_facing(facing)
            navi:sprite():set_layer(-3)
		    navi:sprite():set_texture(HATMAN_TEXTURE, true)
            navi_anim = navi:get_animation()
            navi_anim:load(HATMAN_ANIMPATH)
            navi_anim:set_state("IDLE")
		    navi_anim:refresh(navi:sprite())
            navi_anim:set_playback(Playback.Once)
            --[[if user:get_current_tile():is_hole() then
                print("Tile ("..self_tile:x()..";"..self_tile:y()..") IS a hole!")
                navi_anim:set_state("HOLE")
		        navi_anim:refresh(navi:sprite())
            else
                print("Tile ("..self_tile:x()..";"..self_tile:y()..") is NOT a hole!")
                navi_anim:set_state("NOHOLE")
                navi_anim:refresh(navi:sprite())
            end]]
            navi_anim:on_frame(2, function()
		    	Engine.play_audio(AUDIO_SPAWN, AudioPriority.Low)
		    end)
            navi_anim:on_frame(5, function()
                --Roses
                local tile_front_1 = field:tile_at(self_X_offset1, 1)
                local tile_front_2 = field:tile_at(self_X_offset1, 2)
                local tile_front_3 = field:tile_at(self_X_offset1, 3)
		    	local armr1 = create_effect(facing, HATMAN_TEXTURE, HATMAN_ANIMPATH, "ROSE", 0, (20*2)*(-1), false, -4, field, tile_front_1)
                local shadowr1 = create_effect(facing, HATMAN_TEXTURE, HATMAN_ANIMPATH, "SHADOWR", 0, 0, false, -4, field, tile_front_1)
                local armr2 = create_effect(facing, HATMAN_TEXTURE, HATMAN_ANIMPATH, "ROSE", 0, (20*2)*(-1), false, -4, field, tile_front_2)
                local shadowr2 = create_effect(facing, HATMAN_TEXTURE, HATMAN_ANIMPATH, "SHADOWR", 0, 0, false, -4, field, tile_front_2)
                local armr3 = create_effect(facing, HATMAN_TEXTURE, HATMAN_ANIMPATH, "ROSE", 0, (20*2)*(-1), false, -4, field, tile_front_3)
                local shadowr3 = create_effect(facing, HATMAN_TEXTURE, HATMAN_ANIMPATH, "SHADOWR", 0, 0, false, -4, field, tile_front_3)
                armr1:get_animation():set_playback_speed(2)
                shadowr1:get_animation():set_playback_speed(2)
                armr2:get_animation():set_playback_speed(2)
                shadowr2:get_animation():set_playback_speed(2)
                armr3:get_animation():set_playback_speed(2)
                shadowr3:get_animation():set_playback_speed(2)
                armr1:get_animation():on_frame(8, function()
                    Engine.play_audio(AUDIO_ROSE, AudioPriority.Low)
                    create_rose(user, props, team, facing, field, tile_front_1:get_tile(facing, 1))
                end)
                armr2:get_animation():on_frame(8, function()
                    Engine.play_audio(AUDIO_ROSE, AudioPriority.Low)
                    create_rose(user, props, team, facing, field, tile_front_2:get_tile(facing, 1))
                end)
                armr3:get_animation():on_frame(8, function()
                    Engine.play_audio(AUDIO_ROSE, AudioPriority.Low)
                    create_rose(user, props, team, facing, field, tile_front_3:get_tile(facing, 1))
                end)
		    end)
            navi_anim:on_frame(6, function()
		    	--Swords
                if targeted1 then
                    local arms1 = create_effect(facing, HATMAN_TEXTURE, HATMAN_ANIMPATH, "SWORD", 0, (20*2)*(-1), false, -4, field, tile_array1[1]:get_tile(Direction.reverse(facing), 1))
                    local shadows1 = create_effect(facing, HATMAN_TEXTURE, HATMAN_ANIMPATH, "SHADOWS", 0, 0, false, -4, field, tile_array1[1]:get_tile(Direction.reverse(facing), 1))
                    arms1:get_animation():set_playback_speed(2)
                    shadows1:get_animation():set_playback_speed(2)
                    arms1:get_animation():on_frame(9, function()
                        Engine.play_audio(AUDIO_SLASH, AudioPriority.Low)
                        create_effect(facing, SLASH_TEXTURE, SLASH_ANIMPATH, "WIDE", 0, 0, false, -9, field, tile_array1[1])
                        create_attack(user, props, team, facing, field, tile_array1[1])
                        create_attack(user, props, team, facing, field, tile_array1[1]:get_tile(Direction.Up, 1))
                        create_attack(user, props, team, facing, field, tile_array1[1]:get_tile(Direction.Down, 1))
                    end)
                end
                if targeted2 then
                    local arms2 = create_effect(facing, HATMAN_TEXTURE, HATMAN_ANIMPATH, "SWORD", 0, (20*2)*(-1), false, -4, field, tile_array2[1]:get_tile(Direction.reverse(facing), 1))
                    local shadows2 = create_effect(facing, HATMAN_TEXTURE, HATMAN_ANIMPATH, "SHADOWS", 0, 0, false, -4, field, tile_array2[1]:get_tile(Direction.reverse(facing), 1))
                    arms2:get_animation():set_playback_speed(2)
                    shadows2:get_animation():set_playback_speed(2)
                    arms2:get_animation():on_frame(9, function()
                        Engine.play_audio(AUDIO_SLASH, AudioPriority.Low)
                        create_effect(facing, SLASH_TEXTURE, SLASH_ANIMPATH, "WIDE", 0, 0, false, -9, field, tile_array2[1])
                        create_attack(user, props, team, facing, field, tile_array2[1])
                        create_attack(user, props, team, facing, field, tile_array2[1]:get_tile(Direction.Up, 1))
                        create_attack(user, props, team, facing, field, tile_array2[1]:get_tile(Direction.Down, 1))
                    end)
                end
                if targeted3 then
                    local arms3 = create_effect(facing, HATMAN_TEXTURE, HATMAN_ANIMPATH, "SWORD", 0, (20*2)*(-1), false, -4, field, tile_array3[1]:get_tile(Direction.reverse(facing), 1))
                    local shadows3 = create_effect(facing, HATMAN_TEXTURE, HATMAN_ANIMPATH, "SHADOWS", 0, 0, false, -4, field, tile_array3[1]:get_tile(Direction.reverse(facing), 1))
                    arms3:get_animation():set_playback_speed(2)
                    shadows3:get_animation():set_playback_speed(2)
                    arms3:get_animation():on_frame(9, function()
                        Engine.play_audio(AUDIO_SLASH, AudioPriority.Low)
                        create_effect(facing, SLASH_TEXTURE, SLASH_ANIMPATH, "WIDE", 0, 0, false, -9, field, tile_array3[1])
                        create_attack(user, props, team, facing, field, tile_array3[1])
                        create_attack(user, props, team, facing, field, tile_array3[1]:get_tile(Direction.Up, 1))
                        create_attack(user, props, team, facing, field, tile_array3[1]:get_tile(Direction.Down, 1))
                    end)
                end
		    end)
            navi_anim:on_complete(function()
                navi:delete()
            end)
            navi.delete_func = function(self)
                actor:get_animation():set_playback_speed(1)
                should_end = true
            end
            field:spawn(navi, self_tile)
        end)
        action:add_anim_action(4, function()
            actor:reveal()
        end)
    end
    action.action_end_func = function(self)
        actor:reveal()
	end
	return action
end

function create_rose(user, props, team, facing, field, tile)
    local spell = Battle.Spell.new(team)
    spell:set_facing(facing)
    spell:highlight_tile(Highlight.Solid)
    spell:set_offset(0, ((-8)+(20*2)*(-1)))
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            props.element,
            user:get_id(),
            Drag.None
        )
    )
    spell.slide_started = false
    local sprite = spell:sprite()
    sprite:set_texture(ROSE_TEXTURE, true)
	sprite:set_layer(-3)
    local anim = spell:get_animation()
	anim:load(ROSE_ANIMPATH)
	anim:set_state("0")

    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
        if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then
                self:delete()
            end 

            local dest = self:get_tile(facing, 1)
            local ref = self
            self:slide(dest, frames(6), frames(0), ActionOrder.Voluntary, function()
                ref.slide_started = true 
            end)
        end
    end

    spell.attack_func = function(self, ent)
		if Battle.Obstacle.from(ent) == nil then
			if Battle.Player.from(user) ~= nil then
				Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
			end
		else
			Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		end
	end

	spell.can_move_to_func = function(self, other)
		return true
	end

    spell.collision_func = function(self)
		self:delete()
	end

	spell.battle_end_func = function(self)
		self:delete()
	end

    spell.delete_func = function(self)
        if self:get_current_tile() ~= nil then
            --print("Rose deleted at tile: ("..self:get_current_tile():x()..";"..self:get_current_tile():x()..")")
        end
		self:erase()
	end

    field:spawn(spell, tile)

    --print("Rose spawned at tile: ("..tile:x()..";"..tile:y()..")")

	return spell
end

function create_attack(user, props, team, facing, field, tile)
    local spell = Battle.Spell.new(team)
    spell:set_facing(facing)
    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flinch | Hit.Flash, 
            props.element, 
            user:get_id(), 
            Drag.None
        )
    )
    local anim = spell:get_animation()
    anim:load(_folderpath.."attack.animation")
    anim:set_state("0")
    anim:on_complete(function()
        spell:delete()
    end)

    spell.update_func = function(self)
        self:get_current_tile():attack_entities(self)
    end

    spell.attack_func = function(self, ent)
		if Battle.Obstacle.from(ent) == nil then
			if Battle.Player.from(user) ~= nil then
				Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
			end
		else
			Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		end
	end

    spell.delete_func = function(self)
        self:erase()
    end

    field:spawn(spell, tile)

    return spell
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, flip, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    hitfx:never_flip(flip)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end

return hatman