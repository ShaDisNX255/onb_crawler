local hougan = include("hougan/hougan.lua")

local DAMAGE = 140

hougan.type = 3

hougan.codes = {"E","H","U"}
hougan.shortname = "LavaBall"
hougan.damage = DAMAGE
hougan.time_freeze = false
hougan.element = Element.Fire
hougan.description = "Turns 3rd panel to magma"
hougan.long_description = "Throws a CannonBall 3 squares ahead! Turns panel into magma!"
hougan.can_boost = true
hougan.card_class = CardClass.Standard
hougan.limit = 4
hougan.mb = 31

function package_init(package)
    package:declare_package_id("com.OFC.card.EXEPoN-029-YouganHougan")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes(hougan.codes)

    local props = package:get_card_props()
    props.shortname = hougan.shortname
    props.damage = hougan.damage
    props.time_freeze = hougan.time_freeze
    props.element = hougan.element
    props.description = hougan.description
    props.long_description = hougan.long_description
    props.can_boost = hougan.can_boost
	props.card_class = hougan.card_class
	props.limit = hougan.limit
end

card_create_action = hougan.card_create_action