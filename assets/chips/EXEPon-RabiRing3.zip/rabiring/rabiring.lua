local DAMAGE = 20

local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."EXE4_270.ogg")
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."EXE4_221.ogg")
local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."effect.png")
local EFFECT_ANIMPATH = _folderpath.."effect.animation"

local BUSTER_TEXTURE = Engine.load_texture(_folderpath.."buster.png")
local BUSTER_ANIMPATH = _folderpath.."buster.animation"
local RABIRING_TEXTURE = Engine.load_texture(_folderpath.."rabiring.png")
local RABIRING_ANIMPATH = _folderpath.."rabiring.animation"
local RABIRING_AUDIO = Engine.load_audio(_folderpath.."EXE3_155.ogg")

local rabiring = {
    frames = 4,

    codes = {"A","Q","S","*"},
    shortname = "RabiRng1",
    damage = DAMAGE,
    time_freeze = false,
    element = Element.Elec,
    description = "Pralyzing electric ring atk!",
    long_description = "An electric ring attack! Paralyzes opponent for a while!",
    can_boost = true,
    card_class = CardClass.Standard,
    limit = 4,
    mb = 10
}

rabiring.card_create_action = function(actor, props)
    print("in card_create_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
	action:set_lockout(make_animation_lockout())
    local override_frames = {{1, 0.017},{1, 0.333}}
    local frame_data = make_frame_data(override_frames)
    action:override_animation_frames(frame_data)
	local original_offset = actor:get_offset()
    action.execute_func = function(self, user)
		print("in custom card action execute_func()!")
        local facing = user:get_facing()
        local field = user:get_field()
        local team = user:get_team()

        local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(BUSTER_TEXTURE, true)
		buster:sprite():set_layer(-2)
		
		local buster_anim = buster:get_animation()
		buster_anim:load(BUSTER_ANIMPATH)
		buster_anim:set_state("0")
		self:add_anim_action(2, function()
            create_ring(user, props, team, facing, rabiring.frames, field, user:get_tile(facing, 1))
        end)

        actor:set_offset(original_offset.x, original_offset.y)
	end
    action.action_end_func = function(self, user)
		print("in custom card action action_end_func()!")
		actor:set_offset(original_offset.x, original_offset.y)
	end
    return action
end

function create_ring(user, props, team, facing, frames_count, field, tile)
    local spell = Battle.Spell.new(team)
	spell:set_offset(0.0, -16.0)
    spell.slide_started = false
    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Stun, 
            props.element,
            user:get_id(),
            Drag.None
        )
    )
    local sprite = spell:sprite()
    sprite:set_texture(RABIRING_TEXTURE, true)
    sprite:set_layer(-3)
    local anim = spell:get_animation()
    anim:load(RABIRING_ANIMPATH)
    anim:set_state("0")
    anim:refresh(sprite)

    spell.update_func = function(self) 
        self:get_current_tile():attack_entities(self)
        if self:is_sliding() == false then 
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end
            local dest = self:get_tile(facing, 1)
            local ref = self
            self:slide(dest, frames(frames_count), frames(0), ActionOrder.Voluntary, function()
                ref.slide_started = true 
            end)
        end
    end

    spell.attack_func = function(self, ent)
        create_effect(facing, EFFECT_TEXTURE, EFFECT_ANIMPATH, "4", math.random(-30,30), math.random(-50,30), true, -999999, field, ent:get_current_tile())
        if Battle.Obstacle.from(ent) == nil then
            if Battle.Player.from(user) ~= nil then
                Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
            end
        else
            Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
        end
    end
	
	spell.collision_func = function(self)
		self:delete()
	end

    spell.can_move_to_func = function(tile)
        return true
    end

    spell.delete_func = function(self)
        self:erase()
    end

	Engine.play_audio(RABIRING_AUDIO, AudioPriority.Low)

    field:spawn(spell, tile)

    return spell
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, flip, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    hitfx:never_flip(flip)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end

return rabiring