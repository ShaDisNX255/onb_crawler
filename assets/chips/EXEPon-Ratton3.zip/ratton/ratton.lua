local DAMAGE = 60

local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."EXE4_270.ogg")
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."EXE4_221.ogg")
local MOB_MOVE_TEXTURE = Engine.load_texture(_folderpath.."mob_move.png")
local MOB_MOVE_ANIMPATH = _folderpath.."mob_move.animation"
local TESTDOT_TEXTURE = Engine.load_texture(_folderpath.."testdot.png")
local TESTDOT_ANIMPATH = _folderpath.."testdot.animation"

local RATTON_TEXTURE = Engine.load_texture(_folderpath.."ratton.png")
local RATTON_ANIMPATH = _folderpath.."ratton.animation"
local RATTON_AUDIO = Engine.load_audio(_folderpath.."EXE4_6.ogg")
local BOOM_TEXTURE = Engine.load_texture(_folderpath.."boom.png")
local BOOM_ANIMPATH = _folderpath.."boom.animation"
local BOOM_AUDIO = Engine.load_audio(_folderpath.."EXE4_273.ogg")

local ratton = {
    palette = "palette1.png",

    codes = {"A","C","H","*"},
    shortname = "Ratton1",
    damage = DAMAGE,
    time_freeze = false,
    element = Element.None,
    description = "Rat moves & turns once",
    long_description = "A rat missile moves along the ground and can only turn once",
    can_boost = true,
    card_class = CardClass.Standard,
    limit = 4,
    mb = 18
}

ratton.card_create_action = function(actor, props)
    print("in card_create_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_THROW")
	local original_offset = actor:get_offset()
    local override_frames = {
        {1,0.050},{2,0.050},{3,0.050},{4,0.250},{5,0.050}
    }
    local frame_data = make_frame_data(override_frames)
	action:override_animation_frames(frame_data)
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        local actor = self:get_actor()
        local facing = user:get_facing()
        local field = user:get_field()
        local team = user:get_team()
        local self_tile = user:get_current_tile()

        self:add_anim_action(4, function()
            local tile = self_tile:get_tile(facing, 1)
            create_ratton(user, props, team, facing, field, tile)
            Engine.play_audio(RATTON_AUDIO, AudioPriority.Low)
        end)

        actor:set_offset(original_offset.x, original_offset.y)
    end
    action.action_end_func = function(self, user)
		print("in custom card action action_end_func()!")
        actor:reveal()
		actor:set_offset(original_offset.x, original_offset.y)
    end
    return action
end

function create_ratton(user, props, team, facing, field, tile)
    local spawn_next
    spawn_next = function()
        if not tile:is_walkable() then return end

	    local spell = Battle.Spell.new(team)
	    spell:set_hit_props(
            HitProps.new(
                props.damage,
                Hit.Impact | Hit.Flinch | Hit.Flash, 
                props.element,
                user:get_id(), 
                Drag.None
            )
        )
	    spell:set_facing(facing)
        spell:set_palette(Engine.load_texture(_folderpath..ratton.palette))
        spell.slide_started = false
	    local sprite = spell:sprite()
        sprite:set_texture(RATTON_TEXTURE, true)
	    sprite:set_layer(-3)
        local anim = spell:get_animation()
	    anim:load(RATTON_ANIMPATH)
        anim:set_state("0")
        anim:refresh(sprite)

        local speed = 8
        local cur_facing = facing
        local targetedU = false
        local targetedD = false
        local checkC = false
        local checkU1 = false
        local checkU2 = false
        local checkD1 = false
        local checkD2 = false
        local checkTHP = function(ent)
            if not user:is_team(ent:get_team()) and ent:get_health() > 0 then
                return true
            end
        end

        spell.on_spawn_func = function(self)
            self:highlight_tile(Highlight.Solid)
        end
	    spell.update_func = function(self)
            self:get_current_tile():attack_entities(self)
            if self:is_sliding() == false then
                local dest = self:get_tile(facing, 1)
                if not self:get_current_tile():is_walkable() and self.slide_started then
                    self:delete()
                end
                
                local destU1 = self:get_tile(Direction.Up, 1)
                local destU2 = self:get_tile(Direction.Up, 2)
                local destD1 = self:get_tile(Direction.Down, 1)
                local destD2 = self:get_tile(Direction.Down, 2)
                local ref = self
                if not targetedU and not targetedD then
                    if tile:y() == 1 then
                        local tileD1 = self:get_tile(Direction.Down, 1)
                        local tileD2 = self:get_tile(Direction.Down, 2)
                        checkD1 = #tileD1:find_characters(checkTHP) > 0
                        checkD2 = #tileD2:find_characters(checkTHP) > 0
                        if checkD1 or checkD2 then
                            targetedD = true
                        end
                    elseif tile:y() == 2 then
                        local tileC = self:get_current_tile()
                        local tileU1 = self:get_tile(Direction.Up, 1)
                        local tileD1 = self:get_tile(Direction.Down, 1)
                        checkC = #tileC:find_characters(checkTHP) > 0
                        checkU1 = #tileU1:find_characters(checkTHP) > 0
                        checkD1 = #tileD1:find_characters(checkTHP) > 0
                        if checkC then
                            targetedU = true
                            targetedD = true
                        end
                        if checkU1 then
                            targetedU = true
                        end
                        if checkD1 then
                            targetedD = true
                        end
                    elseif tile:y() == 3 then
                        local tileU1 = self:get_tile(Direction.Up, 1)
                        local tileU2 = self:get_tile(Direction.Up, 2)
                        checkU1 = #tileU1:find_characters(checkTHP) > 0
                        checkU2 = #tileU2:find_characters(checkTHP) > 0
                        if checkU1 or checkU2 then
                            targetedU = true
                        end
                    end
                end
                if targetedU and not targetedD then
                    dest = self:get_tile(Direction.Up, 1)
                    speed = 7
                    cur_facing = Direction.Up
                elseif not targetedU and targetedD then
                    dest = self:get_tile(Direction.Down, 1)
                    speed = 7
                    cur_facing = Direction.Down
                elseif targetedU and targetedD then
                    dest = self:get_tile(Direction.Down, 1)
                    speed = 7
                    cur_facing = Direction.Down
                end
                self:slide(dest, frames(speed), frames(0), ActionOrder.Voluntary, function()
                    ref.slide_started = true
                end)
            end
        end
	    spell.collision_func = function(self, ent)
            local offset1 = 32
            local offset2 = 12
            local offset_x = nil
            local offset_y = nil
            if      cur_facing == Direction.Up then
                offset_x = 0
                offset_y = offset2 * 1
            elseif  cur_facing == Direction.Down then
                offset_x = 0
                offset_y = offset2 * -1
            elseif  cur_facing == Direction.Left then
                offset_x = offset1 * 1
                offset_y = 0
            elseif  cur_facing == Direction.Right then
                offset_x = offset1 * -1
                offset_y = 0
            end
            create_effect(facing, BOOM_TEXTURE, BOOM_ANIMPATH, "0", offset_x, offset_y, true, -999999, field, ent:get_current_tile())
            Engine.play_audio(BOOM_AUDIO, AudioPriority.Low)
            if Battle.Obstacle.from(ent) == nil then
                if Battle.Player.from(user) ~= nil then
                    Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
                end
            else
                Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
            end
            self:delete()
	    end
        spell.attack_func = function(self, ent)
            --
        end
	    spell.battle_end_func = function(self)
            create_effect(facing, BOOM_TEXTURE, BOOM_ANIMPATH, "0", 0, 0, true, -999999, field, ent:get_current_tile())
            Engine.play_audio(BOOM_AUDIO, AudioPriority.Low)
	    	self:delete()
	    end
	    spell.can_move_to_func = function(tile)
            return true
        end
        spell.delete_func = function(self)
            if not self:get_current_tile():is_walkable() then
                create_effect(facing, MOB_MOVE_TEXTURE, MOB_MOVE_ANIMPATH, "4", 0, 0, true, -9, field, self:get_current_tile())
            end
	    	self:erase()
        end
	    field:spawn(spell, tile)
    end
    spawn_next()
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, flip, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    hitfx:never_flip(flip)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end

return ratton