local satellite = include("satellite/satellite.lua")

local DAMAGE = 120

satellite.path = "battle_v3.palette.png"
satellite.shake_speed = 28

satellite.codes = {"H","Q","S"}
satellite.shortname = "Satelit3"
satellite.damage = DAMAGE
satellite.time_freeze = false
satellite.element = Element.Elec
satellite.description = "Wavering satellite hits foe"
satellite.long_description = "Wavering satellite deals Elec damage to an enemy"
satellite.can_boost = true
satellite.card_class = CardClass.Standard
satellite.limit = 4
satellite.mb = 45

function package_init(package)
    package:declare_package_id("com.OFC.card.EXEPoN-074-Satellite3")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes(satellite.codes)

    local props = package:get_card_props()
    props.shortname = satellite.shortname
    props.damage = satellite.damage
    props.time_freeze = satellite.time_freeze
    props.element = satellite.element
    props.description = satellite.description
    props.long_description = satellite.long_description
    props.can_boost = satellite.can_boost
	props.card_class = satellite.card_class
	props.limit = satellite.limit
end

card_create_action = satellite.card_create_action