local DAMAGE = 60

local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."EXE4_270.ogg")
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."EXE4_221.ogg")
local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."effect.png")
local EFFECT_ANIMPATH = _folderpath.."effect.animation"

local attack_sprite = Engine.load_texture(_folderpath.."satellite.grayscaled.png")
local attack_anim = _folderpath.."satellite.animation"
local AUDIO_SHOOT = Engine.load_audio(_folderpath.."EXE4_72.ogg")

local satellite = {
    path = "battle_v1.palette.png",
    shake_speed = 48,

    codes = {"D","J","N","*"},
    shortname = "Satelit1",
    damage = DAMAGE,
    time_freeze = false,
    element = Element.Elec,
    description = "Wavering satellite hits foe",
    long_description = "Wavering satellite deals Elec damage to an enemy",
    can_boost = true,
    card_class = CardClass.Standard,
    limit = 4,
    mb = 25,
}

satellite.card_create_action = function(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_SWORD")
    local frame_data = make_frame_data({
        {1, 0.033}, {2, 0.033}, {3, 0.033}, {4, 0.416}
    })
    action:override_animation_frames(frame_data)
    action:set_lockout(make_animation_lockout())
    --local frame1 = { 1, 0.033 }
    --local frame2 = { 1, 0.305 }
    --action.frames = { frame1, frame1, frame1, frame2 }
    --local frame_data = make_frame_data(action.frames)
    --action:override_animation_frames(frame_data)
    action.execute_func = function(self, user)
        print("in custom card action execute_func()!")
        local facing = user:get_facing()
        local field = user:get_field()
        local team = user:get_team()

        self:add_anim_action(2, function()
			local hilt = self:add_attachment("HILT")
			local hilt_sprite = hilt:sprite()
			hilt_sprite:set_texture(actor:get_texture())
			hilt_sprite:set_layer(-2)
			hilt_sprite:enable_parent_shader(true)
			local hilt_anim = hilt:get_animation()
			hilt_anim:copy_from(actor:get_animation())
			hilt_anim:set_state("HAND")
			hilt_anim:refresh(hilt_sprite)
		end)

        self:add_anim_action(3, function()
            local tile = user:get_tile(facing, 1)
            create_satellite(user, props, team, facing, field, tile)
        end)
    end
    action.action_end_func = function()
    end
    return action
end

---@param user Entity The user summoning a spell
---@param damage number The amount of damage the spell will do
---@param speed number The number of frames it takes the spell to travel 1 tile.
---@param direction any The direction the
function create_satellite(user, props, team, facing, field, start_tile)
    local tile = field:tile_at(start_tile:x(), 2)
    -- Creates a new spell that belongs to the user's team.
    local spell = Battle.Obstacle.new(team)
    spell:set_facing(facing)
    --spell:set_health(damage)
    spell:set_palette(Engine.load_texture(_folderpath..satellite.path))
    --Set the hit properties of this spell.
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Stun,
            props.element,
            user:get_id(),
            Drag.None
        )
    )
    spell.base_tile = tile
    spell.moving = false
    spell.idle_timer = 10
    spell.act_timer = true
    -- Setup sprite of the spell
    local sprite = spell:sprite()
    sprite:set_texture(attack_sprite)
    sprite:set_layer(-1)
    -- Setup animation of the spell
    local anim = spell:get_animation()
    anim:load(attack_anim)
    anim:set_state("0")
    anim:set_playback(Playback.Loop)
    anim:refresh(sprite)
    local round = function(val)
        if facing == Direction.Right then
            return math.floor(val)
        else
            return math.ceil(val)
        end
    end

    --54: spshake1
    --38: spshake2/BN6ver
    --28: spshake3

    local pi = math.pi
    tileWidth = tile:width()
    tileHeight = tile:height()

    local x_speed = tileWidth / satellite.shake_speed
    if (facing == Direction.Left) then
        x_speed = -x_speed
    end
    spell.x_coord = 0
    spell.time = 0
    --local start_y = user:get_tile():y()
    local start_y = tile:y()
    local tileOffsetY = 0
    spell.update_func = function(self, dt)
        spell:get_current_tile():attack_entities(self)
        spell:get_current_tile():highlight(Highlight.Solid)
        if spell.act_timer then
            if spell.idle_timer > 0 then
                spell.idle_timer = spell.idle_timer - 1
            else
                Engine.play_audio(AUDIO_SHOOT, AudioPriority.Low)
                spell:teleport(tile, ActionOrder.Immediate, function()
                    spell.moving = true
                end)
                spell.act_timer = false
            end
        end

        if spell.moving then
            spell.x_coord = spell.x_coord + x_speed
            spell.y_coord = -round(math.sin((pi * spell.time) / (satellite.shake_speed)) * tileHeight)
            -- Once shakey has moved half a tile, needs to change its tile
            if (spell.y_coord > tileHeight / 2) then
                --in bottom tile
                tileOffsetY = 1
            elseif (spell.y_coord < -tileHeight / 2) then
                --in top tile
                tileOffsetY = -1
            else
                -- same row
                tileOffsetY = 0
            end
            local prospective_y = tileOffsetY + start_y
            if (spell:get_current_tile():y() ~= prospective_y) then
                --check if tile should be updated
                spell:teleport(field:tile_at(spell:get_current_tile():x(), prospective_y))
            end
            if (spell:get_facing() == Direction.Right and round(spell.x_coord) >= tileWidth / 2) then
                spell:teleport(spell:get_tile(Direction.Right, 1), ActionOrder.Immediate)
                spell.x_coord = -tileWidth / 2
            elseif (spell:get_facing() == Direction.Left and round(spell.x_coord) <= -tileWidth / 2) then
                spell:teleport(spell:get_tile(Direction.Left, 1), ActionOrder.Immediate)
                spell.x_coord = tileWidth / 2
            end
            --Teleporting increases the offsetY.
            local relativeOffsetY = (tileOffsetY * (tileHeight * 0.8))
            local adjusted_y = spell.y_coord - relativeOffsetY
            spell:set_offset(spell.x_coord, adjusted_y)
            spell.time = spell.time + 1
            if (spell.time == satellite.shake_speed * 2) then
                spell.time = 0
            end
            if (spell:get_current_tile():x() > 6 or spell:get_current_tile():x() < 1) then
                spell:delete()
            end
        end
    end
    spell.attack_func = function(self, ent)
        create_effect(facing, EFFECT_TEXTURE, EFFECT_ANIMPATH, "4", math.random(-30,30), math.random(-50,-30), true, -999999, field, ent:get_current_tile())
        if Battle.Obstacle.from(ent) == nil then
			if Battle.Player.from(user) ~= nil then
				Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
			end
		else
			Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		end
    end
    spell.collision_func = function(self)
        self:delete()
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    spell.battle_end_func = function(self)
        self:delete()
    end
    spell.delete_func = function(self)
        self:erase()
    end
    field:spawn(spell, start_tile)
    return spell
end

--- create hit effect.
function create_hit_effect(field, tile, hit_texture, hit_anim_path, hit_anim_state, sfx)
    local hitfx = Battle.Artifact.new()
    hitfx:set_texture(hit_texture, true)
    hitfx:set_offset(math.random(-25, 25), math.random(-25, 25))
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-3)
    local hitfx_anim = hitfx:get_animation()
    hitfx_anim:load(hit_anim_path)
    hitfx_anim:set_state(hit_anim_state)
    hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_frame(1, function()
        Engine.play_audio(sfx, AudioPriority.Highest)
    end)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)
    return hitfx
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, flip, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    hitfx:never_flip(flip)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end

return satellite