local vulcan = include("vulcan/vulcan.lua")

local DAMAGE = 10

vulcan.shots_animated = 9
vulcan.hits = 5

vulcan.codes = {"B","H","O"}
vulcan.shortname = "Vulcan2"
vulcan.damage = DAMAGE
vulcan.time_freeze = false
vulcan.element = Element.None
vulcan.description = "5-shot to pierce 1 panel!"
vulcan.long_description = "5-shot Vulcan hits pierce 1 square back!"
vulcan.can_boost = true
vulcan.card_class = CardClass.Standard
vulcan.limit = 4
vulcan.mb = 18

function package_init(package) 
    package:declare_package_id("com.OFC.card.EXEPoN-005-Vulcan2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(vulcan.codes)

    local props = package:get_card_props()
    props.shortname = vulcan.shortname
    props.damage = vulcan.damage
    props.time_freeze = vulcan.time_freeze
    props.element = vulcan.element
    props.description = vulcan.description
    props.long_description = vulcan.long_description
    props.can_boost = vulcan.can_boost
	props.card_class = vulcan.card_class
	props.limit = vulcan.limit
end

card_create_action = vulcan.card_create_action