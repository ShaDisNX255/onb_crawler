--[[

    The 75 frames delay is added when:
    1. The battle starts.
    2. The Cannodumb has attacked.
    CUSTOM BEHAVIOR:
    if Confused or Blind, it can't see the player.

]]
local is_counterable = true
local print_debug = false

local CHARACTER_TEXTURE = Engine.load_texture(_folderpath.."gfx/battle.grayscaled.png")
local CHARACTER_ANIMPATH = _folderpath.."gfx/battle.animation"

local CURSOR_TEXTURE = Engine.load_texture(_folderpath.."gfx/cursor.grayscaled.png")
local CURSOR_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/cursor.png")
local CURSOR_ANIMPATH = _folderpath.."gfx/cursor.animation"

local BOOM_TEXTURE = Engine.load_texture(_folderpath.."gfx/boom.grayscaled.png")
local BOOM_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/boom.png")
local BOOM_ANIMPATH = _folderpath.."gfx/boom.animation"

local CANNON_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE3_117.ogg", true)

function debug_print(id,str)
    if print_debug then
        print("[Cannodumb] (ID: "..id:get_id()..") "..str)
    end
end

--possible states for character
local states = { IDLE = 1, SEEK = 2, ATTACK = 3, DELAY = 4 }

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or Playback.Once
    facing = facing or user:get_facing()
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and facing == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function create_shot(user, damage, facing, field, team)
    local tile = user:get_tile(facing,1)
    if not tile then return end
    local spell = Battle.Spell.new(team)
    spell:set_facing(facing)
    spell:set_hit_props(
        HitProps.new()
        :dmg(damage)
        :impact()
        :flinch()
        :flash()
        :no_counter()
        :from(user:get_context())
    )
    spell.update_func = function(self)
        self:get_tile():attack_entities(self)
        if not self:is_sliding() then
            local tile = self:get_tile(facing,1)
            if not tile then
                self:delete()
            else
                self:slide(tile, frames(1), frames(0), ActionOrder.Immediate)
            end
        end
    end
    spell.attack_func = function(self, other, judge)
        if not judge:hint_spawn_gfx() then return end
        local offset_y = math.random(-30,-20)
        local offset_x = math.random(-10,5)
        if facing == Direction.Left then offset_x = -offset_x end
        local hit_fx = graphic_init("artifact", (offset_x*2), 0, BOOM_TEXTURE, BOOM_PALETTE, BOOM_ANIMPATH, -999, "0", Playback.Once, user, facing, true, false, true)
        hit_fx:set_elevation(-(offset_y*2))
        field:spawn(hit_fx,other:get_tile())
    end
    spell.collision_func = function(self)
        self:delete()
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    spell.battle_end_func = function(self)
        self:delete()
    end
    spell.delete_func = function(self)
        self:erase()
    end
    field:spawn(spell, tile)
    return spell
end

local function create_cursor(user, speed, facing, field, team)
    local tile = user:get_tile(facing,1)
    if not tile or tile:is_edge() then return end
    local spell = graphic_init("spell", 0, 0, CURSOR_TEXTURE, CURSOR_PALETTE, CURSOR_ANIMPATH, -3, "0", Playback.Once, user, facing)
    spell:set_hit_props(
        HitProps.new()
        :dmg(0)
        :no_counter()
        :from(user:get_context())
    )
    spell.state = "SEARCHING"
    spell.frames = 1
    spell.first_move = true
    spell.update_func = function(self)
        if self:get_tile():is_edge() then self:delete() return end
        if self.state == "SEARCHING" then
            self:get_tile():attack_entities(self)
            -- For some reason, the cursor does its first teleport 1 frame earlier that it should.
            if (self.first_move and self.frames >= speed-1) or (not self.first_move and self.frames >= speed) then
                if self.first_move then self.first_move = false end
                local t = self:get_tile(facing,1)
                self:teleport(t,ActionOrder.Voluntary)
                self.frames = 1
                return
            end
        else
            if math.ceil(self.frames/2)%2~=0 then
                self:sprite():set_color_mode(ColorMode.Additive)
                self:sprite():set_color(Color.new(255,255,255,255))
            end
            if self.frames >= 17 then
                user.set_state(states.ATTACK)
                self:delete()
                return
            end
        end
        self.frames = self.frames + 1
    end
    spell.collision_func = function(self)
        if self.state == "SEARCHING" then
            self.state = "ATTACKING"
            self.frames = 1
        end
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    spell.battle_end_func = function(self)
        self:delete()
    end
    spell.delete_func = function(self)
        self:erase()
    end
    field:spawn(spell, tile)
    return spell
end

function package_init(self, character_info)
    -- Required function, main package information
    self.texture = CHARACTER_TEXTURE
    self.anim = self:get_animation()
    self.anim:load(CHARACTER_ANIMPATH)
    -- Load extra resources
    -- Set up character meta
    -- Common Properties
    self:set_name(character_info.name)
    self:set_health(character_info.health)
    self:set_element(character_info.element)
    self:set_texture(self.texture, true)
    self:set_height(50)
    self:set_float_shoe(false)
    self:set_air_shoe(false)
    self:share_tile(false)
    self:set_explosion_behavior(2, 1, false)
    self:set_offset(0,0)
    self:store_base_palette(Engine.load_texture(_folderpath.."gfx/palette/battle-"..self:get_rank()..".png"))
    self:set_palette(self:get_base_palette())
    self.damage = character_info.damage
    -- Cannodumb Specific
    self.damage_cannon = character_info.damage_cannon
    self.cursor_speed = character_info.cursor_speed
    -- Other Setup
    self.collision_available = true
    -- entity will spawn with this animation.
    self.anim:set_state("PLAYER_IDLE")
    --self.anim:refresh(self:sprite())
    self.frame_counter = 0
    self.started = false
    self.is_deleting = false
    self.move_counter = 0
    -- This defense rule is added to prevent enemy from gaining invincibility after taking damage.
    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)
    self.defense_rule = Battle.DefenseRule.new(1, DefenseOrder.Always)
    local ref = self
    self.defense_rule.filter_statuses_func = function(statuses)
		statuses.flags = statuses.flags & ~Hit.Flinch
		statuses.flags = statuses.flags & ~Hit.Flash
		return statuses
	end
    self:add_defense_rule(self.defense_rule)
    self.reserving_obstacle = Battle.Obstacle.new(self:get_team())

    local ref = self
    self.counterable_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.counterable_component.timer = 0
    self.counterable_component.update_func = function(self)
        if self.timer > 0 and is_counterable then
            debug_print(ref,"COUNTERABLE")
            self.timer = self.timer - 1
            ref:toggle_counter(true)
        else
            ref:toggle_counter(false)
        end
    end
    self:register_component(self.counterable_component)
    self.hit_func = function(from_stun)
        debug_print(ref,"Hit func runs")
        self.counterable_component.timer = 0
        self:toggle_counter(false)
    end
    self.on_countered = function(self)
        debug_print(ref,"Countered")
        self.hit_func(true)
    end
    self:register_status_callback(Hit.Stun, function() self.hit_func(true) end)
    self:register_status_callback(Hit.Freeze, function() self.hit_func(true) end)

    self.slide_component = nil
    self.prev_tile = nil
    self.next_tile = nil

    self.can_move_to_func = function(tile)
        --if self:is_rooted() then return false end
        if tile:is_hole() then
            return false
        end
        if tile:get_team() ~= self:get_team() then
            return false
        end
        -- Can't move to reserved tiles.
        if(tile:is_reserved({self:get_id()})) then
            return false
        end
        if tile == self:get_tile() then
            return true
        end
        return not check_obstacles(tile) and not check_characters_true(tile)
    end

    -- Code that runs sometimes
    ---@param frame number
    self.action_delay = function(frame)
		if frame >= 75 then
            self.set_state(states.IDLE)
        end
    end
    -- Code that runs in the default state
    ---@param frame number
    self.action_idle = function(frame)
        local facing = self:get_facing()
        local field = self:get_field()
        if not self:is_confused() and not self:is_blind() then
            for i=1,field:width() do
                local t = self:get_tile(facing,i)
                if t and not t:is_edge() and check_characters(t,self) then
                    self.set_state(states.SEEK)
                    break
                end
            end
        end
    end
    --- Code that runs in the seek state.
    ---@param frame number
    self.action_seek = function(frame)
        local facing = self:get_facing()
        local field = self:get_field()
        local team = self:get_team()
        if frame == 33 then
            create_cursor(self, self.cursor_speed, facing, field, team)
        end
        if frame >= 57 then
            self.set_state(states.IDLE)
        end
    end
    --- Code that runs in the attack state.
    ---@param frame number
    self.action_attack = function(frame)
        local facing = self:get_facing()
        local field = self:get_field()
        local team = self:get_team()
        if frame == 1 then
            self.anim:set_state("ATTACKING")
        end
        if frame == 3 then
            Engine.play_audio(CANNON_AUDIO, AudioPriority.Immediate)
            self.counterable_component.timer = 20 -- Becomes counterable for 20 frames.
        end
        if frame == 4 then
            create_shot(self, self.damage_cannon, facing, field, team)
        end
        if frame >= 18 then
            self.set_state(states.DELAY)
        end
    end
    --utility to set the update state, and reset frame counter
    ---@param state number
    self.set_state = function(state)
        self.state = state
        self.frame_counter = 0
    end
    -- actions for states
    local actions = { [1] = self.action_idle, [2] = self.action_seek, [3] = self.action_attack, [4] = self.action_delay }
    self.on_spawn_func = function(self)
        debug_print(self,"on_spawn_func called")
        if character_info.name_on_spawn then
            self:set_name(character_info.name)
        end
    end
    self.battle_start_func = function()
        debug_print(self,"battle_start_func called")
    end
    self.delete_func = function()
        debug_print(self,"delete_func called")
        self.is_deleting = true
    end
    self.update_func = function()
        self.frame_counter = self.frame_counter + 1
        if not self.started then
            self.started = true
            self.set_state(states.DELAY)
        else
            local action_func = actions[self.state]
            action_func(self.frame_counter)
        end
        -- collision hitbox
        check_collision(self, self.damage)
    end
end

function choose_move(self)
    local tiles = {}
    for i=0,3 do
        local tile = self:get_tile(math.floor(2^i),1)
        if tile and self.can_move_to_func(tile) then
            table.insert(tiles, tile)
        end
    end
    --print("Found ", #tiles, " possible tiles")
    if #tiles == 0 then 
        return self:get_tile()
    end
    return tiles[math.random(1,#tiles)]
end

function choose_move_to_row(self, dest_y)
    local tile = self:get_tile()
    if (dest_y < tile:y()) then
        tile = tile:get_tile(Direction.Up,1)
    else
        tile = tile:get_tile(Direction.Down,1)
    end
    if not tile or not self.can_move_to_func(tile) or self:is_confused() or self:is_blind() then 
        return nil
    end
    return tile
end

function create_collision_attack(user, damage, tile)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(user:get_facing())
    spell:set_hit_props(
        HitProps.new()
        :dmg(damage)
        :impact()
        :flinch()
        :flash()
        :no_counter()
        :from(user:get_context())
        :elem(user:get_element())
    )
    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end
    user:get_field():spawn(spell, tile)
    return spell
end

function check_collision(user, damage)
    local t = user:get_tile()
    if user.collision_available and check_characters(t, user) then 
        create_collision_attack(user, damage, t)
    end
end

-- Checks for non-zero-health Obstacles.
function check_obstacles(tile)
    local ob = tile:find_obstacles(function(o)
        if o:get_animation():has_state("PASS_THROUGH") or o:get_name() == "CANTINTERACT" then
            return false
        else
            return true
        end
        return o:get_health() > 0
    end)
    return #ob > 0 
end

-- Checks for unfriendly Characters.
function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)
    return #characters > 0
end

-- Checks for any Characters.
function check_characters_true(tile)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0
    end)
    return #characters > 0
end

function check_characters_true_team(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_tile():get_team() == self:get_tile():get_team()
    end)
    return #characters > 0
end

return package_init