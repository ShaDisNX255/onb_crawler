local shared_package_init = include("../Cannodumb/character.lua")

function package_init(character)
    local character_info = {
        name = "Cannodumb",
        name_on_spawn = false,
        health = 60,
        damage = 10,
        element = Element.None,
        damage_cannon = 10,
        cursor_speed = 12,
    }
    if character:get_rank() == Rank.V2 then
        character_info.health = 90
        character_info.damage = 50
        character_info.damage_cannon = 50
        character_info.cursor_speed = 9
    elseif character:get_rank() == Rank.V3 then
        character_info.health = 130
        character_info.damage = 100
        character_info.damage_cannon = 100
        character_info.cursor_speed = 6
    elseif character:get_rank() == Rank.SP then
        character_info.health = 180
        character_info.damage = 200
        character_info.damage_cannon = 200
        character_info.cursor_speed = 3
    end
    shared_package_init(character,character_info) -- 75 sp 33 sp
end