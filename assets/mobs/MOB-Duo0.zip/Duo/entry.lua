--[[

    TODO: maybe make hand moving animation more accurate.

    Duo boss character from "Rockman EXE4: Tournament Red Sun/Tournament Blue Moon"
    Ported to Open Net Battle (ONB) by K1rbYat1Na

    Moves:
    Move -> Stomp
    Move -> Stomp -> Yura -> JusticeFist
    Move -> Stomp -> Yura -> Missile -> JusticeFist
    Move -> Stomp -> 3 Missiles -> GiantHook
    Move -> Stomp -> DestroyLaser -> GiantHook
    Move -> Stomp -> DestroyLaser -> JusticeFist

    HP > 50%
    3 Missiles
    1 Yura
    1 Missile + 1 Yura

    HP <= 50%
    1 Yura + 1 Missile + 1 Yura
    1 Missile + 1 Yura + 1 Missile
    1 Yura + 2 Missiles
    1 Missile + 2 Yuras

    When the core is closed, can't be targeted.

    Duo Yura
    "PASS_THROUGH"
    Can be destroyed by Duo's fists.

    Duo Missile
    "PASS_THROUGH"
    Can be destroyed by Duo's fists.

    Other versions increase:
    - Number of the rings created by Destroy Laser.
    - Delay between creating the rings of Destroy Laser.
    - Speed of Duo Yura.
]]
----

local print_debug = false -- Turns on/off the debug text.

local anim = nil
local dir = Direction.Up
local idleDuoPos  = {x=0, y=0, z=0}
local idleHandPos = {x=0, y=0, z=2*2}

local DUO_TEXTURE = Engine.load_texture(_folderpath.."gfx/duo.png")
local DUO_TEXTURE_SP = Engine.load_texture(_folderpath.."gfx/duo-sp.png")
local DUO_ANIMPATH = _folderpath.."gfx/duo.animation"
local DUOMISSILE_ANIMPATH = _folderpath.."gfx/duomissile.animation"
local DUOYURA_TEXTURE = Engine.load_texture(_folderpath.."gfx/duoyura.png")
local DUOYURA_ANIMPATH = _folderpath.."gfx/duoyura.animation"
local SHADOW_TEXTURE = Engine.load_texture(_folderpath.."gfx/shadow.png")

local FIST_IMPACT_TEXTURE = Engine.load_texture(_folderpath.."gfx/fist_impact.grayscaled.png")
local FIST_IMPACT_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/fist_impact.png")
local FIST_IMPACT_ANIMPATH = _folderpath.."gfx/fist_impact.animation"
local DESTROYLASER_TEXTURE = Engine.load_texture(_folderpath.."gfx/destroylaser.grayscaled.png")
local DESTROYLASER_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/destroylaser.png")
local DESTROYLASER_ANIMPATH = _folderpath.."gfx/destroylaser.animation"
local ANGERIMPACT_TEXTURE = Engine.load_texture(_folderpath.."gfx/angerimpact.grayscaled.png")
local ANGERIMPACT_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/angerimpact.png")
local ANGERIMPACT_ANIMPATH = _folderpath.."gfx/angerimpact.animation"

local MOB_MOVE_TEXTURE = Engine.load_texture(_folderpath.."gfx/mob_move.grayscaled.png")
local MOB_MOVE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/mob_move.png")
local MOB_MOVE_ANIMPATH = _folderpath.."gfx/mob_move.animation"
local SMOKE_TEXTURE = Engine.load_texture(_folderpath.."gfx/smoke.grayscaled.png")
local SMOKE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/smoke.png")
local SMOKE_ANIMPATH = _folderpath.."gfx/smoke.animation"

local SMOKE_TEXTURE = Engine.load_texture(_folderpath.."gfx/smoke.grayscaled.png")
local SMOKE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/smoke.png")
local SMOKE_ANIMPATH = _folderpath.."gfx/smoke.animation"

local BOOM1_TEXTURE = Engine.load_texture(_folderpath.."gfx/boom1.grayscaled.png")
local BOOM1_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/boom1.png")
local BOOM1_ANIMPATH = _folderpath.."gfx/boom1.animation"
local BOOM2_TEXTURE = Engine.load_texture(_folderpath.."gfx/boom2.grayscaled.png")
local BOOM2_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/boom2.png")
local BOOM2_ANIMPATH = _folderpath.."gfx/boom2.animation"
local BOOM_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_273.ogg", true)

local DUOMISSILE_AUDIO_SPAWN = Engine.load_audio(_folderpath.."sfx/EXE4_178.ogg", true)
local DUOMISSILE_AUDIO_SHOOT = Engine.load_audio(_folderpath.."sfx/EXE4_134.ogg", true)
local DUOYURA_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_73.ogg", true)

local DUOSTOMP_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_163.ogg", true)
local GIANTHOOK_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_105.ogg", true)
local JUSTICEFIST_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_311.ogg", true)
local DESTROYLASER_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_160.ogg", true)
local DESTROYCANNON_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_109.ogg", true)
local METEORKNUCKLE_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_212.ogg", true)
local ANGERIMPACT_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_294.ogg", true)

-- LIBRARIES --
local ObstacleInfo = include("ObstacleInfo.lua")
---------------

-- Prints the debug text.
local function debug_print(text)
    if print_debug then
        print("[Duo] "..text)
    end
end

local function shuffle(tbl)
    for i = #tbl, 2, -1 do
        local j = math.random(i)
        tbl[i], tbl[j] = tbl[j], tbl[i]
    end
    return tbl
end

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function create_anger_impact(user, tile_self, tile_anger)
    if not tile_anger or tile_anger:is_edge() then return end
    ----
    local function create_anger_impact_impact(user, knuckle, field, tile)
        if not tile or tile:is_edge() then return end
        local tileWidth = tile:width()/2
        local impact = graphic_init("artifact", tileWidth, 0, ANGERIMPACT_TEXTURE, ANGERIMPACT_PALETTE, ANGERIMPACT_ANIMPATH, -99, "ANGER_IMPACT1", Playback.Loop, knuckle, knuckle:get_facing(), false, true)
        impact.anim = impact:get_animation()
        impact.frames = 1
        impact.update_func = function(self)
            if user.deleting then
                self:delete()
                return
            end
            if self.frames == 7 then
                self:hide()
            end
            if self.frames == 8 then
                self:reveal()
                self.anim:set_state("ANGER_IMPACT2")
                self.anim:set_playback(Playback.Loop)
                self.anim:refresh(self:sprite())
            end
            if self.frames == 28 then
                self.anim:set_state("ANGER_IMPACT3")
                self.anim:refresh(self:sprite())
            end
            if self.frames == 32 then
                self:delete()
            end
            self.frames = self.frames + 1
        end
        impact.battle_end_func = function(self)
            self:delete()
        end
        impact.delete_func = function(self)
            self:erase()
        end
        field:spawn(impact, tile)
        return impact
    end
    ----
    local function create_anger_impact_hitbox(user, anger, field, tile1, tile2)
        if not tile1 or tile1:is_edge() then return end
        local spell = Battle.Spell.new(anger:get_team())
        spell:set_facing(anger:get_facing())
        spell:set_hit_props(
            HitProps.new()
            :dmg(user.damage_angerimpact)
            :impact()
            :flinch()
            :flash()
            :pierce()
            :retangible()
            :from(user:get_context())
        )
        spell.update_func = function(self)
            tile1:attack_entities(self)
            if tile2 then tile2:attack_entities(self) end
            self:delete()
        end
        spell.attack_func = function(self, other, judge)
            if not judge:hint_spawn_gfx() then return end
            local offset_y = math.random(-5,6)
            local offset_x = math.random(-6,5)
            local hit_fx = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT0_TEXTURE, EFFECT0_PALETTE, EFFECT0_ANIMPATH, -999, "0", Playback.Once, self, self:get_facing(), true, true, true)
            self:get_field():spawn(hit_fx, self:get_tile())
        end
        spell.battle_end_func = function(self)
            self:delete()
        end
        spell.delete_func = function(self)
            self:erase()
        end
        field:spawn(spell, tile1)
        return spell
    end
    ----
    local field = user:get_field()
    local anger = graphic_init("artifact", 16*2, 0, ANGERIMPACT_TEXTURE, ANGERIMPACT_PALETTE, ANGERIMPACT_ANIMPATH, -3, "ANGERIMPACT3", Playback.Loop, user, user:get_facing(), false, true)
    anger:set_elevation(-8*2)
    anger.frames = 1
    anger.do_once = true
    anger.on_spawn_func = function(self)
        local facing = self:get_facing()
        for i=0, 1 do
            for j=-1, 1 do
                local tile = field:tile_at(tile_anger:get_tile(facing,i):x(),tile_anger:y()+j)
                if not tile:is_hole() then
                    if self.do_once then
                        self.do_once = false
                        self:shake_camera(10, 0.333)
                    end
                end
                if not tile:is_cracked() and not tile:is_hole() then
                    Engine.play_audio(AudioType.PanelCrack, AudioPriority.Immediate)
                    tile:set_state(TileState.Cracked)
                end
            end
        end
        create_anger_impact_hitbox(user, self, field, tile_anger, tile_anger:get_tile(facing,1))
        create_anger_impact_impact(user, self, field, tile_anger)
    end
    anger.update_func = function(self)
        if user.deleting then
            self:delete()
            return
        end
        if self.frames == 41 then
            self:delete()
        end
        self.frames = self.frames + 1
    end
    anger.battle_end_func = function(self)
        self:delete()
    end
    anger.delete_func = function(self)
        self:erase()
    end
    field:spawn(anger, tile_anger)
    return anger
end

-- Creates Meteor Knuckle.
-- If stunned while highlighting tiles, gets deleted.
local function create_meteor_knuckle(user, tile, number)
    if not tile or tile:is_edge() then return end
    local function create_meteor_knuckle_hitbox(user, knuckle, field, tile)
        if not tile or tile:is_edge() then return end
        local spell = Battle.Spell.new(knuckle:get_team())
        spell:set_facing(knuckle:get_facing())
        spell:set_hit_props(
            HitProps.new()
            :dmg(user.damage_meteorknuckle)
            :impact()
            :flinch()
            :flash()
            :breaking()
            :pierce_ground()
            :retangible()
            :from(user:get_context())
        )
        spell.update_func = function(self)
            tile:attack_entities(self)
            self:delete()
        end
        spell.battle_end_func = function(self)
            self:delete()
        end
        spell.delete_func = function(self)
            self:erase()
        end
        field:spawn(spell, tile)
        return spell
    end
    local field = user:get_field()
    local state = "METEORKNUCKLE_L"
    if number%2==0 then
        state = "METEORKNUCKLE_R"
    end
    local knuckle = graphic_init("spell", -10*2*15, 0, user.texture, nil, DUO_ANIMPATH, -3, state, Playback.Once, user, user:get_facing(), false, true)
    knuckle:set_elevation(11*2*15)
    knuckle:hide()
    knuckle.frames = 1
    knuckle.state = "WAIT"
    knuckle.update_func = function(self)
        if user.deleting then
            self:delete()
            return
        end
        if self.state == "WAIT" then
            if user:is_stunned() then
                self:delete()
                return
            end
            tile:highlight(Highlight.Flash)
            if self.frames == 9 then
                self.state = "FALL"
                self.frames = 1
                Engine.play_audio(METEORKNUCKLE_AUDIO, AudioPriority.Immediate)
                knuckle:reveal()
            end
        end
        if self.state == "FALL" then
            if self:get_elevation() > 0 then
                if self:get_facing() == Direction.Right then
                    self:set_offset(self:get_offset().x+11*2,self:get_offset().y)
                else
                    self:set_offset(self:get_offset().x-11*2,self:get_offset().y)
                end
                self:set_elevation(self:get_elevation()-11*2)
            else
                self.state = "END"
                self.frames = 1
                if not tile:is_hole() then
                    self:shake_camera(10, 0.333)
                end
                if math.random(1,2) == 1 and not tile:is_cracked() and not tile:is_hole() then
                    Engine.play_audio(AudioType.PanelCrack, AudioPriority.Immediate)
                    tile:set_state(TileState.Cracked)
                end
                local hit_fx = graphic_init("spell", -2*2, 3*2, BOOM2_TEXTURE, BOOM2_PALETTE, BOOM2_ANIMPATH, -99, "0", Playback.Once, user, facing, true, true)
                field:spawn(hit_fx, tile)
                create_meteor_knuckle_hitbox(user, self, field, tile)
                --Engine.play_audio(METEORHIT_AUDIO, AudioPriority.Immediate)
            end
        end
        if self.state == "END" then
            for i=6, 9 do
                if self.frames == i then
                    if self:get_facing() == Direction.Right then
                        self:set_offset(self:get_offset().x-11*2,self:get_offset().y)
                    else
                        self:set_offset(self:get_offset().x+11*2,self:get_offset().y)
                    end
                    self:set_elevation(self:get_elevation()+11*2)
                end
            end
            if self.frames == 10 then
                self:delete()
            end
        end
        self.frames = self.frames + 1
    end
    knuckle.battle_end_func = function(self)
        self:delete()
    end
    knuckle.delete_func = function(self)
        self:erase()
    end
    field:spawn(knuckle, tile)
    return knuckle
end

local function create_destroy_ring(user, tile)
    if not tile or tile:is_edge() then return end
    local field = user:get_field()
    local ring = graphic_init("spell", 0, 0, DESTROYLASER_TEXTURE, DESTROYLASER_PALETTE, DESTROYLASER_ANIMPATH, -3, "DESTROYRING1", Playback.Once, user, user:get_facing())
    ring:set_hit_props(
        HitProps.new()
        :dmg(user.damage_destroylaser)
        :impact()
        :flinch()
        :flash()
        :breaking()
        :pierce()
        :retangible()
        :from(user:get_context())
    )
    ring.anim = ring:get_animation()
    ring.frames = 1
    ring.update_func = function(self)
        if user.deleting then
            self:delete()
            return
        end
        if self.anim:get_state() == "DESTROYRING2" then
            tile:attack_entities(self)
            tile:get_tile(Direction.Up,1):attack_entities(self)
            tile:get_tile(Direction.Down,1):attack_entities(self)
        end
        if self.frames == 7 then
            self.anim:set_state("DESTROYRING2")
            self.anim:set_playback(Playback.Loop)
            self.anim:refresh(self:sprite())
        end
        if self.frames == 21 then
            self.anim:set_state("DESTROYRING3")
            self.anim:refresh(self:sprite())
        end
        if self.frames == 25 then
            self:delete()
        end
        self.frames = self.frames + 1
    end
    ring.battle_end_func = function(self)
        self:delete()
    end
    ring.delete_func = function(self)
        self:erase()
    end
    field:spawn(ring, tile)
    return ring
end

-- Creates Destroy Laser.
local function create_destroy_laser(user, start_tile, ring_number)
    if not start_tile or start_tile:is_edge() then return end
    local function create_destroy_laser_hitbox(user, laser, field, tile)
        if not tile or tile:is_edge() then return end
        local spell = Battle.Spell.new(laser:get_team())
        spell:set_facing(laser:get_facing())
        spell:set_hit_props(
            HitProps.new()
            :dmg(user.damage_destroylaser)
            :impact()
            :flinch()
            :flash()
            :breaking()
            :from(user:get_context())
        )
        spell.update_func = function(self)
            if user.deleting then
                self:delete()
                return
            end
            if laser:get_animation():get_state() == "DESTROYLASER2" and not user.remove_laser_hitboxes then
                tile:attack_entities(self)
            else
                self:delete()
            end
        end
        -- Colliding a Character or an Obstacle removes every single hitbox.
        spell.collision_func = function(self)
            user.remove_laser_hitboxes = true
        end
        spell.battle_end_func = function(self)
            self:delete()
        end
        spell.delete_func = function(self)
            self:erase()
        end
        field:spawn(spell, tile)
        return spell
    end
    local field = user:get_field()
    local laser = graphic_init("spell", 0, 0, DESTROYLASER_TEXTURE, DESTROYLASER_PALETTE, DESTROYLASER_ANIMPATH, -3, "DESTROYLASER1", Playback.Once, user, user:get_facing())
    laser.anim = laser:get_animation()
    laser.tiles = {
        [1] = start_tile:get_tile(laser:get_facing(),1),
        [2] = start_tile:get_tile(laser:get_facing(),3),
        [3] = start_tile:get_tile(laser:get_facing(),2),
        [4] = start_tile:get_tile(laser:get_facing(),4),
    }
    laser.tiles_index = 1
    laser.frames = 1
    laser.on_spawn_func = function(self)
        Engine.play_audio(DESTROYLASER_AUDIO, AudioPriority.Immediate)
    end
    laser.update_func = function(self)
        if user.deleting then
            self:delete()
            return
        end
        if self.frames == 14 then
            self.anim:set_state("DESTROYLASER2")
            self.anim:set_playback(Playback.Loop)
            self.anim:refresh(self:sprite())
            for i=1, field:width() do
                local tile = start_tile:get_tile(self:get_facing(),i)
                create_destroy_laser_hitbox(user, self, field, tile)
                if tile:is_edge() then break end
            end
        end
        for i=1, user.rings do
            if self.frames == 21+(user.ring_delay*(i-1)) then -- 24/21/18/15
                create_destroy_ring(user, self.tiles[self.tiles_index])
                self.tiles_index = self.tiles_index + 1
                if self.tiles_index > #self.tiles then self.tiles_index = 1 end
            end
        end
        if self.frames == 151 then
            self.anim:set_state("DESTROYLASER3")
            self.anim:refresh(self:sprite())
        end
        if self.frames == 164 then
            self:delete()
        end
        self.frames = self.frames + 1
    end
    laser.battle_end_func = function(self)
        self:delete()
    end
    laser.delete_func = function(self)
        user.remove_laser_hitboxes = false
        self:erase()
    end
    field:spawn(laser, start_tile)
    return laser
end

local function create_duo_yura(user, start_tile)
    local field = user:get_field()
    local yura = graphic_init("obstacle", 0, 0, DUOYURA_TEXTURE, nil, DUOYURA_ANIMPATH, -3, "0", Playback.Once, user, user:get_facing())
	ObstacleInfo.set_cannot_be_targeted(yura, true)
	ObstacleInfo.set_cannot_be_manipulated(yura, true)
	ObstacleInfo.set_obstacle_damage(yura, Element.None, user.damage_duoyura)
    yura:share_tile(true)
    yura:set_name("DuoYura")
    yura:set_health(40)
    --[[
    yura:set_hit_props(
        HitProps.new()
        :dmg(user.damage_duoyura)
        :impact()
        :flinch()
        :flash()
        :from(user:get_context())
    )]]
    ----
    yura.attack_delay = math.random(1,10)
    yura.dir = Direction.Down
    if start_tile:y() >= field:height() then
        yura.dir = Direction.Up
    end
    yura.pos_offset = {
        [ 1] = { x= 1 , y=  0 },
        [ 2] = { x= 1 , y=  0 },
        [ 3] = { x= 2 , y=  0 },
        [ 4] = { x= 1 , y=  0 },
        [ 5] = { x= 2 , y=  1 },
        [ 6] = { x= 1 , y=  1 },
        [ 7] = { x= 2 , y=  0 },
        [ 8] = { x= 1 , y=  1 },
        [ 9] = { x= 2 , y=  1 },
        [10] = { x= 1 , y=  2 },
        [11] = { x= 2 , y=  1 },
        [12] = { x= 1 , y=  1 },
        [13] = { x= 2 , y=  1 },
        [14] = { x= 1 , y=  2, dir= Direction.join(yura:get_facing(), yura.dir) }, --
        [15] = { x= 2 , y=  1 },
        [16] = { x= 1 , y=  2 },
        [17] = { x= 2 , y=  1 },
        [18] = { x= 1 , y=  1 },
        [19] = { x= 2 , y=  2 },
        [20] = { x= 1 , y=  1 },
        [21] = { x= 2 , y=  1 },
        [22] = { x= 1 , y=  1 },
        [23] = { x= 2 , y=  1 },
        [24] = { x= 1 , y=  0 },
        [25] = { x= 2 , y=  1 },
        [26] = { x= 1 , y=  0 },
        [27] = { x= 2 , y=  0 },
        [28] = { x= 1 , y=  0 },
        [29] = { x= 2 , y=  0 },
        [30] = { x= 1 , y=  0 },
        [31] = { x= 2 , y=  0 },
        [32] = { x= 1 , y= -1 },
        [33] = { x= 2 , y= -1 },
        [34] = { x= 1 , y= -1 },
        [35] = { x= 2 , y= -1 },
        [36] = { x= 1 , y= -1 },
        [37] = { x= 2 , y= -1 },
        [38] = { x= 1 , y= -1 },
        [39] = { x= 2 , y= -2 },
        [40] = { x= 1 , y= -1 },
        [41] = { x= 2 , y= -1, dir= yura:get_facing() }, --
        [42] = { x= 1 , y= -2 },
        [43] = { x= 2 , y= -1 },
        [44] = { x= 1 , y= -2, dir= Direction.reverse(yura.dir) }, --
        [45] = { x= 2 , y= -1 },
        [46] = { x= 1 , y= -1 },
        [47] = { x= 2 , y= -1 },
        [48] = { x= 1 , y= -1 },
        [49] = { x= 2 , y= -1 },
        [50] = { x= 1 , y= -1 },
        [51] = { x= 2 , y= -1 },
        [52] = { x= 1 , y=  0 },
        [53] = { x= 2 , y=  0 },
        [54] = { x= 1 , y=  0 },
    }
    yura.pos_index = 1
    yura.new_tile = start_tile
    local tileWidth = start_tile:width()/2
    local tileHeight = start_tile:height()/2 - start_tile:height()/10
    local round = function(val)
        if facing == Direction.Right then
            return math.floor(val)
        else
            return math.ceil(val)
        end
    end
    yura.x_coord = 0
    yura.y_coord = 0
    ----
    yura.state = "SPAWN"
    yura.frames = 1
    ----
    yura.on_spawn_func = function(self)
        yura:set_shadow(SHADOW_TEXTURE)
        Engine.play_audio(DUOYURA_AUDIO, AudioPriority.Immediate)
        local smoke_fx = graphic_init("artifact", 0, 0, SMOKE_TEXTURE, SMOKE_PALETTE, SMOKE_ANIMPATH, -99, "0", Playback.Once, self, self:get_facing(), true, true, true)
        smoke_fx:set_elevation(18*2)
        self:get_field():spawn(smoke_fx, self:get_tile())
    end
    yura:get_animation():on_frame(2, function()
        yura:show_shadow(true)
    end)
    yura.update_func = function(self)
        if user.deleting or self:get_tile():is_edge() then
            self:delete()
            return
        end
        check_collision(user, self, ObstacleInfo.get_obstacle_damage_number(self), self:get_tile())
        --self:get_tile():attack_entities(self)
        --self:get_tile():highlight(Highlight.Solid)
        if self.state == "SPAWN" then
            if self:get_facing() == Direction.Right then
                self.x_coord = self.x_coord + user.yura_spawn_speed
            else
                self.x_coord = self.x_coord - user.yura_spawn_speed
            end
            if     (self:get_facing() == Direction.Right and round(self.x_coord) >  tileWidth/2) then
                self.new_tile = self.new_tile:get_tile(Direction.Right,1)
                self:teleport(self.new_tile, ActionOrder.Immediate)
                self.x_coord = -(tileWidth-(self.x_coord-tileWidth))
            elseif (self:get_facing() == Direction.Left  and round(self.x_coord) < -tileWidth/2) then
                self.new_tile = self.new_tile:get_tile(Direction.Left, 1)
                self:teleport(self.new_tile, ActionOrder.Immediate)
                self.x_coord =  (tileWidth+(self.x_coord+tileWidth))
            end
            self:set_offset(round(self.x_coord), 0)
            if self.frames == self.attack_delay then
                self.frames = 1
                self.state = "ATTACK"
            end
        end
        if self.state == "ATTACK" then
            for i=1, user.yura_speed do
                if self.pos_offset[self.pos_index] ~= nil then
                    if self:get_facing() == Direction.Right then
                        self.x_coord = self.x_coord + self.pos_offset[self.pos_index].x*2
                    else
                        self.x_coord = self.x_coord - self.pos_offset[self.pos_index].x*2
                    end
                    if self.dir == Direction.Down then
                        self.y_coord = self.y_coord + self.pos_offset[self.pos_index].y*2
                    else
                        self.y_coord = self.y_coord - self.pos_offset[self.pos_index].y*2
                    end
                    if (self:get_facing() == Direction.Right and round(self.x_coord) >  tileWidth/2) then
                        self.x_coord = -(tileWidth-(self.x_coord-tileWidth))
                        self.new_tile = self.new_tile:get_tile(Direction.Right,1)
                        self:teleport(self.new_tile, ActionOrder.Immediate)
                    end
                    if (self:get_facing() == Direction.Left  and round(self.x_coord) < -tileWidth/2) then
                        self.x_coord =  (tileWidth+(self.x_coord+tileWidth))
                        self.new_tile = self.new_tile:get_tile(Direction.Left, 1)
                        self:teleport(self.new_tile, ActionOrder.Immediate)
                    end
                    if math.floor(self.y_coord) >  tileHeight/2 then
                        self.y_coord = -(tileHeight-(self.y_coord-tileHeight))
                        self.new_tile = self.new_tile:get_tile(Direction.Down, 1)
                        self:teleport(self.new_tile, ActionOrder.Immediate)
                    end
                    if math.floor(self.y_coord) < -tileHeight/2 then
                        self.y_coord =  (tileHeight+(self.y_coord+tileHeight))
                        self.new_tile = self.new_tile:get_tile(Direction.Up,   1)
                        self:teleport(self.new_tile, ActionOrder.Immediate)
                    end
                    self:set_offset(round(self.x_coord),math.floor(self.y_coord))
                    self.pos_index = self.pos_index + 1
                    if self.pos_index > #self.pos_offset then self.pos_index = 1 end
                end
            end
        end
        self.frames = self.frames + 1
    end
    yura.collision_func = function(self)
        self:set_health(0)
    end
    yura.can_move_to_func = function(tile)
        return true
    end
    yura.battle_end_func = function(self)
        self:delete()
    end
    yura.delete_func = function(self)
        if self:get_health() <= 0 then
            Engine.play_audio(BOOM_AUDIO, AudioPriority.Immediate)
            local boom_fx = graphic_init("artifact", self:get_tile_offset().x+self:get_offset().x, self:get_tile_offset().y+self:get_offset().y, BOOM1_TEXTURE, BOOM1_PALETTE, BOOM1_ANIMPATH, -99, "0", Playback.Once, self, self:get_facing(), true, false, true)
            boom_fx:set_elevation(self:get_elevation())
            self:get_field():spawn(boom_fx, self:get_tile())
        end
        self:erase()
    end
    user:get_field():spawn(yura, start_tile)
    return yura
end

local function create_duo_missile(user, start_tile, move_tile)
    local field = user:get_field()
    local missile = graphic_init("obstacle", 0, 0, user.texture, nil, DUOMISSILE_ANIMPATH, -3, "DUOMISSILE", Playback.Loop, user, user:get_facing())
	ObstacleInfo.set_cannot_be_targeted(missile, true)
	ObstacleInfo.set_cannot_be_manipulated(missile, true)
	ObstacleInfo.set_obstacle_damage(missile, Element.None, user.damage_duomissile)
    missile:share_tile(true)
    missile:set_name("DuoMissile")
    missile:set_health(40)
    --[[
    missile:set_hit_props(
        HitProps.new()
        :dmg(user.damage_duomissile)
        :impact()
        :flinch()
        :flash()
        :from(user:get_context())
    )]]
    missile.state = "SPAWN"
    missile.frames = 1
    missile.on_spawn_func = function(self)
        Engine.play_audio(DUOMISSILE_AUDIO_SPAWN, AudioPriority.Immediate)
        local smoke_fx = graphic_init("artifact", 0, 0, SMOKE_TEXTURE, SMOKE_PALETTE, SMOKE_ANIMPATH, -99, "0", Playback.Once, self, self:get_facing(), true, true, true)
        smoke_fx:set_elevation(18*2)
        field:spawn(smoke_fx, self:get_tile())
    end
    missile.update_func = function(self)
        if user.deleting then
            self:delete()
            return
        end
        if self:get_tile():is_edge() then
            self:delete()
            return
        end
        check_collision(user, self, ObstacleInfo.get_obstacle_damage_number(self), self:get_tile())
        --self:get_tile():attack_entities(self)
        if self.state == "SPAWN" then
            if self.frames == 1 then
                self:slide(move_tile, frames(8), frames(0), ActionOrder.Immediate)
            end
            if self.frames >= 25 then
                self.frames = 0
                self.state = "ATTACK"
                Engine.play_audio(DUOMISSILE_AUDIO_SHOOT, AudioPriority.Immediate)
            end
        elseif self.state == "ATTACK" then
            if not self:is_sliding() then
                local next_tile = self:get_tile(self:get_facing(), 1)
                if not next_tile then
                    self:delete()
                else
                    self:slide(next_tile, frames(12), frames(0), ActionOrder.Voluntary)
                end
            end
        end
        self.frames = self.frames + 1
    end
    missile.collision_func = function(self)
        self:set_health(0)
    end
    missile.can_move_to_func = function(tile)
        return true
    end
    missile.battle_end_func = function(self)
        self:delete()
    end
    missile.delete_func = function(self)
        if self:get_health() <= 0 then
            Engine.play_audio(BOOM_AUDIO, AudioPriority.Immediate)
            local boom_fx = graphic_init("artifact", self:get_tile_offset().x+self:get_offset().x, self:get_tile_offset().y+self:get_offset().y, BOOM1_TEXTURE, BOOM1_PALETTE, BOOM1_ANIMPATH, -99, "0", Playback.Once, self, self:get_facing(), true, false, true)
            boom_fx:set_elevation(self:get_elevation())
            self:get_field():spawn(boom_fx, self:get_tile())
        end
        self:erase()
    end
    field:spawn(missile, start_tile)
    return missile
end

-- Creates Justice Fist.
-- If stunned while highlighting tiles, gets deleted.
function create_justice_fist(user, state, start_tile)
    local tileWidth = start_tile:width()/2
    local tileHeight = start_tile:height()/2 - start_tile:height()/10
    debug_print(tileWidth,tileHeight)
    local field = user:get_field()
    local fist = graphic_init("spell", tileWidth, -(math.floor(tileHeight/3)*2), user.texture, nil, DUO_ANIMPATH, -3, state, Playback.Once, user, user:get_facing(), false, true)
    fist:set_elevation((12*2)*14)
    fist:hide()
    fist.frames = 1
    fist.state = "WAIT"
    fist.tiles = {
        [1] = start_tile,
        [2] = start_tile:get_tile(Direction.Up,1),
        [3] = start_tile:get_tile(user:get_facing(),1),
        [4] = start_tile:get_tile(Direction.join(user:get_facing(),Direction.Up),1),
    }
    local function create_hitbox(user, tile)
        local spell = Battle.Spell.new(user:get_team())
        spell:set_facing(user:get_facing())
        spell:set_hit_props(
            HitProps.new()
            :dmg(user.damage_justicefist)
            :impact()
            :flinch()
            :flash()
            :breaking()
            :pierce_ground()
            :retangible()
            :from(user:get_context())
        )
        local query = function(o)
            return o:get_name() == "DuoYura" or o:get_name() == "DuoMissile"
        end
        spell.update_func = function(self)
            if user.deleting then
                self:delete()
                return
            end
            local duo_objs = tile:find_obstacles(query)
            if #duo_objs>0 then
                for i=1,#duo_objs do
                    duo_objs[i]:set_health(0)
                end
            end
            tile:attack_entities(self)
            tile:highlight(Highlight.Solid)
            self:delete()
        end
        spell.attack_func = function(self, other, judge)
            if not judge:hint_spawn_gfx() then return end
            local offset_y = math.random(-5,6)
            local offset_x = math.random(-6,5)
            local hit_fx = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT0_TEXTURE, EFFECT0_PALETTE, EFFECT0_ANIMPATH, -999, "0", Playback.Once, self, self:get_facing(), true, true, true)
            self:get_field():spawn(hit_fx, self:get_tile())
        end
        spell.battle_end_func = function(self)
            self:delete()
        end
        spell.delete_func = function(self)
            self:erase()
        end
        user:get_field():spawn(spell, tile)
        return spell
    end
    fist.update_func = function(self, dt)
        if user.deleting then
            self:delete()
            return
        end
        if self.state == "WAIT" then
            if user:is_stunned() then
                self:delete()
                return
            end
            for i=1, #self.tiles do
                field:tile_at(self.tiles[i]:x(),self.tiles[i]:y()):highlight(Highlight.Flash)
            end
            if self.frames == 27 then
                self.frames = 1
                self.state = "ATTACK"
                self:reveal()
            end
        end
        if self.state == "ATTACK" then
            for i=1, #self.tiles do
                field:tile_at(self.tiles[i]:x(),self.tiles[i]:y()):highlight(Highlight.Solid)
            end
            if self:get_elevation() > 0 then
                self:set_elevation(self:get_elevation()-(12*2))
            else
                self.frames = 1
                self.state = "END"
                self:shake_camera(10, 0.333)
                Engine.play_audio(JUSTICEFIST_AUDIO, AudioPriority.Immediate)
                for i=1, #self.tiles do
                    create_hitbox(user, self.tiles[i])
                end
                local hit_fx = graphic_init("artifact", self:get_offset().x, self:get_offset().y, FIST_IMPACT_TEXTURE, FIST_IMPACT_PALETTE, FIST_IMPACT_ANIMPATH, -2, "0", Playback.Once, self, self:get_facing(), true)
                hit_fx:set_elevation(11*2)
                field:spawn(hit_fx, start_tile)
            end
        end
        if self.state == "END" then
            if self.frames == 51 then
                local move_fx = graphic_init("artifact", self:get_offset().x, self:get_offset().y, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, -99, "1", Playback.Once, self, self:get_facing(), true, false, true)
                move_fx:set_elevation(32*2)
                field:spawn(move_fx, start_tile)
            end
            if self.frames == 52 then
                self:delete()
            end
        end
        self.frames = self.frames + 1
    end
    fist.delete_func = function(self) 
        self:erase()
    end
    fist.can_move_to_func = function(tile)
        return true
    end
    field:spawn(fist, start_tile)
    return fist
end

-- Creates Giant Hook.
-- If stunned while highlighting tiles, gets deleted.
function create_giant_hook(user, x_start, x_end, x_mid, start_tile, start_x, start_y, state, dir, pos_offset)
    local tileWidth = start_tile:width()/2
    local tileHeight = start_tile:height()/2 - start_tile:height()/10
    debug_print(tileWidth,tileHeight)
    local field = user:get_field()
    local fist = graphic_init("spell", start_x, start_y, user.texture, nil, DUO_ANIMPATH, -3, state, Playback.Once, user, user:get_facing(), false, true)
    fist:get_animation():set_playback_speed(0)
    fist:hide()
    fist.frames = 1
    fist.state = "WAIT"
    local round = function(val)
        if fist:get_facing() == Direction.Right then
            return math.floor(val)
        else
            return math.ceil(val)
        end
    end
    local function create_hitbox(user, tile)
        if not tile or tile:is_edge() then return end
        local spell = Battle.Spell.new(user:get_team())
        spell:set_facing(user:get_facing())
        spell:set_hit_props(
            HitProps.new()
            :dmg(user.damage_gianthook)
            :impact()
            :flinch()
            :flash()
            :breaking()
            :from(user:get_context())
        )
        spell.frames = 1
        local query = function(o)
            return o:get_name() == "DuoYura" or o:get_name() == "DuoMissile"
        end
        spell.update_func = function(self)
            if user.deleting then
                self:delete()
                return
            end
            local duo_objs = tile:find_obstacles(query)
            if #duo_objs>0 then
                for i=1,#duo_objs do
                    duo_objs[i]:set_health(0)
                end
            end
            tile:attack_entities(self)
            tile:highlight(Highlight.Solid)
            local next_tile = tile:get_tile(self:get_facing(),1)
            next_tile:attack_entities(self)
            if next_tile and not next_tile:is_edge() then
                next_tile:highlight(Highlight.Solid)
            end
            if self.frames == 7 then
                self:delete()
            end
            self.frames = self.frames + 1
        end
        spell.attack_func = function(self, other, judge)
            if not judge:hint_spawn_gfx() then return end
            local offset_y = math.random(-5,6)
            local offset_x = math.random(-6,5)
            local hit_fx = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT0_TEXTURE, EFFECT0_PALETTE, EFFECT0_ANIMPATH, -999, "0", Playback.Once, self, self:get_facing(), true, true, true)
            self:get_field():spawn(hit_fx, self:get_tile())
        end
        spell.battle_end_func = function(self)
            self:delete()
        end
        spell.delete_func = function(self)
            self:erase()
        end
        user:get_field():spawn(spell, tile)
        return spell
    end
    fist.update_func = function(self, dt)
        if user.deleting then
            self:delete()
            return
        end
        if self.state == "WAIT" then
            if user:is_stunned() then
                self:delete()
                return
            end
            for x=x_start, x_end, x_mid do
                for y=1, field:height() do
                    field:tile_at(x,y):highlight(Highlight.Flash)
                end
            end
            if self.frames == 27 then
                self.frames = 1
                self.state = "ATTACK"
                self:reveal()
                self:get_animation():set_playback_speed(1)
                Engine.play_audio(GIANTHOOK_AUDIO, AudioPriority.Immediate)
            end
        end
        if self.state == "ATTACK" then
            if pos_offset[self.frames] ~= nil then
                if pos_offset[self.frames].x == 0 and pos_offset[self.frames].y == 0 then
                    self:hide()
                else
                    self:reveal()
                end
                if self.frames == #pos_offset then
                    self:delete()
                else
                    if self:get_facing() == Direction.Right then
                        self:set_offset(self:get_offset().x+ (pos_offset[self.frames].x*2), self:get_offset().y+(pos_offset[self.frames].y*2))
                    else
                        self:set_offset(self:get_offset().x+(-pos_offset[self.frames].x*2), self:get_offset().y+(pos_offset[self.frames].y*2))
                    end
                    local round_x = round(self:get_offset().x)
                    local round_y = round(self:get_offset().y)
                    if (dir == Direction.Down and round_y > tileHeight) or (dir == Direction.Up and round_y < tileHeight) then
                        local tile = self:get_tile(dir,1)
                        if tile then
                            if round_y > tileHeight then
                                round_y = -(tileHeight-(round_y-tileHeight))
                            elseif round_y < tileHeight then
                                round_y = (tileHeight+(round_y+tileHeight))
                            end
                            self:set_offset(round_x,round_y)
                            self:teleport(tile, ActionOrder.Immediate)
                            create_hitbox(user, tile)
                            --create_hitbox(user, tile:get_tile(self:get_facing(),1))
                        end
                    end
                end
            end
        end
        self.frames = self.frames + 1
    end
    fist.delete_func = function(self) 
        self:erase()
    end
    fist.can_move_to_func = function(tile)
        return true
    end
    field:spawn(fist, start_tile)
    return fist
end 

function package_init(self)
    self.texture = DUO_TEXTURE
    self.damage = 100
    self.damage_duomissile = 50
    self.damage_duoyura = 50
    self.damage_destroylaser = 100
    self.damage_justicefist = 100
    self.damage_meteorknuckle = 100
    self.damage_gianthook = 100
    self.damage_angerimpact = 100
    self.yura_spawn_speed = 2*2
    self.yura_speed = 1
    self.ring_delay = 24
    self.rings = 5
    local rank = self:get_rank()
    if rank == Rank.V2 then
        self:set_health(2500)
        self.damage = 200
        self.damage_duomissile = 100
        self.damage_duoyura = 100
        self.damage_destroylaser = 200
        self.damage_justicefist = 200
        self.damage_meteorknuckle = 200
        self.damage_gianthook = 200
        self.damage_angerimpact = 200
        self.yura_spawn_speed = 3*2
        self.yura_speed = 2
        self.ring_delay = 21
        self.rings = 6
    elseif rank == Rank.V3 then
        self:set_health(3000)
        self.damage = 300
        self.damage_duomissile = 150
        self.damage_duoyura = 150
        self.damage_destroylaser = 300
        self.damage_justicefist = 300
        self.damage_meteorknuckle = 300
        self.damage_gianthook = 300
        self.damage_angerimpact = 300
        self.yura_spawn_speed = 4*2
        self.yura_speed = 3
        self.ring_delay = 18
        self.rings = 7
    elseif rank == Rank.SP then
        self.texture = DUO_TEXTURE_SP
        self:set_health(3500)
        self.damage = 400
        self.damage_duomissile = 200
        self.damage_duoyura = 200
        self.damage_destroylaser = 400
        self.damage_justicefist = 400
        self.damage_meteorknuckle = 400
        self.damage_gianthook = 400
        self.damage_angerimpact = 400
        self.yura_spawn_speed = 4*2
        self.yura_speed = 3
        self.ring_delay = 15
        self.rings = 8
    else
        self:set_health(2000)
    end
    self:set_name("Duo")
    self:set_texture(self.texture, true)
    self:set_height(100)
    self:share_tile(true)
    self:set_float_shoe(true)
    self:set_air_shoe(true)
    self:set_explosion_behavior(11, 2, true) --12

    self:set_offset(idleDuoPos.x, idleDuoPos.y)

    anim = self:get_animation()
    anim:load(DUO_ANIMPATH)
    anim:set_state("BODY_IDLE")
    anim:set_playback(Playback.Loop)
    anim:refresh(self:sprite())
    anim:set_playback_speed(0)

    self.core = self:create_node()
    self.core:set_texture(self.texture, true)
    self.core:set_offset(idleHandPos.x, idleHandPos.y)
    self.core:set_layer(-1)
    self.core:enable_parent_shader(true)
    self.core_anim = Engine.Animation.new(anim)
    self.core_anim:set_state("BODY_CORE")
    self.core_anim:refresh(self.core)
    self.core:hide()

    self.cannon = self:create_node()
    self.cannon:set_texture(self.texture, true)
    self.cannon:set_offset(idleHandPos.x, idleHandPos.y)
    self.cannon:set_layer(-1)
    self.cannon:enable_parent_shader(true)
    self.cannon_anim = Engine.Animation.new(anim)
    self.cannon_anim:set_state("CANNON1")
    self.cannon_anim:refresh(self.cannon)
    self.cannon:hide()

    self.hand = self:create_node()
    self.hand:set_texture(self.texture, true)
    self.hand:set_offset(idleHandPos.x, idleHandPos.y)
    self.hand:set_layer(-2) -- put it in front at all times
    self.hand:enable_parent_shader(true)
    self.hand_anim = Engine.Animation.new(anim)
    self.hand_anim:set_state("HAND_IDLE")
    self.hand_anim:set_playback(Playback.Loop)
    self.hand_anim:refresh(self.hand)
    self.hand_anim:set_playback_speed(0)
    
    self.core_do_once = false

    local ref = self
    --This is how we animate nodes.
    self.animate_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.animate_component.update_func = function(self, dt)
        if not ref:is_stunned() then
            if ref.core_do_once then
                ref.core_do_once = false
                ref.core:show()
            end
            ref.core_anim:update(dt, ref.core)
            ref.cannon_anim:update(dt, ref.cannon)
            ref.hand_anim:update(dt, ref.hand)
        end
    end
    self:register_component(self.animate_component)
    --[[
    local origin = anim:point("origin")
    local point  = anim:point("NO_SHOOT")
    ]]
    self.defending = true
    self.defense = Battle.DefenseRule.new(1, DefenseOrder.Always)
    self.defense.filter_statuses_func = function(props)
        debug_print("inside filter_statuses_func")
        if props.flags & Hit.Flinch == Hit.Flinch then
            props.flags = props.flags~Hit.Flinch
        end
        if props.flags & Hit.Flash == Hit.Flash then
            props.flags = props.flags~Hit.Flash
        end
        if props.flags & Hit.Confuse == Hit.Confuse then
            props.flags = props.flags~Hit.Confuse
        end
        if props.flags & Hit.Blind == Hit.Blind then
            props.flags = props.flags~Hit.Blind
        end
        if props.flags & Hit.Root == Hit.Root then
            props.flags = props.flags~Hit.Root
        end
        if props.flags & Hit.Bubble == Hit.Bubble then -- ???
            props.flags = props.flags~Hit.Bubble
        end
        if props.flags & Hit.Drag == Hit.Drag then
            props.flags = props.flags~Hit.Drag
        end
        return props
    end
    self.defense.can_block_func = function(judge, attacker, defender)
        judge:hint_spawn_gfx(true)
        if self.defending then
            judge:block_damage()
            judge:block_impact()
        end
    end
    self:add_defense_rule(self.defense)
    debug_print("defense was created")
    self.can_move_to_func = function(tile)
        if tile:is_edge() then
            return false
        end
        return true
    end
    self.on_spawn_func = function(self, tile) 
        debug_print("on_spawn_func called")
        local rank = self:get_rank()
        if     rank == Rank.V2 then
            self:set_name("DuoV2")
        elseif rank == Rank.V3 then
            self:set_name("DuoV3")
        elseif rank == Rank.SP then
            self:set_name("DuoSP")
        end
    end
    self.deleting = false
    self.delete_func = function(self)
        debug_print("delete_func called")
        self.deleting = true
        self:set_offset(idleDuoPos.x, idleDuoPos.y)
        self.hand:set_offset(idleHandPos.x, idleHandPos.y)
        anim:set_state("BODY_IDLE")
        anim:set_playback(Playback.Loop)
        anim:refresh(self:sprite())
        anim:set_playback_speed(1)
        self.hand_anim:set_state("HAND_IDLE")
        self.hand_anim:set_playback(Playback.Loop)
        self.hand_anim:refresh(self.hand)
        self.hand_anim:set_playback_speed(1)
    end
    self.battle_end_func = function(self)
        debug_print("battle_end_func called")
    end
    local function reconstruct_pattern(self)
        local r_mn = math.random(1,2)
        if self.move_count > 15 and r_mn == 1 then -- 25
            table.insert(self.pattern, "HAND OUT")
            table.insert(self.pattern, "METEOR KNUCKLE")
            table.insert(self.pattern, "HAND IN")
            self.move_count = 0 -- RESET
        else
            local r0 = math.random(1,2)
            if self:get_tile():y() <= 1 or self:get_tile():y() >= self:get_field():height() then
                if r0 == 1 then
                    self.pattern = {"MOVING"}
                    self.move_count = self.move_count + 1 -- PLUS
                    table.insert(self.pattern, "DESTROY LASER")
                    self.move_count = self.move_count + 1 -- PLUS
                else
                    self.pattern = {"MOVING"}
                    self.move_count = self.move_count + 1 -- PLUS
                    local r1 = math.random(1,2)
                    if r1 == 1 then
                        table.insert(self.pattern, "DUO PROJECTILES")
                    else

                    end
                end
            else
                self.pattern = {"MOVING"}
                self.move_count = self.move_count + 1 -- PLUS
                local r1 = math.random(1,2)
                if r1 == 1 then
                    table.insert(self.pattern, "DUO PROJECTILES")
                else

                end
            end
            local r2 = math.random(1,4)
            if self:get_health() <= math.floor(self:get_max_health()/2) then r2 = math.random(1,5) end
            if r2 == 1 then
                table.insert(self.pattern, "HAND OUT")
                table.insert(self.pattern, "CHOOSE JUSTICE FIST")
                table.insert(self.pattern, "HAND IN")
                self.move_count = self.move_count + 1 -- PLUS
            elseif r2 == 2 then
                table.insert(self.pattern, "HAND OUT")
                table.insert(self.pattern, "GIANT HOOK")
                table.insert(self.pattern, "HAND IN")
                self.move_count = self.move_count + 1 -- PLUS
            elseif r2 == 3 then
                table.insert(self.pattern, "HAND OUT")
                table.insert(self.pattern, "CHOOSE JUSTICE FIST")
                table.insert(self.pattern, "HAND IN")
                self.move_count = self.move_count + 1 -- PLUS
                table.insert(self.pattern, "HAND OUT")
                table.insert(self.pattern, "GIANT HOOK")
                table.insert(self.pattern, "HAND IN")
                self.move_count = self.move_count + 1 -- PLUS
            elseif r2 == 4 then
                -- NONE
            elseif r2 == 5 then
                table.insert(self.pattern, "ANGER IMPACT")
                self.move_count = self.move_count + 1 -- PLUS
            end
        end
    end
    self.battle_start_func = function(self)
        debug_print("on_battle_start called")
        anim:set_playback_speed(1)
        self.hand_anim:set_playback_speed(1)
        reconstruct_pattern(self)
    end
    self.pattern = {"MOVING"}
    self.pattern_index = 1
    self.hand_pos_offset1 = {
        [ 1] = { b_x=  0 , h_x=  0 , h_z=  0 },
        [ 2] = { b_x=  0 , h_x= -5 , h_z=  1 },
        [ 3] = { b_x= -1 , h_x= -6 , h_z=  2 },
        [ 4] = { b_x=  0 , h_x= -5 , h_z=  1 },
        [ 5] = { b_x= -1 , h_x= -6 , h_z=  2 },
        [ 6] = { b_x=  0 , h_x= -5 , h_z=  1 },
        [ 7] = { b_x= -1 , h_x= -6 , h_z=  2 },
        [ 8] = { b_x=  0 , h_x= -5 , h_z=  1 },
        [ 9] = { b_x= -1 , h_x= -6 , h_z=  2 },
        [10] = { b_x=  0 , h_x= -5 , h_z=  1 },
        [11] = { b_x=  0 , h_x= -6 , h_z=  2 },
        [12] = { b_x=  0 , h_x= -5 , h_z=  1 },
        [13] = { b_x=  0 , h_x= -6 , h_z=  2 },
        [14] = { b_x=  0 , h_x= -5 , h_z=  1 },
        [15] = { b_x=  0 , h_x= -6 , h_z=  2 },
        [16] = { b_x=  0 , h_x= -5 , h_z=  1 },
        [17] = { b_x=  0 , h_x= -6 , h_z=  2 },
        [18] = { b_x=  0 , h_x= -5 , h_z=  1 },
    }
    self.hand_pos_offset2 = {
        [ 1] = { b_x=  0 , h_x=  0 , h_z=  0 },
        [ 2] = { b_x=  0 , h_x=  5 , h_z= -1 },
        [ 3] = { b_x=  1 , h_x=  6 , h_z= -2 },
        [ 4] = { b_x=  0 , h_x=  5 , h_z= -1 },
        [ 5] = { b_x=  1 , h_x=  6 , h_z= -2 },
        [ 6] = { b_x=  0 , h_x=  5 , h_z= -1 },
        [ 7] = { b_x=  1 , h_x=  6 , h_z= -2 },
        [ 8] = { b_x=  0 , h_x=  5 , h_z= -1 },
        [ 9] = { b_x=  1 , h_x=  6 , h_z= -2 },
        [10] = { b_x=  0 , h_x=  5 , h_z= -1 },
        [11] = { b_x=  0 , h_x=  6 , h_z= -2 },
        [12] = { b_x=  0 , h_x=  5 , h_z= -1 },
        [13] = { b_x=  0 , h_x=  6 , h_z= -2 },
        [14] = { b_x=  0 , h_x=  5 , h_z= -1 },
        [15] = { b_x=  0 , h_x=  6 , h_z= -2 },
        [16] = { b_x=  0 , h_x=  5 , h_z= -1 },
        [17] = { b_x=  0 , h_x=  6 , h_z= -2 },
        [18] = { b_x=  0 , h_x=  5 , h_z= -1 },
    }
    self.move_count = 0
    self.destroycannon = nil
    self.remove_laser_hitboxes = false
    self.meteor_tiles = {}
    self.moving_dir = {}
    self.moving_tile = self:get_tile()
    self.projectiles = {}
    self.y_table = {}
    self.stored_y = 0

    -- Makes Duo stop or skip a move if stunned. Can't stop hand moving.
    self.request_for_skip = false

    self.hit_func = function()
        debug_print("Hit func runs")
        self.core_do_once = true
        self.core:hide()
        self.request_for_skip = true
        if self:get_offset().y < 0 then
            self:set_offset(idleDuoPos.x, idleDuoPos.y)
        end
        anim:set_state("BODY_IDLE")
        anim:set_playback(Playback.Loop)
        anim:refresh(self:sprite())
        anim:set_playback_speed(1)
        self.hand_anim:set_state("HAND_IDLE")
        self.hand_anim:set_playback(Playback.Loop)
        self.hand_anim:refresh(self.hand)
        self.hand_anim:set_playback_speed(1)
    end
    self:register_status_callback(Hit.Stun, self.hit_func)

    self.frames = 0
    local activity = self.pattern[self.pattern_index]
    self.update_func = function(self)
        --CHANGES PATTERN
        if self.change_pattern then
            self.change_pattern = false
            self.frames = 1 -- Resets the frame counter.
            self.pattern_index = self.pattern_index + 1
            if self.pattern_index > #self.pattern then
                reconstruct_pattern(self)
                self.pattern_index = 1
            end
            activity = self.pattern[self.pattern_index]
        end
        if activity == "MOVING" then
            -- Can be skipped if stunned.
            if self.request_for_skip then
                self.change_pattern = true
                self.request_for_skip = false
                return
            end
            if self.frames == 1 then
                --NO DEFENDING--
                self.core:show()
                self.defending = false
                self:toggle_hitbox(true)
                ----
            end
            for i=3, 11, 4 do
                if self.frames == i or self.frames == i+1 or self.frames == i+2 then
                    self:set_offset(self:get_offset().x, self:get_offset().y-1*2)
                end
            end
            if self.frames == 13 then
                --DEFENDING--
                self.core:hide()
                self.defending = true
                self:toggle_hitbox(false)
                ----
            end
            if self.frames == 15 then
                self.moving_dir = {Direction.Up, Direction.Down}
                self.moving_dir = self.moving_dir[math.random(1,#self.moving_dir)]
                if self.moving_dir == Direction.Up then 
                    self.moving_tile = self:get_tile()
                    self.moving_tile = self:get_field():tile_at(self.moving_tile:x(), self.moving_tile:y()-1)
                    if self.can_move_to_func(self.moving_tile) == false then 
                        self.moving_dir = Direction.Down
                    end
                elseif self.moving_dir == Direction.Down then
                    self.moving_tile = self:get_tile()
                    self.moving_tile = self:get_field():tile_at(self.moving_tile:x(), self.moving_tile:y()+1)
                    if self.can_move_to_func(self.moving_tile) == false then
                        self.moving_dir = Direction.Up
                    end
                end
                local dest = self:get_tile(self.moving_dir, 1)
                self:slide(dest, frames(38), frames(0), ActionOrder.Voluntary, function() 
                    debug_print("jumping started")
                end)
            end
            for i=54, 58, 2 do
                if self.frames == i then
                    self:set_offset(self:get_offset().x, self:get_offset().y+2*2)
                end
                if self.frames == i+1 then
                    self:set_offset(self:get_offset().x, self:get_offset().y+1*2)
                end
            end
            if self.frames == 59 then
                --NO DEFENDING--
                self.core:show()
                self.defending = false
                self:toggle_hitbox(true)
                ----
                self:set_offset(idleDuoPos.x, idleDuoPos.y)
                self:shake_camera(12, 0.333)
                Engine.play_audio(DUOSTOMP_AUDIO, AudioPriority.Immediate)
            end
            if self.frames == 72 then
                self.change_pattern = true
            end
        end
        if activity == "DUO PROJECTILES" then
            -- Can be skipped if stunned.
            if self.request_for_skip then
                self.change_pattern = true
                self.request_for_skip = false
                return
            end
            ----
            if self.frames == 1 then
                self.projectiles = {}
                if self:get_health() <= math.floor(self:get_max_health()/2) then
                    local r_hp2 = math.random(1,4)
                    if r_hp2 == 1 then
                        table.insert(self.projectiles, {type="Missile", target=1})
                        table.insert(self.projectiles, {type="Yura",    target=0})
                        table.insert(self.projectiles, {type="Yura",    target=0})
                    elseif r_hp2 == 2 then
                        table.insert(self.projectiles, {type="Yura",    target=0})
                        table.insert(self.projectiles, {type="Missile", target=1})
                        table.insert(self.projectiles, {type="Missile", target=2})
                    elseif r_hp2 == 3 then
                        table.insert(self.projectiles, {type="Missile", target=1})
                        table.insert(self.projectiles, {type="Yura",    target=0})
                        table.insert(self.projectiles, {type="Missile", target=2})
                    else
                        table.insert(self.projectiles, {type="Yura",    target=0})
                        table.insert(self.projectiles, {type="Missile", target=1})
                        table.insert(self.projectiles, {type="Yura",    target=0})
                    end
                else
                    local r_hp1 = math.random(1,3)
                    if r_hp1 == 1 then
                        table.insert(self.projectiles, {type="Yura",    target=0})
                    elseif r_hp1 == 2 then
                        table.insert(self.projectiles, {type="Yura",    target=0})
                        table.insert(self.projectiles, {type="Missile", target=1})
                    else
                        table.insert(self.projectiles, {type="Missile", target=1})
                        table.insert(self.projectiles, {type="Missile", target=2})
                        table.insert(self.projectiles, {type="Missile", target=3})
                    end
                end
            end
            for i=1, #self.projectiles do
                if self.frames == 1+(20*(i-1)) then
                    local field = self:get_field()
                    if self.projectiles[i].target == 1 then
                        self.y_table = {}
                        local enemies = field:find_characters(function(c)
                            return c:get_health() > 0 and not c:is_team(self:get_team())
                        end)
                        if #enemies>0 then
                            --table.insert(self.y_table, enemies[math.random(1,#enemies)]:get_tile():y())
                            table.insert(self.y_table, enemies[1]:get_tile():y())
                            local y_table = {}
                            for i=1, field:height() do
                                if i ~= self.y_table[1] then
                                    table.insert(y_table, i)
                                end
                            end
                            shuffle(y_table)
                            for i=1, #y_table do
                                table.insert(self.y_table, y_table[i])
                            end
                        else
                            for i=1, field:height() do
                                table.insert(self.y_table, i)
                            end
                            shuffle(self.y_table)
                        end
                    end
                    if self.projectiles[i].type == "Missile" then
                        create_duo_missile(self, self:get_tile(), field:tile_at(self:get_tile(self:get_facing(),1):x(),self.y_table[self.projectiles[i].target]))
                    elseif self.projectiles[i].type == "Yura" then
                        create_duo_yura(self, self:get_tile())
                    end
                end
            end
            if self.frames == 12+22*(#self.projectiles-1) then
                self.change_pattern = true
            end
        end
        if activity == "HAND OUT" then
            if self.request_for_skip then
                self.request_for_skip = false
            end
            if self.hand_pos_offset1[self.frames] ~= nil then
                if self:get_facing() == Direction.Right then
                    self:set_offset(self:get_offset().x+self.hand_pos_offset1[self.frames].b_x*2, idleDuoPos.y)
                    self.hand:set_offset(self.hand:get_offset().x-self.hand_pos_offset1[self.frames].h_x*2, self.hand:get_offset().y-self.hand_pos_offset1[self.frames].h_z*2)
                else
                    self:set_offset(self:get_offset().x-self.hand_pos_offset1[self.frames].b_x*2, idleDuoPos.y)
                    self.hand:set_offset(self.hand:get_offset().x+self.hand_pos_offset1[self.frames].h_x*2, self.hand:get_offset().y-self.hand_pos_offset1[self.frames].h_z*2)
                end
                --self.hand:set_elevation(self.hand:get_elevation()+self.hand_pos_offset1[self.frames].h_z*2)
            end
            if self.frames == 21 then
                --self:set_offset(idleDuoPos.x, idleDuoPos.y)
                --self.hand:set_offset(idleHandPos.x, idleHandPos.y)
                self.change_pattern = true
            end
        end
        if activity == "HAND IN" then
            if self.request_for_skip then
                self.request_for_skip = false
            end
            if self.hand_pos_offset2[self.frames] ~= nil then
                if self:get_facing() == Direction.Right then
                    self:set_offset(self:get_offset().x+self.hand_pos_offset2[self.frames].b_x*2, idleDuoPos.y)
                    self.hand:set_offset(self.hand:get_offset().x-self.hand_pos_offset2[self.frames].h_x*2, self.hand:get_offset().y+self.hand_pos_offset1[self.frames].h_z*2)
                else
                    self:set_offset(self:get_offset().x-self.hand_pos_offset2[self.frames].b_x*2, idleDuoPos.y)
                    self.hand:set_offset(self.hand:get_offset().x+self.hand_pos_offset2[self.frames].h_x*2, self.hand:get_offset().y+self.hand_pos_offset1[self.frames].h_z*2)
                end
                --self.hand:set_elevation(self.hand:get_elevation()+self.hand_pos_offset2[self.frames].h_z*2)
            end
            if self.frames == 41 then
                self:set_offset(idleDuoPos.x, idleDuoPos.y)
                self.hand:set_offset(idleHandPos.x, idleHandPos.y)
                self.change_pattern = true
            end
        end
        if activity == "GIANT HOOK" then
            -- Can be skipped if stunned.
            if self.request_for_skip then
                self.change_pattern = true
                self.request_for_skip = false
                return
            end
            ----
            if self.frames == 1 then
                local start_x = -3*2
                local start_y = -14*2
                local state = "GIANTHOOK_L"
                local dir = Direction.Down
                local pos_offset = {
                    [ 1] = { x=  4 , y=  7 },
                    [ 2] = { x=  4 , y=  6 },
                    [ 3] = { x=  4 , y=  8 },
                    [ 4] = { x=  1 , y=  3 },
                    [ 5] = { x=  2 , y=  8 },
                    [ 6] = { x=  2 , y=  7 },
                    [ 7] = { x=  2 , y=  8 },
                    [ 8] = { x=  1 , y=  4 },
                    [ 9] = { x=  2 , y=  7 },
                    [10] = { x=  0 , y=  8 },
                    [11] = { x=  1 , y=  8 },
                    [12] = { x=  0 , y=  4 },
                    [13] = { x=  0 , y=  7 },
                    [14] = { x=  0 , y=  8 },
                    [15] = { x= -1 , y=  8 },
                    [16] = { x=  0 , y=  4 },
                    [17] = { x=  0 , y=  0 },
                }
                local field = self:get_field()
                local start_tile_y = 0
                local start_tile_x = field:width()-1
                if self:get_facing() == Direction.Left then start_tile_x = 2 end
                local start_tile = field:tile_at(start_tile_x,start_tile_y)
                local x_start = 1
                local x_end = 2
                local x_mid = 1
                if self:get_facing() == Direction.Right then
                    x_start = field:width()
                    x_end = field:width()-1
                    x_mid = -1
                end
                create_giant_hook(self, x_start, x_end, x_mid, start_tile, start_x, start_y, state, dir, pos_offset)
            end
            if self.frames == 55 then
                local start_x = 18*2
                local start_y = -2*2
                local state = "GIANTHOOK_R"
                local dir = Direction.Up
                local pos_offset = {
                    [ 1] = { x=  0 , y=  0 },
                    [ 2] = { x=  1 , y= -7 },
                    [ 3] = { x=  1 , y= -8 },
                    [ 4] = { x=  0 , y= -4 },
                    [ 5] = { x=  0 , y= -7 },
                    [ 6] = { x=  0 , y= -8 },
                    [ 7] = { x= -1 , y= -8 },
                    [ 8] = { x=  0 , y= -4 },
                    [ 9] = { x= -1 , y= -7 },
                    [10] = { x= -2 , y= -8 },
                    [11] = { x= -2 , y= -8 },
                    [12] = { x= -1 , y= -4 },
                    [13] = { x= -2 , y= -7 },
                    [14] = { x= -3 , y= -7 },
                    [15] = { x= -3 , y= -8 },
                    [16] = { x= -2 , y= -3 },
                    [17] = { x= -4 , y= -7 },
                    [18] = { x= -4 , y= -6 },
                    [19] = { x=  0 , y=  0 },
                }
                local field = self:get_field()
                local start_tile_y = field:height()+1
                local start_tile_x = field:width()-2
                if self:get_facing() == Direction.Left then start_tile_x = 3 end
                local start_tile = field:tile_at(start_tile_x,start_tile_y)
                local x_start = 2
                local x_end = 3
                local x_mid = 1
                if self:get_facing() == Direction.Right then
                    x_start = field:width()-1
                    x_end = field:width()-2
                    x_mid = -1
                end
                create_giant_hook(self, x_start, x_end, x_mid, start_tile, start_x, start_y, state, dir, pos_offset)
            end
            if self.frames == 134 then
                self.change_pattern = true
            end
        end
        if activity == "JUSTICE FIST 1" or activity == "JUSTICE FIST 2" then
            -- Can be skipped if stunned.
            if self.request_for_skip then
                self.change_pattern = true
                self.request_for_skip = false
                return
            end
            ----
            if self.frames == 1 or (self.frames == 99 and activity == "JUSTICE FIST 2") then
                local facing_away = self:get_facing_away()
                local facing = self:get_facing()
                local field = self:get_field()
                local team = self:get_team()
                local enemy = nil
                local enemies = field:find_characters(function(c)
                    return c:get_health() > 0 and not c:is_team(team)
                end)
                if #enemies > 0 then
                    --enemy = enemies[math.random(1,#enemies)]:get_tile()
                    enemy = enemies[1]:get_tile()
                else
                    local tiles = field:find_tiles(function(t)
                        return t and not t:is_edge() and t:get_team() ~= team and t:get_state() ~= TileState.Hidden
                    end)
                    enemy = tiles[math.random(1,#tiles)]
                end
                local tiles = {}
                local dirs = {
                    [1] = {dir= Direction.None,                             ndir = nil                                       },
                    [2] = {dir= facing,                                     ndir = facing_away                               },
                    [3] = {dir= facing_away,                                ndir = nil                                       },
                    [4] = {dir= Direction.Up,                               ndir = Direction.Down                            },
                    [5] = {dir= Direction.Down,                             ndir = nil                                       },
                    [6] = {dir= Direction.join(facing,Direction.Up),        ndir = Direction.join(facing_away,Direction.Down)},
                    [7] = {dir= Direction.join(facing,Direction.Down),      ndir = Direction.join(facing_away,Direction.Up)  },
                    [8] = {dir= Direction.join(facing_away,Direction.Up),   ndir = Direction.join(facing,Direction.Down)     },
                    [9] = {dir= Direction.join(facing_away,Direction.Down), ndir = nil                                       },
                }
                local r = math.random(1,4)
                for i=1,#dirs do
                    local tile = enemy:get_tile(dirs[i].dir,1)
                    if dirs[i].ndir ~= nil then
                        tile = tile:get_tile(dirs[i].ndir,1)
                    end
                    if not tile:is_edge() and tile:get_state() ~= TileState.Hidden then
                        table.insert(tiles,tile)
                    end
                end
                enemy = tiles[math.random(1,#tiles)]
                if enemy:get_tile(facing,1):is_edge() or enemy:get_tile(facing,1):get_state() == TileState.Hidden then
                    enemy = enemy:get_tile(facing_away,1)
                end
                if enemy:get_tile(Direction.Up,1):is_edge() or enemy:get_tile(Direction.Up,1):get_state() == TileState.Hidden then
                    enemy = enemy:get_tile(Direction.Down,1)
                end
                local state = "JUSTICEFIST_R"
                if self.frames == 99 then state = "JUSTICEFIST_L" end
                create_justice_fist(self, state, enemy)
            end
            if (self.frames == 93 and activity == "JUSTICE FIST 1") or (self.frames == 191 and activity == "JUSTICE FIST 2") then
                self.change_pattern = true
            end
        end
        if activity == "DESTROY LASER" then
            -- Can be skipped if stunned OR not in the center.
            if self.request_for_skip or self:get_tile():y() <= 1 or self:get_tile():y() >= self:get_field():height() then
                self.change_pattern = true
                self.request_for_skip = false
                return
            end
            ----
            if self.frames == 1 then
                --DEFENDING--
                --self.core:hide()
                self.defending = true
                self:toggle_hitbox(false)
                ----
                Engine.play_audio(DESTROYCANNON_AUDIO, AudioPriority.Immediate)
                self.cannon:show()
                self.cannon_anim:set_state("CANNON1")
                self.cannon_anim:refresh(self.cannon)
            end
            if self.frames == 51 then
                create_destroy_laser(self, self:get_tile())
            end
            if self.frames == 216 then
                self.cannon_anim:set_state("CANNON2")
                self.cannon_anim:refresh(self.cannon)
            end
            if self.frames == 221 then
                --NO DEFENDING--
                --self.core:show()
                self.defending = false
                self:toggle_hitbox(true)
                ----
                self.cannon:hide()
            end
            if self.frames == 232 then
                self.change_pattern = true
            end
        end
        -- Attacks the furthest 3x3 area.
        if activity == "METEOR KNUCKLE" then
            -- Can be skipped if stunned.
            if self.request_for_skip then
                self.change_pattern = true
                self.request_for_skip = false
                return
            end
            ----
            if self.frames == 1 then
                local facing = self:get_facing()
                local field = self:get_field()
                local team = self:get_team()
                local x_start = 1
                local x_end = x_start+2
                local x_mid = 1
                if facing == Direction.Right then
                    x_start = field:width()
                    x_end = x_start-2
                    x_mid = -1
                end
                for x=x_start,x_end,x_mid do
                    for y=1,field:height() do
                        table.insert(self.meteor_tiles,field:tile_at(x,y))
                    end
                end
                shuffle(self.meteor_tiles)
            end
            if #self.meteor_tiles>0 then
                for i=1, #self.meteor_tiles do
                    if self.frames == 23+10*(i-1) then
                        create_meteor_knuckle(self, self.meteor_tiles[i], i)
                    end
                end
                if self.frames == 23+10*(#self.meteor_tiles-1)+32 then
                    self.change_pattern = true
                end
            else
                self.change_pattern = true
            end
        end
        if activity == "ANGER IMPACT" then
            -- Can be skipped if stunned.
            if self.request_for_skip then
                self.change_pattern = true
                self.request_for_skip = false
                return
            end
            ----
            if self.frames == 1 then
                Engine.play_audio(ANGERIMPACT_AUDIO, AudioPriority.Immediate)
                anim:set_state("BODY_ANGER1")
                anim:refresh(self:sprite())
                self.hand_anim:set_state("HAND_IDLE")
                self.hand_anim:set_playback(Playback.Loop)
                self.hand_anim:refresh(self.hand)
                self.hand_anim:set_playback_speed(0)
            end
            if self.frames == 11 then
                local anger_fx = graphic_init("artifact",  4*2, 0, ANGERIMPACT_TEXTURE, ANGERIMPACT_PALETTE, ANGERIMPACT_ANIMPATH, -3, "ANGERIMPACT1", Playback.Once, self, self:get_facing(), true, true)
                anger_fx:set_elevation(48*2)
                self:get_field():spawn(anger_fx, self:get_tile())
            end
            if self.frames == 14 then
                local anger_fx = graphic_init("artifact", 22*2, 0, ANGERIMPACT_TEXTURE, ANGERIMPACT_PALETTE, ANGERIMPACT_ANIMPATH, -3, "ANGERIMPACT1", Playback.Once, self, self:get_facing(), true, true)
                anger_fx:set_elevation(41*2)
                self:get_field():spawn(anger_fx, self:get_tile())
            end
            if self.frames == 17 then
                local anger_fx = graphic_init("artifact", -1*2, 0, ANGERIMPACT_TEXTURE, ANGERIMPACT_PALETTE, ANGERIMPACT_ANIMPATH, -3, "ANGERIMPACT2", Playback.Once, self, self:get_facing(), true, true)
                anger_fx:set_elevation(24*2)
                self:get_field():spawn(anger_fx, self:get_tile(self:get_facing(),1))
            end
            if self.frames == 20 then
                local anger_fx = graphic_init("artifact", 27*2, 0, ANGERIMPACT_TEXTURE, ANGERIMPACT_PALETTE, ANGERIMPACT_ANIMPATH, -3, "ANGERIMPACT2", Playback.Once, self, self:get_facing(), true, true)
                anger_fx:set_elevation(11*2)
                self:get_field():spawn(anger_fx, self:get_tile(self:get_facing(),1))
            end
            if self.frames == 23 then
                anim:set_state("BODY_ANGER2")
                anim:refresh(self:sprite())
                create_anger_impact(self, self:get_tile(), self:get_tile(self:get_facing(),2))
            end
            if self.frames == 47 then
                anim:set_state("BODY_IDLE")
                anim:set_playback(Playback.Loop)
                anim:refresh(self:sprite())
                self.hand_anim:set_state("HAND_IDLE")
                self.hand_anim:set_playback(Playback.Loop)
                self.hand_anim:refresh(self.hand)
                self.hand_anim:set_playback_speed(1)
            end
            if self.frames == 87 then
                self.change_pattern = true
            end
        end
        if activity == "CHOOSE JUSTICE FIST" then
            self.frames = 0 -- Resets the frame counter.
            if self:get_health() <= math.floor(self:get_max_health()/2) then
                activity = "JUSTICE FIST 2"
            else
                activity = "JUSTICE FIST 1"
            end
        end
        if activity == "CHOOSE HOOK OR ANGER" then
            self.frames = 0 -- Resets the frame counter.
            if self:get_health() <= math.floor(self:get_max_health()/2) and math.random(1,2) == 1 then
                activity = "ANGER IMPACT"
            else
                activity = "GIANT HOOK"
            end
        end
        self.frames = self.frames + 1
    end
    debug_print("done")
end

function create_collision_attack(user, obj, damage, tile)
    local spell = Battle.Spell.new(obj:get_team())
    spell:set_facing(obj:get_facing())
    local hit_props = HitProps.new()
    :dmg(damage)
    :impact()
    :flinch()
    :flash()
    :from(user:get_context())
    :elem(user:get_element())
    spell:set_hit_props(hit_props)
    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end
    spell.collision_func = function(self)
        obj:set_health(0)
    end
    spell.battle_end_func = function(self)
        self:delete()
    end
    spell.delete_func = function(self)
        self:erase()
    end
    obj:get_field():spawn(spell, tile)
end

function check_collision(user, obj, damage, tile)
    if check_characters(obj, tile) or check_obstacles_true(tile) then 
        create_collision_attack(user, obj, damage, tile)
    end
end

-- Checks for non-zero-health Obstacles.
function check_obstacles(tile)
    local ob = tile:find_obstacles(function(o)
        if o:get_animation():has_state("PASS_THROUGH") or o:get_name() == "CANTINTERACT" then
            return false
        else
            return true
        end
        return o:get_health() > 0
    end)
    return #ob > 0 
end
function check_obstacles_true(tile)
    local ob = tile:find_obstacles(function(o)
        return o:get_health() > 0
    end)
    return #ob > 0 
end

-- Checks for unfriendly Characters.
function check_characters(self, tile)
    local characters = tile:find_characters(function(c)
        return c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)
    return #characters > 0
end

-- Checks for any Characters.
function check_characters_true(tile)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0
    end)
    return #characters > 0
end