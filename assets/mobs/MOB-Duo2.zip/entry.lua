local package_id = "com.OFC.mob.EXE4-046-Duo2"
local character_id = "com.OFC.char.EXE4-046-Duo0"

function package_requires_scripts()
    Engine.requires_character(character_id)
end

function package_init(package)
    package:declare_package_id(package_id)
    package:set_name("Duo V2 (EXE4)")
    package:set_description("Test fight with\nDuo V2\nfrom Rockman EXE4")
    package:set_speed(2)
    package:set_attack(200)
    package:set_health(2500)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
    print("")
    ----
    -- Set background --
    print("Current area:","Control Area")
    local texPath = _modpath.."exe4-final.png"
    local animPath = _modpath.."exe4-final.animation"
    mob:set_background(texPath, animPath, 1, 0)
    -- Set music --
    print("Now playing:","VS. Duo")
    print('(from "Rockman EXE4: Tournament Red Sun/Blue Moon")')
    local musicPath = _modpath.."exe4-final.ogg"
    mob:stream_music(musicPath, 5964, 75714)
    -- Mod field --
    for x=5,6 do
        for y=1,3 do
            mob:get_field():tile_at(x,y):set_state(TileState.Hidden)
        end
    end
    -- Spawn mob --
    mob:create_spawner(character_id, Rank.V2):spawn_at(5,2)
    mob:enable_boss_battle()
    ----
    print("")
end