local package_id = "com.OFC.mob.EXE4-047-Forte1"
local character_id = "com.OFC.char.EXE4-047-Forte0"

function package_requires_scripts()
    Engine.requires_character(character_id)
end

function package_init(package) 
    package:declare_package_id(package_id)
    package:set_name("Forte (EXE4)")
    package:set_description("Test fight with\nForte\nfrom Rockman EXE4")
    package:set_speed(1)
    package:set_attack(100)
    package:set_health(2000)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
    print("")
    ----
    -- Set background --
    print("Current area:","Ura Internet 5")
    local texPath = _modpath.."exe4-bg-urainternet.png"
    local animPath = _modpath.."exe4-bg-urainternet.animation"
    mob:set_background(texPath, animPath, 0, 0)
    -- Set music --
    print("Now playing:","Fighting Oneself")
    print('(from "Rockman EXE4: Tournament Red Sun/Blue Moon")')
    local musicPath = _modpath.."exe4-boss.ogg"
    mob:stream_music(musicPath, 9644, 47934)
    -- Spawn mob --
    mob:create_spawner(character_id, Rank.V1):spawn_at(5,2)
    mob:enable_boss_battle()
    ----
    print("")
end