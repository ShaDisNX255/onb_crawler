local package_id = "com.OFC.mob.EXE4-047-Forte2"
local character_id = "com.OFC.char.EXE4-047-Forte0"

function package_requires_scripts()
    Engine.requires_character(character_id)
end

function package_init(package) 
    package:declare_package_id(package_id)
    package:set_name("Forte SP (EXE4)")
    package:set_description("Test fight with\nForte SP\nfrom Rockman EXE4")
    package:set_speed(2)
    package:set_attack(200)
    package:set_health(3000)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
    print("")
    ----
    -- Set background --
    print("Current area:","Black Earth 2")
    local texPath = _modpath.."exe4-bg-blackearth.png"
    local animPath = _modpath.."exe4-bg-blackearth.animation"
    mob:set_background(texPath, animPath, 0, 0)
    -- Set music --
    print("Now playing:","Fighting Oneself")
    print('(from "Rockman EXE4: Tournament Red Sun/Blue Moon")')
    local musicPath = _modpath.."exe4-boss.ogg"
    mob:stream_music(musicPath, 9644, 47934)
    -- Spawn mob --
    mob:create_spawner(character_id, Rank.SP):spawn_at(5,2)
    mob:enable_boss_battle()
    ----
    print("")
end