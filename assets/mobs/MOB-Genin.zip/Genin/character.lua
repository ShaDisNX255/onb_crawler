--[[
    TODO:
    The Genin virus family in EXE5 can see if the Player is about to attack them. If Genin is on the same row as the Player and the Player is in one of these anim states ("PLAYER_SHOOTING", "PLAYER_THROW", or "PLAYER_SWORD"), Genin attacks immediately.
    AI:
    Genin stands still for 5 seconds. Then, using a smoke bomb, teleports closer to the Player, allowing it to hit them with the Engetsu Kunai. Afterward, teleports to a random tile on his field. If the Player tries to attack Genin while standing on the same row, Genin attacks immediatly. Never teleports to a tile that is on the same row as the Player, but to a tile higher or lower. If the chosen tile is blocked by an Obstacle, teleports to a tile further away from the Obstacle.
    IGNORES Confuse or Blind.
    Doesn't use the MobTracker. If two Genins try to teleport to the same tile at the same time (or there's no any available tile), one of them moves back to their field and cancel the attack.

]]
local print_debug = false

local CHARACTER_TEXTURE = Engine.load_texture(_folderpath.."gfx/battle.grayscaled.png")
local CHARACTER_ANIMPATH = _folderpath.."gfx/battle.animation"

local ENGETSUKUNAI_TEXTURE = Engine.load_texture(_folderpath.."gfx/engetsukunai.grayscaled.png")
local ENGETSUKUNAI_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/engetsukunai.png")
local ENGETSUKUNAI_ANIMPATH = _folderpath.."gfx/engetsukunai.animation"
local ENGETSUKUNAI_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE5_138.ogg", true)

local SMOKEBOMB_TEXTURE = Engine.load_texture(_folderpath.."gfx/smokebomb.grayscaled.png")
local SMOKEBOMB_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/smokebomb.png")
local SMOKEBOMB_ANIMPATH = _folderpath.."gfx/smokebomb.animation"
local SMOKEBOMB_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE5_59.ogg", true)

local MOB_MOVE_TEXTURE = Engine.load_texture(_folderpath.."gfx/mob_move.grayscaled.png")
local MOB_MOVE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/mob_move.png")
local MOB_MOVE_ANIMPATH = _folderpath.."gfx/mob_move.animation"

local WindPush = include("libs/WindPush.lua")

function debug_print(str)
    if print_debug then
        print("[Genin] "..str)
    end
end

--possible states for character
local states = { IDLE = 1, MOVE_F = 2, ATTACK = 3, MOVE_B = 4 }

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or Playback.Once
    facing = facing or user:get_facing()
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and facing == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function create_hitbox(user, facing_away, facing, field, team, damage, tile)
	local spell = Battle.Spell.new(team)
    spell:set_facing(facing)
    spell:set_hit_props(
        HitProps.new()
        :dmg(damage)
        :impact()
        :flinch()
        :flash()
        :elem(Element.Sword)
        :from(user:get_context())
    )
	spell.update_func = function(self)
        --print("ID ("..user:get_id().."): ("..self:get_tile():x()..";"..self:get_tile():y()..")")
        self:get_tile():attack_entities(self)
		self:delete()
    end
    spell.attack_func = function(self, other)
    end
    spell.battle_end_func = function(self)
		self:delete()
    end
    spell.delete_func = function(self)
		self:erase()
    end
    spell.can_move_to_func = function(tile)
        return true
    end
	field:spawn(spell, tile)
    return spell
end

local function create_slash(user, facing_away, facing, field, team, damage, tile)
	local spell = graphic_init("spell", 0, 0, ENGETSUKUNAI_TEXTURE, ENGETSUKUNAI_PALETTE, ENGETSUKUNAI_ANIMPATH, -3, "0", Playback.Once, user, facing)
    local frame = 1
	local clockwise_path = {
		[1] = facing,
		[2] = Direction.join(facing, Direction.Down),
		[3] = Direction.Down,
		[4] = Direction.join(facing_away, Direction.Down),
		[5] = facing_away,
		[6] = Direction.join(facing_away, Direction.Up),
		[7] = Direction.Up,
		[8] = Direction.join(facing, Direction.Up),
	}
	spell.update_func = function(self)
        --[[
		local tile = self:get_tile()
        if tile ~= user:get_tile() then
            self:teleport(tile, ActionOrder.Immediate)
        end]]
        if clockwise_path[frame] ~= nil then
            create_hitbox(user, facing_away, facing, field, team, damage, tile:get_tile(clockwise_path[frame], 1))
        else
			spell:delete()
            return
        end
		frame = frame + 1
	end
    spell.battle_end_func = function(self)
		self:delete()
    end
    spell.delete_func = function(self)
		self:erase()
    end
    spell.can_move_to_func = function(tile)
        return true
    end
	field:spawn(spell, tile)
    return spell
end

function package_init(self, character_info)
    -- Required function, main package information
    self.texture = CHARACTER_TEXTURE
    self.animation = self:get_animation()
    self.animation:load(CHARACTER_ANIMPATH)
    -- Load extra resources
    -- Set up character meta
    -- Common Properties
    self:set_name(character_info.name)
    self:set_health(character_info.health)
    self:set_element(character_info.element)
    self:set_texture(self.texture, true)
    self:set_height(39)
    self:set_float_shoe(false)
    self:set_air_shoe(false)
    self:share_tile(false)
    self:set_explosion_behavior(2, 1, false)
    self:set_offset(0,0)
    self:store_base_palette(Engine.load_texture(_folderpath.."gfx/palette/battle-"..self:get_rank()..".png"))
    self:set_palette(self:get_base_palette())
    self.damage = character_info.damage
    -- Genin Specific
    self.damage_engetsukunai = character_info.damage_engetsukunai
    self.idle_delay = character_info.idle_delay
    self.attack_frame = character_info.attack_frame
    self.attack_end_frame = character_info.attack_end_frame
    -- Other Setup
    self.collision_available = true
    self.attacked = false
    -- entity will spawn with this animation.
    self.animation:set_state("SPAWN")
    --self.animation:refresh(self:sprite())
    self.frame_counter = 0
    self.started = false
    self.is_deleting = false
    -- This defense rule is added to prevent enemy from gaining invincibility after taking damage.
    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)
    -- Can't be Dragged.
    self.guarding = true
    self.defense_rule = Battle.DefenseRule.new(1, DefenseOrder.Always)
    local ref = self
    self.defense_rule.filter_statuses_func = function(statuses)
		statuses.flags = statuses.flags & ~Hit.Flash
		if ref.state ~= states.IDLE then
		    statuses.flags = statuses.flags & ~Hit.Drag
        end
		return statuses
	end
    self:add_defense_rule(self.defense_rule)

    local ref = self
    self.counterable_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.counterable_component.timer = 0
    self.counterable_component.update_func = function(self)
        if self.timer > 0 then
            debug_print("COUNTERABLE")
            self.timer = self.timer - 1
            ref:toggle_counter(true)
        else
            ref:toggle_counter(false)
        end
    end
    self:register_component(self.counterable_component)
    self.hit_func = function(from_stun)
        debug_print("Hit func runs")
        self.counterable_component.timer = 0
        self:toggle_counter(false)
    end
    self.on_countered = function(self)
        debug_print("Countered")
        self.hit_func(true)
    end
    self:register_status_callback(Hit.Stun, function() self.hit_func(true) end)
    self:register_status_callback(Hit.Freeze, function() self.hit_func(true) end)

    self.slide_component = nil

    self.move_cancelled = false
    self.can_move_to_team = false
    self.original_tile = nil
    self.reserving = false
    self.can_move_to_func = function(tile)
        --if self:is_rooted() then return false end
        if tile:is_hole() then
            return false
        end
        if not self.can_move_to_team and tile:get_team() ~= self:get_team() then
            return false
        end
        -- Can't move to reserved tiles.
        if(tile:is_reserved({self:get_id()})) then
            return false
        end
        if tile == self:get_tile() then
            return true
        end
        return not check_obstacles(tile) and not check_characters_true(tile)
    end
    -- Code that runs in the default state
    ---@param frame number
    self.action_idle = function(frame)
        if frame == 1 then
            debug_print("IDLE")
            self:toggle_hitbox(true)
            self.animation:set_state("PLAYER_IDLE")
            self.animation:set_playback(Playback.Loop)
        end
        local enemies = self:get_field():find_characters(function(c)
            return c:get_health() > 0 and not c:is_team(self:get_team()) and c:get_tile():y() == self:get_tile():y()
            and (c:get_animation():get_state() == "PLAYER_SHOOTING"
            or   c:get_animation():get_state() == "PLAYER_SHOOTING2"
            or   c:get_animation():get_state() == "PLAYER_CANNON"
            or   c:get_animation():get_state() == "PLAYER_SWORD"
            or   c:get_animation():get_state() == "PLAYER_THROW"
            or   c:get_animation():get_state() == "PLAYER_ATTACK"
            or   c:get_animation():get_state() == "ATTACK"
            or   c:get_animation():get_state() == "ATTACKING"
            or   c:get_animation():get_state() == "ATTACK_START")
        end)
        if frame >= self.idle_delay or #enemies>0 then
            self.set_state(states.MOVE_F)
        end
    end

    ---@param frame number
    self.action_move_f = function(frame)
        local field = self:get_field()
        if frame == 1 then
            debug_print("MOVE_F")
            WindPush.make_entity_immune_to_status(self)
            self.can_move_to_team = true
            self.animation:set_state("INVISIBLE")
            self:toggle_hitbox(false)
            self:hide()
            local smoke_fx = graphic_init("artifact", 0, 0, SMOKEBOMB_TEXTURE, SMOKEBOMB_PALETTE, SMOKEBOMB_ANIMPATH, -999, "0", Playback.Once, self, self:get_facing(), true, true, true)
            smoke_fx:set_elevation(16*2)
            field:spawn(smoke_fx, self:get_tile())
            Engine.play_audio(SMOKEBOMB_AUDIO, AudioPriority.Immediate)
        end
        if frame == 9 then
            local enemies = field:find_nearest_characters(self, function(c)
                return c:get_health()>0 and not c:is_team(self:get_team())
            end)
            local tiles_to_move = {}
            if #enemies > 0 then
                for i=1,field:width() do
                    local tile0 = enemies[1]:get_tile(Direction.Up,1)
                    local tile = tile0:get_tile(self:get_facing_away(),i)
                    if tile and check_characters_true(tile) then
                        break
                    else
                        if tile and self.can_move_to_func(tile) then
                            table.insert(tiles_to_move, tile)
                            break
                        end
                    end
                end
                for i=1,field:width() do
                    local tile0 = enemies[1]:get_tile(Direction.Down,1)
                    local tile = tile0:get_tile(self:get_facing_away(),i)
                    if tile and check_characters_true(tile) then
                        break
                    else
                        if tile and self.can_move_to_func(tile) then
                            table.insert(tiles_to_move, tile)
                            break
                        end
                    end
                end
            end
            if #enemies == 0 or #tiles_to_move == 0 then
                self.move_cancelled = true
                self.set_state(states.MOVE_B)
            else
                self.original_tile = self:get_tile()
                self.reserving = true
                self:teleport(tiles_to_move[math.random(1,#tiles_to_move)], ActionOrder.Immediate)
                self.set_state(states.ATTACK)
            end
        end
    end
    
    ---@param frame number
    self.action_attack = function(frame)
        if self.reserving then
            self.original_tile:reserve_entity_by_id(self:get_id())
        end
        local field = self:get_field()
        if frame == 1 then
            debug_print("ATTACK")
            local move_fx = graphic_init("artifact", 0, 0, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, -999, "3", Playback.Once, self, self:get_facing(), true, true, true)
            move_fx:set_elevation(16*2)
            field:spawn(move_fx, self:get_tile())
        end
        if frame == 3 then
            self:reveal()
            self.animation:set_state("INVISIBLE")
        end
        if frame == 4 then
            self:toggle_hitbox(true)
            self.animation:set_state("READY")
        end
        if frame == self.attack_frame-15 then
            self.counterable_component.timer = 15 -- Becomes counterable for 15 frames.
        end
        if frame == self.attack_frame then
            self.animation:set_state("ATTACKING")
            self.animation:set_playback(Playback.Loop)
            Engine.play_audio(ENGETSUKUNAI_AUDIO, AudioPriority.Immediate)
            create_slash(self, self:get_facing_away(), self:get_facing(), self:get_field(), self:get_team(), self.damage_engetsukunai, self:get_tile())
        end
        if frame == self.attack_frame+8 then
            self.animation:set_state("ATTACK_END")
        end
        if frame == self.attack_end_frame then
            WindPush.remove_immunity(self)
            self.can_move_to_team = false
            self.animation:set_state("INVISIBLE")
            self:toggle_hitbox(false)
            self:hide()
            local smoke_fx = graphic_init("artifact", 0, 0, SMOKEBOMB_TEXTURE, SMOKEBOMB_PALETTE, SMOKEBOMB_ANIMPATH, -999, "0", Playback.Once, self, self:get_facing(), true, true, true)
            smoke_fx:set_elevation(16*2)
            field:spawn(smoke_fx, self:get_tile())
        end
        if frame >= self.attack_end_frame+27 then
            self.set_state(states.MOVE_B)
        end
    end
    
    ---@param frame number
    self.action_move_b = function(frame)
        local field = self:get_field()
        if frame == 1 then
            debug_print("MOVE_B")
            self.can_move_to_team = false
            if self.move_cancelled then
                self.move_cancelled = false
            else
                local tiles = {}
                local enemies = field:find_characters(function(c)
                    return c:get_health()>0 and not c:is_team(self:get_team())
                end)
                for i=1,#enemies do
                    local tiles1 = field:find_tiles(function(t)
                        return t and t:y() ~= i and self.can_move_to_func(t)
                    end)
                    for j=1,#tiles1 do
                        table.insert(tiles,tiles1[j])
                    end
                end
                if #tiles == 0 then
                    tiles = field:find_tiles(function(t)
                        return t and self.can_move_to_func(t)
                    end)
                end
                local new_tile = tiles[math.random(1,#tiles)]
                self:get_tile():remove_entity_by_id(self:get_id())
                if self.original_tile then
                    self.original_tile:remove_entity_by_id(self:get_id())
                    self.original_tile = nil
                end
                new_tile:add_entity(self)
            end
            --
            local move_fx = graphic_init("artifact", 0, 0, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, -999, "3", Playback.Once, self, self:get_facing(), true, true, true)
            move_fx:set_elevation(16*2)
            field:spawn(move_fx, self:get_tile())
        end
        if frame == 3 then
            self:reveal()
            self.animation:set_state("INVISIBLE")
        end
        if frame >= 4 then
            self.set_state(states.IDLE)
        end
    end

    --utility to set the update state, and reset frame counter
    ---@param state number
    self.set_state = function(state)
        self.state = state
        self.frame_counter = 0
    end
    -- actions for states
    local actions = { [1] = self.action_idle, [2] = self.action_move_f, [3] = self.action_attack, [4] = self.action_move_b }
    self.current_name = self:get_name()
    self.on_spawn_func = function(self)
        debug_print("on_spawn_func called")
        if character_info.name_on_spawn then
            self:set_name(character_info.name)
        end
    end
    self.battle_start_func = function()
    end
    self.delete_func = function()
        self.is_deleting = true
    end
    self.update_func = function()
        self.frame_counter = self.frame_counter + 1
        if not self.started then
            self.started = true
            self.set_state(states.IDLE)
        else
            local action_func = actions[self.state]
            action_func(self.frame_counter)
        end
        -- collision hitbox
        check_collision(self, self.damage)
    end
end

function create_collision_attack(user, damage, tile)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(user:get_facing())
    spell:set_hit_props(
        HitProps.new()
        :dmg(damage)
        :impact()
        :flinch()
        :flash()
        --:breaking()
        :from(user:get_context())
        :elem(user:get_element())
    )
    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end
    user:get_field():spawn(spell, tile)
    return spell
end

function check_collision(user, damage)
    local t = user:get_tile()
    if user.collision_available and check_characters(t, user) then 
        create_collision_attack(user, damage, t)
    end
end

-- Checks for non-zero-health Obstacles.
function check_obstacles(tile)
    local ob = tile:find_obstacles(function(o)
        if o:get_animation():has_state("PASS_THROUGH") or o:get_name() == "CANTINTERACT" then
            return false
        else
            return true
        end
        return o:get_health() > 0
    end)
    return #ob > 0 
end

-- Checks for unfriendly Characters.
function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)
    return #characters > 0
end

-- Checks for any Characters.
function check_characters_true(tile)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0
    end)
    return #characters > 0
end

function check_characters_true_team(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_tile():get_team() == self:get_tile():get_team()
    end)
    return #characters > 0
end

return package_init