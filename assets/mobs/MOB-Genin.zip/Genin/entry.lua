local shared_package_init = include("../Genin/character.lua")

function package_init(character)
    local character_info = {
        name = "Genin",
        name_on_spawn = true,
        health = 100,
        damage = 30,
        element = Element.None,
        damage_engetsukunai = 30,
        idle_delay = 212,
        attack_frame = 43,
        attack_end_frame = 97,
    }
    if character:get_rank() == Rank.V2 then
        character_info.name = "GeninEX"
        character_info.health = 140
        character_info.damage = 60
        character_info.damage_engetsukunai = 50
        character_info.attack_frame = 38
        character_info.attack_end_frame = 87
    elseif character:get_rank() == Rank.V3 then
        character_info.name = "Chuenin"
        character_info.health = 180
        character_info.damage = 90
        character_info.damage_engetsukunai = 90
        character_info.attack_frame = 35
        character_info.attack_end_frame = 79
    elseif character:get_rank() == Rank.SP then
        character_info.name = "ChueninEX"
        character_info.health = 220
        character_info.damage = 120
        character_info.damage_engetsukunai = 120
        character_info.attack_frame = 33
        character_info.attack_end_frame = 72
    elseif character:get_rank() == Rank.Rare1 then
        character_info.name = "Joenin"
        character_info.health = 270
        character_info.damage = 160
        character_info.damage_engetsukunai = 160
        character_info.attack_frame = 31
        character_info.attack_end_frame = 65
    elseif character:get_rank() == Rank.Rare2 then
        character_info.name = "JoeninEX"
        character_info.health = 330
        character_info.damage = 200
        character_info.damage_engetsukunai = 200
        character_info.attack_frame = 28
        character_info.attack_end_frame = 57
    else
        character_info.name_on_spawn = false
    end
    shared_package_init(character,character_info)
end