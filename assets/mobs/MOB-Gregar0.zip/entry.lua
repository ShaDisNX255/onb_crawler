local package_id = "com.OFC.mob.EXE6-048-Gregar0"
local character_id = "com.OFC.char.EXE6-048-Gregar0"

function package_requires_scripts()
    Engine.define_character(character_id, _modpath.."Gregar")
end

function package_init(package) 
    package:declare_package_id(package_id)
    package:set_name("Gregar (EXE6)")
    package:set_description("MAIN MOB PACKAGE")
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
    mob:create_spawner(character_id, Rank.V1):spawn_at(5,2)
end  