local package_id = "com.OFC.mob.EXE6-048-Gregar2"
local character_id = "com.OFC.char.EXE6-048-Gregar0"

function package_requires_scripts()
    Engine.requires_character(character_id)
end

function package_init(package)
    package:declare_package_id(package_id)
    package:set_name("Gregar SP (EXE6)")
    package:set_description("Test fight with\nGregar SP\nfrom Rockman EXE6")
    package:set_speed(3)
    package:set_attack(315)
    package:set_health(4000)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
    print("")
    ----
    -- Set background --
    print("Current area:","Copyroid's Cyber")
    local texPath = _modpath.."exe6-copyroiddennou.png"
    local animPath = _modpath.."exe6-copyroiddennou.animation"
    mob:set_background(texPath, animPath, 0, -0.125)
    -- Set music --
    print("Now playing:","Decisive Battle, Cyber Beasts!")
    print('(from "Rockman EXE6: Cyber Beast Gregar/Falzar")')
    local musicPath = _modpath.."exe6-final.ogg"
    mob:stream_music(musicPath, 8406, 54665)
    -- Spawn mob --
    mob:create_spawner(character_id, Rank.SP):spawn_at(5, 2)
    mob:enable_boss_battle()
    ----
    print("")
end