local package_id = "com.OFC.mob.EXE6-051-GregarBeast0"
local character_id = "com.OFC.char.EXE6-051-GregarBeast0"

function package_requires_scripts()
    Engine.define_character(character_id, _modpath.."GregarBeast")
end

function package_init(package)
    package:declare_package_id(package_id)
    package:set_name("Gregar Beast (EXE6)")
    package:set_description("MAIN MOB PACKAGE")
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
    mob:create_spawner(character_id, Rank.V1):spawn_at(5,2)
end