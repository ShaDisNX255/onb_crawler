local package_id = "com.OFC.mob.EXE6-051-GregarBeast1"
local character_id = "com.OFC.char.EXE6-051-GregarBeast0"

function package_requires_scripts()
    Engine.requires_character(character_id)
end

function package_init(package) 
    package:declare_package_id(package_id)
    package:set_name("Gregar Beast (EXE6)")
    package:set_description("Test fight with\nGregar Beast\nfrom Rockman EXE6")
    package:set_speed(1)
    package:set_attack(30)
    package:set_health(900)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
    print("")
    ----
    -- Set background --
    print("Current area:","Underground 2")
    local texPath = _modpath.."exe6-underground.png"
    local animPath = _modpath.."exe6-underground.animation"
    mob:set_background(texPath, animPath, 0, 0)
    -- Set music --
    print("Now playing:","Surge of Power!")
    print('(from "Rockman EXE6: Cyber Beast Gregar/Falzar")')
    local musicPath = _modpath.."exe6-boss.ogg"
    mob:stream_music(musicPath, 6833, 58267)
    -- Spawn mob --
    mob:create_spawner(character_id, Rank.V1):spawn_at(5,2)
    mob:enable_boss_battle()
    ----
    print("")
end