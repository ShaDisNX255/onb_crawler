local package_id = "com.OFC.mob.EXE6-051-GregarBeast2"
local character_id = "com.OFC.char.EXE6-051-GregarBeast0"

function package_requires_scripts()
    Engine.requires_character(character_id)
end

function package_init(package) 
    package:declare_package_id(package_id)
    package:set_name("Gregar Beast SP (EXE6)")
    package:set_description("Test fight with\nGregar Beast SP\nfrom Rockman EXE6")
    package:set_speed(3)
    package:set_attack(160)
    package:set_health(1800)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
    print("")
    ----
    -- Set background --
    local background = "RANDOM" --[[
        RANDOM - random area
        GRAVE - Graveyard 1 (EXE6 only)
        UNDER - Underground 2 (BN6 only)
    ]]
    if background == "RANDOM" then
        print("Background Randomizer ON")
    else
        print("Background Randomizer OFF")
    end
    local r = math.random(1,2)
    if     background == "GRAVE" or (background == "RANDOM" and r==1) then
        local texPath = _modpath.."exe6-graveyard.png"
        local animPath = _modpath.."exe6-graveyard.animation"
        print("Current area:","Graveyard 1")
        mob:set_background(texPath, animPath, -0.0295, 0)
    elseif background == "UNDER" or (background == "RANDOM" and r==2) then
        local texPath = _modpath.."exe6-underground.png"
        local animPath = _modpath.."exe6-underground.animation"
        print("Current area:","Underground 1")
        mob:set_background(texPath, animPath, 0, 0)
    end
    -- Set music --
    print("Now playing:","Surge of Power!")
    print('(from "Rockman EXE6: Cyber Beast Gregar/Falzar")')
    local musicPath = _modpath.."exe6-boss.ogg"
    mob:stream_music(musicPath, 6833, 58267)
    -- Spawn mob --
    mob:create_spawner(character_id, Rank.SP):spawn_at(5,2)
    mob:enable_boss_battle()
    ----
    print("")
end