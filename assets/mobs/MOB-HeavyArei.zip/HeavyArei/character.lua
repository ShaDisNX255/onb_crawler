--[[

    CUSTOM BEHAVIOR:
    if Confused or Blind, can't find the player.
    if Rooted, can't move.

]]
local is_counterable = true
local print_debug = false

local CHARACTER_TEXTURE = Engine.load_texture(_folderpath.."gfx/battle.grayscaled.png")
local CHARACTER_ANIMPATH = _folderpath.."gfx/battle.animation"
local SHADOW_TEXTURE = Engine.load_texture(_folderpath.."gfx/battle_shadow.png")

local MOB_MOVE_TEXTURE = Engine.load_texture(_folderpath.."gfx/mob_move.grayscaled.png")
local MOB_MOVE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/mob_move.png")
local MOB_MOVE_ANIMPATH = _folderpath.."gfx/mob_move.animation"

local ATTACK_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE3_216.ogg", true)

local WindPush = include("libs/WindPush.lua")
-- Mob Tracker
local MobTracker = include("libs/mob_tracker.lua")
local left_mob_tracker = MobTracker:new()
local right_mob_tracker = MobTracker:new()

function debug_print(id,str)
    if print_debug then
        print("[HeavyArei] (ID: "..id:get_id()..") "..str)
    end
end

--possible states for character
local states = { IDLE = 1, MOVING = 2, ATTACK = 3, MOVE_BACK = 4 }

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or Playback.Once
    facing = facing or user:get_facing()
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and facing == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

function get_tracker_from_direction(facing)
    if facing == Direction.Left then
        return left_mob_tracker
    elseif facing == Direction.Right then
        return right_mob_tracker
    end
end

function advance_a_turn_by_facing(facing)
    local mob_tracker = get_tracker_from_direction(facing)
    return mob_tracker:advance_a_turn()
end

function get_active_mob_id_for_same_direction(facing)
    local mob_tracker = get_tracker_from_direction(facing)
    return mob_tracker:get_active_mob()
end

function add_enemy_to_tracking(enemy)
    local facing = enemy:get_facing()
    local id = enemy:get_id()
    local mob_tracker = get_tracker_from_direction(facing)
    mob_tracker:add_by_id(id)
end

function remove_enemy_from_tracking(enemy)
    local facing = enemy:get_facing()
    local id = enemy:get_id()
    local mob_tracker = get_tracker_from_direction(facing)
    mob_tracker:remove_by_id(id)
end

local function move_slide(self, facing, frames1, direction)
    WindPush.make_entity_immune_to_status(self)
    self.slide_component = Battle.Component.new(self, Lifetimes.Local)
    local cur_tile = 1
    local self_tile = self:get_tile()
    local tileWidthO = self_tile:width()
    local tileHeightO = self_tile:height()
    local tileWidth = tileWidthO/2
    local tileHeight = tileHeightO/2 - tileHeightO/10
    local offset_x = self:get_offset().x
    local offset_y = self:get_offset().y
    local wait_delay = 0
    local round = function(val)
        if facing == Direction.Right then
            return math.floor(val)
        else
            return math.ceil(val)
        end
    end
    local cancel_move = function()
        WindPush.remove_immunity(self)
        self.slide_component:eject()
        self.slide_component = nil
        self:set_offset(0,0)
    end
    self.slide_component.update_func = function()
        if self:is_bubbled() then
            cancel_move()
            return
        end
        if self:is_stunned() or self:is_frozen() or self:is_rooted() or self.is_deleting then return end
        ----
        local frames = frames1
        if self:is_confused() or self:is_blind() then
            frames = math.floor(frames1*2)
        end
        local round_x = 0
        local round_y = 0
        if direction == Direction.Up then
            offset_y = offset_y - tileHeightO/frames
            round_y = round(offset_y)
            if round_y <= 0 and cur_tile == 2 then
                cancel_move()
                return
            end
            if round_y < -tileHeight and cur_tile == 1 then
                self:teleport(self:get_tile(Direction.Up,1), ActionOrder.Immediate)
                round_y = (tileHeight+(round_y+tileHeight))
                offset_y = round_y
                cur_tile = 2
            end
        elseif direction == Direction.Down then
            offset_y = offset_y + tileHeightO/frames
            round_y = round(offset_y)
            if round_y >= 0 and cur_tile == 2 then
                cancel_move()
                return
            end
            if round_y > tileHeight and cur_tile == 1 then
                self:teleport(self:get_tile(Direction.Down,1), ActionOrder.Immediate)
                round_y = -(tileHeight-(round_y-tileHeight))
                offset_y = round_y
                cur_tile = 2
            end
        elseif direction == Direction.Left then
            offset_x = offset_x - tileWidthO/frames
            round_x = round(offset_x)
            if round_x <= 0 and cur_tile == 2 then
                cancel_move()
                return
            end
            if round_x < -tileWidth and cur_tile == 1 then
                self:teleport(self:get_tile(Direction.Left,1), ActionOrder.Immediate)
                round_x = (tileWidth+(round_x+tileWidth))
                offset_x = round_x
                cur_tile = 2
            end
        elseif direction == Direction.Right then
            offset_x = offset_x + tileWidthO/frames
            round_x = round(offset_x)
            if round_x >= 0 and cur_tile == 2 then
                cancel_move()
                return
            end
            if round_x > tileWidth and cur_tile == 1 then
                self:teleport(self:get_tile(Direction.Right,1), ActionOrder.Immediate)
                round_x = -(tileWidth-(round_x-tileWidth))
                offset_x = round_x
                cur_tile = 2
            end
        elseif direction == nil then
            wait_delay = wait_delay + 1
            if wait_delay >= frames1 then
                self.slide_component:eject()
                self.slide_component = nil
            end
            return
        end
        self:set_offset(round_x,round_y)
    end
    self:register_component(self.slide_component)
end

function package_init(self, character_info)
    -- Required function, main package information
    self.texture = CHARACTER_TEXTURE
    self.anim = self:get_animation()
    self.anim:load(CHARACTER_ANIMPATH)
    -- Load extra resources
    -- Set up character meta
    -- Common Properties
    self:set_name(character_info.name)
    self:set_health(character_info.health)
    self:set_element(character_info.element)
    self:set_texture(self.texture, true)
    self:set_height(48)
    self:set_float_shoe(true)
    self:set_air_shoe(true)
    self:share_tile(false)
    self:set_explosion_behavior(2, 1, false)
    self:set_offset(0,0)
    self:store_base_palette(Engine.load_texture(_folderpath.."gfx/palette/battle-"..self:get_rank()..".png"))
    self:set_palette(self:get_base_palette())
    self.damage = character_info.damage
    -- Heavy Arei Specific
    self.damage_waindo = character_info.damage_waindo
    self.frames_speed = character_info.frames_speed
    self.attack_speed = character_info.attack_speed
    self.frames_between_actions = character_info.frames_between_actions
    -- Other Setup
    self.collision_available = true
    -- entity will spawn with this animation.
    self.anim:set_state("SPAWN")
    --self.anim:refresh(self:sprite())
    self.frame_counter = 0
    self.started = false
    self.is_deleting = false
    self.move_counter = 0
    -- This defense rule is added to prevent enemy from gaining invincibility after taking damage.
    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)
    self.defense_rule = Battle.DefenseRule.new(1, DefenseOrder.Always)
    local ref = self
    self.defense_rule.filter_statuses_func = function(statuses)
        if ref.anim:get_state() == "ATTACK" then
		    statuses.flags = statuses.flags & ~Hit.Drag
        end
		statuses.flags = statuses.flags & ~Hit.Flash
		return statuses
	end
    self:add_defense_rule(self.defense_rule)
    self.reserving_obstacle = Battle.Obstacle.new(self:get_team())

    local ref = self
    self.counterable_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.counterable_component.timer = 0
    self.counterable_component.update_func = function(self)
        if self.timer > 0 and is_counterable then
            debug_print(ref,"COUNTERABLE")
            self.timer = self.timer - 1
            ref:toggle_counter(true)
        else
            ref:toggle_counter(false)
        end
    end
    self:register_component(self.counterable_component)
    self.hit_func = function(from_stun)
        debug_print(ref,"Hit func runs")
        self.counterable_component.timer = 0
        self:toggle_counter(false)
    end
    self.on_countered = function(self)
        debug_print(ref,"Countered")
        self.hit_func(true)
    end
    self:register_status_callback(Hit.Stun, function() self.hit_func(true) end)
    self:register_status_callback(Hit.Freeze, function() self.hit_func(true) end)

    self.slide_component = nil
    self.prev_tile = nil
    self.next_tile = nil

    self.can_move_to_func = function(tile, move_to_enemy)
        --if self:is_rooted() then return false end
        if not tile or tile:is_edge() then
            return false
        end
        if tile:get_team() ~= self:get_team() then
            if not move_to_enemy and self.state ~= states.MOVING and self.state ~= states.ATTACK then
                return false
            end
        end
        -- Can't move to reserved tiles.
        if tile:is_reserved({self:get_id(),self.reserving_obstacle:get_id()}) and self.anim:get_state() ~= "ATTACK" then
            return false
        end
        if tile == self:get_tile() then
            return true
        end
        if self:is_sliding() then
            return not check_obstacles(tile) and not check_characters_true(tile)
        end
        if self.anim:get_state() == "ATTACK" then
            return true
        else
            return not check_obstacles(tile) and not check_characters_true(tile)
        end
    end

    self.move_state = "MOVING"
    self.move_index = 1
    self.tile_traveled = 1
    self.offset_y = 0

    self.attack_timer = 0
    self.move_dir = Direction.Down
    self.atk_dir = nil
    self.dir_m = 0
    self.orig_offset = {}
    -- Code that runs in the default state
    ---@param frame number
    self.action_idle = function(frame)
        local facing = self:get_facing()
        local field = self:get_field()
        local team = self:get_team()
        local id = self:get_id()
        local active_mob_id = get_active_mob_id_for_same_direction(facing)
        if frame == 1 then
            if self.anim:get_state() ~= "PLAYER_IDLE" then
                self.anim:set_state("PLAYER_IDLE")
                self.anim:set_playback(Playback.Loop)
            end
            self.tile_traveled = 1
        end
        --[[
        if active_mob_id == id then
            if self.attack_timer < self.frames_between_actions then
                self.attack_timer = self.attack_timer + 1
            end
        end]]
        if self:get_tile() == self.next_tile then
            self.next_tile:remove_entity_by_id(self.reserving_obstacle:get_id())
        end
        if not self.slide_component and not self:is_sliding() and not self:is_rooted() then
            local tile = self:get_tile(self.move_dir,1)
            if not self.can_move_to_func(tile) then
                if active_mob_id == id and self.tile_traveled > 14 and not self.slide_component and not self:is_sliding() and not self:is_blind() and not self:is_confused() then
                    debug_print(self,"search for enemy")
                    local tile = nil
                    local enemies = field:find_nearest_characters(self, function(c)
                        return not c:is_team(team)
                    end)
                    if #enemies>0 then
                        debug_print(self,"enemies around")
                        if enemies[1]:get_tile():y() <= 1 then
                            debug_print(self,"set tile for search")
                            tile = field:tile_at(enemies[1]:get_tile():x(),field:height())
                            self.atk_dir = Direction.Up
                            self.dir_m = -1
                        else
                            debug_print(self,"set tile for search")
                            tile = field:tile_at(enemies[1]:get_tile():x(),1)
                            self.atk_dir = Direction.Down
                            self.dir_m = 1
                        end
                    end
                    local tile2 = nil
                    if tile then
                        debug_print(self,"SEARCHING")
                        for i=0,field:height() do
                            local tile = tile:get_tile(self.atk_dir,i)
                            debug_print(self,"tile: ("..tile:x()..";"..tile:y()..")")
                            if self.can_move_to_func(tile, true) then
                                debug_print(self,"SPOTTED")
                                tile2 = tile
                                break
                            end
                        end
                    end
                    if tile2 then
                        debug_print(self,"ENEMY FOUND")
                        self.prev_tile = self:get_tile()
                        self.next_tile = tile2
                        self.attack_timer = 0
                        self.set_state(states.MOVING)
                        return
                    end
                else
                    tile = nil
                    --self:slide(self.next_tile, frames(0), frames(5), ActionOrder.Voluntary)
                    move_slide(self, facing, 5)
                    self.move_dir = Direction.reverse(self.move_dir)
                    --[[
                    tile = self:get_tile(self.move_dir,1)
                    if not self.can_move_to_func(tile) then
                        tile = nil
                    end]]
                end
            end
            if tile then
                self.next_tile = tile
                self.next_tile:reserve_entity_by_id(self.reserving_obstacle:get_id())
                self.next_tile:reserve_entity_by_id(self:get_id())
                --[[
                self:slide(self.next_tile, frames(self.frames_speed), frames(0), ActionOrder.Voluntary, function()
                    if active_mob_id == id then self.tile_traveled = self.tile_traveled + 1 end
                end)]]
                move_slide(self, facing, self.frames_speed, self.move_dir)
                if active_mob_id == id then self.tile_traveled = self.tile_traveled + 1 end
            end
        end
        --[[
        if frame == self.frames_between_actions then
            self.move_counter = self.move_counter + 1
            if not self:is_rooted() then
                self.prev_tile = self:get_tile()
                local tile = choose_move(self)
                self.next_tile = tile
                self.next_tile:reserve_entity_by_id(self.reserving_obstacle:get_id())
                self.next_tile:reserve_entity_by_id(self:get_id())
                local move_fx = graphic_init("artifact", 0, 0, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, -999, "0", Playback.Once, self, facing, true, true, true)
                move_fx:set_elevation(16*2)
                field:spawn(move_fx, self.prev_tile)
                self.anim:set_state("WARP1")
                self.anim:on_complete(function()
                    self:teleport(self.next_tile, ActionOrder.Voluntary, function()
                        local move_fx = graphic_init("artifact", 0, 0, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, -999, "1", Playback.Once, self, facing, true, true, true)
                        move_fx:set_elevation(16*2)
                        field:spawn(move_fx, self.next_tile)
                    end)
                    self.anim:set_state("WARP2")
                    self.anim:on_complete(function()
                        if (self.move_counter < 5) then
                            self.set_state(states.IDLE)
                        else
                            self.set_state(states.SEEK)
                            self.move_counter = 0
                        end
                    end)
                end)
            else
                if (self.move_counter < 5) then
                    self.set_state(states.IDLE)
                else
                    self.set_state(states.SEEK)
                    self.move_counter = 0
                end
            end
        end]]
    end
    ---@param frame number
    self.action_moving = function(frame)
        local facing = self:get_facing()
        local field = self:get_field()
        self.prev_tile:reserve_entity_by_id(self.reserving_obstacle:get_id())
        self.prev_tile:reserve_entity_by_id(self:get_id())
        if frame == 1 then
            WindPush.make_entity_immune_to_status(self)
            self:hide()
            self.orig_offset = {[1]={x=self:get_offset().x,y=self:get_offset().y}}
            local move_fx = graphic_init("artifact", 0, 0, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, -99, "0", Playback.Once, shake, facing, true, true, true)
            move_fx:set_elevation(20*2)
            field:spawn(move_fx, self:get_tile())
            self.anim:set_state("ATTACK")
            self.anim:refresh(self:sprite())
            Engine.play_audio(ATTACK_AUDIO, AudioPriority.Immediate)
        end
        if frame == 4 then
            self.counterable_component.timer = 10 -- Becomes counterable for 10 frames.
            self:reveal()
            self:teleport(self.next_tile, ActionOrder.Immediate)
            local move_fx = graphic_init("artifact", 0, 0, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, -99, "1", Playback.Once, shake, facing, true, true, true)
            move_fx:set_elevation(20*2)
            field:spawn(move_fx, self.next_tile)
            self:share_tile(true)
        end
        if frame >= 34 then
            self.set_state(states.ATTACK)
        end
    end
    local offsets_y = {}
    offsets_y.rank0 = { -- 11
        [1]  = {move=0, stop=2},
        [2]  = {move=0, stop=2},
        [3]  = {move=1, stop=2},
        [4]  = {move=1, stop=2},
        [5]  = {move=1, stop=1},
        [6]  = {move=1, stop=1},
        [7]  = {move=1, stop=1},
        [8]  = {move=2, stop=1},
        [9]  = {move=2, stop=0},
        [10] = {move=2, stop=0},
        [11] = {move=2, stop=0},
        [12] = {move=2, stop=0},
    }
    offsets_y.rank1 = {
        [1]  = {move=0, stop=3},
        [2]  = {move=0, stop=2},
        [3]  = {move=1, stop=2},
        [4]  = {move=1, stop=2},
        [5]  = {move=2, stop=2},
        [5]  = {move=2, stop=1},
        [6]  = {move=2, stop=1},
        [7]  = {move=2, stop=0},
        [8]  = {move=3, stop=0},
        [9]  = {move=3, stop=0},
        [10] = {move=3, stop=0},
        [11] = {move=3, stop=0},
        [12] = {move=3, stop=0},
    }
    offsets_y.rank2 = { -- 8
        [1]  = {move=0, stop=3},
        [2]  = {move=1, stop=3},
        [3]  = {move=1, stop=3},
        [4]  = {move=2, stop=2},
        [5]  = {move=2, stop=2},
        [6]  = {move=3, stop=1},
        [7]  = {move=3, stop=1},
        [7]  = {move=4, stop=0},
        [8]  = {move=4, stop=0},
        [9]  = {move=4, stop=0},
        [10] = {move=4, stop=0},
        [11] = {move=4, stop=0},
        [12] = {move=4, stop=0},
    }
    offsets_y.rank3 = { -- 8
    --[[
        [1]  = {move=0, stop=0},
        [1]  = {move=2, stop=0},
        [1]  = {move=2, stop=0},
        [1]  = {move=3, stop=0},
        [1]  = {move=4, stop=0},
        [1]  = {move=5, stop=0},
        [1]  = {move=5, stop=0},

        
        [1]  = {move=0, stop=4},
        [1]  = {move=0, stop=4},
        [1]  = {move=0, stop=2},
        [1]  = {move=0, stop=2},
        [1]  = {move=0, stop=0},
        [1]  = {move=0, stop=0},
    ]]
        
        [1]  = {move=0, stop=4},
        [2]  = {move=1, stop=3},
        [3]  = {move=2, stop=2},
        [4]  = {move=3, stop=1},
        [5]  = {move=4, stop=0},
        [6]  = {move=5, stop=0},
        [7]  = {move=5, stop=0},
        [8]  = {move=5, stop=0},
        [9]  = {move=5, stop=0},
        [10] = {move=5, stop=0},
        [11] = {move=5, stop=0},
        [12] = {move=5, stop=0},
    }
    self:set_shadow(SHADOW_TEXTURE)
    self:show_shadow(true)
    --- Code that runs in the attack state
    ---@param frame number
    self.action_attack = function(frame) -- 15
        local facing = self:get_facing()
        local field = self:get_field()
        self.prev_tile:reserve_entity_by_id(self.reserving_obstacle:get_id())
        self.prev_tile:reserve_entity_by_id(self:get_id())
        if frame == 1 then
            self.tileHeight = math.floor(self:get_tile():height()/2 - self:get_tile():height()/10)
            self.move_state = "MOVING"
            self.move_index = 1
            self.tile_traveled = 1
            self.offset_y = 0
        end
        if self.move_state == "MOVING" then
            self.y_speed = offsets_y["rank"..self.attack_speed][self.move_index].move
            if self:get_tile(self.atk_dir,1):is_edge() then
                self.move_index = 0
                self.move_state = "STOPPING"
                --return
            end
        elseif self.move_state == "STOPPING" then
            self.y_speed = offsets_y["rank"..self.attack_speed][self.move_index].stop
            if self.move_index >= 11-self.attack_speed then
                self.move_index = 0
                self.move_state = "MOVING"
                self.atk_dir = Direction.reverse(self.atk_dir)
                self.dir_m = -self.dir_m
                --return
            end
        end
        self.offset_y = self.offset_y+(self.y_speed*self.dir_m)
        if self.atk_dir == Direction.Down and math.floor(self.offset_y) > self.tileHeight/2 then
            if self.tile_traveled < 15 then
                self.tile_traveled = self.tile_traveled + 1
                self:teleport(self:get_tile(Direction.Down,1), ActionOrder.Voluntary)
                self.offset_y = self.offset_y-self.tileHeight
            else
                self.set_state(states.MOVE_BACK)
            end
        elseif self.atk_dir == Direction.Up and math.floor(self.offset_y) < -self.tileHeight/2 then
            if self.tile_traveled < 15 then
                self.tile_traveled = self.tile_traveled + 1
                self:teleport(self:get_tile(Direction.Up,1), ActionOrder.Voluntary)
                self.offset_y = self.offset_y+self.tileHeight
            else
                self.set_state(states.MOVE_BACK)
            end
        end
        if self.move_index < #offsets_y["rank"..self.attack_speed] then
            self.move_index = self.move_index + 1
        end
        self:set_offset(0,self.offset_y*2)
        self:get_tile():highlight(Highlight.Solid)
    end
    --- Code that runs in the attack state.
    ---@param frame number
    self.action_move_back = function(frame)
        local facing = self:get_facing()
        local field = self:get_field()
        self.prev_tile:reserve_entity_by_id(self.reserving_obstacle:get_id())
        self.prev_tile:reserve_entity_by_id(self:get_id())
        if frame == 1 then
            local move_fx = graphic_init("artifact", self:get_offset().x, self:get_offset().y, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, -99, "0", Playback.Once, self, facing, true, true, true)
            move_fx:set_elevation(20*2)
            field:spawn(move_fx, self:get_tile())
            self:hide()
            self:set_offset(self.orig_offset[1].x,self.orig_offset[1].y)
            self.tile_traveled = 1
            advance_a_turn_by_facing(self:get_facing())
        end
        if frame == 4 then
            self:reveal()
            self.anim:set_state("PLAYER_IDLE")
            self.anim:set_playback(Playback.Loop)
            self:teleport(self.prev_tile, ActionOrder.Immediate)
            local move_fx = graphic_init("artifact", self.orig_offset[1].x, self.orig_offset[1].y, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, -99, "1", Playback.Once, self, facing, true, true, true)
            move_fx:set_elevation(20*2)
            field:spawn(move_fx, self.prev_tile)
            self:share_tile(false)
        end
        --[[
        if frame == 5 then
            advance_a_turn_by_facing(self:get_facing())
            self.set_state(states.IDLE)
        end]]
        if frame >= 50 then
            WindPush.remove_immunity(self)
            self.set_state(states.IDLE)
        end
    end
    --utility to set the update state, and reset frame counter
    ---@param state number
    self.set_state = function(state)
        self.state = state
        self.frame_counter = 0
    end
    -- actions for states
    local actions = { [1] = self.action_idle, [2] = self.action_moving, [3] = self.action_attack, [4] = self.action_move_back }
    self.on_spawn_func = function(self)
        debug_print(self,"on_spawn_func called")
        if character_info.name_on_spawn then
            self:set_name(character_info.name)
        end
        self:get_field():spawn(self.reserving_obstacle,0,0)
        --In theory we should not need to do this as they would be cleared at the end of the last battle
        --However there is a bug in ONB V2 which causes battle_end_func to be missed sometimes.
        left_mob_tracker:clear()
        right_mob_tracker:clear()
    end
    self.battle_start_func = function()
        debug_print(self,"battle_start_func called")
        if left_mob_tracker:get_first_mob(false) == nil then
            left_mob_tracker:clear()
        end
        if right_mob_tracker:get_first_mob(true) == nil then
            right_mob_tracker:clear()
        end
        add_enemy_to_tracking(self)
        local field = self:get_field()
        local mob_sort_func = function(a,b)
            local met_a_tile = field:get_entity(a):get_tile()
            local met_b_tile = field:get_entity(b):get_tile()
            local var_a = (met_a_tile:x()*3)+met_a_tile:y()
            local var_b = (met_b_tile:x()*3)+met_b_tile:y()
            return var_a < var_b
        end
        left_mob_tracker:sort_turn_order(mob_sort_func)
        right_mob_tracker:sort_turn_order(mob_sort_func,true)--reverse sort direction
    end
    self.battle_end_func = function(self)
        debug_print(self,"battle_end_func called")
        left_mob_tracker:clear()
        right_mob_tracker:clear()
    end
    self.delete_func = function()
        debug_print(self,"delete_func called")
        self.is_deleting = true
        self.reserving_obstacle:delete() -- Removes the Reserving Obstacle.
        remove_enemy_from_tracking(self)
    end
    self.update_func = function()
        self.frame_counter = self.frame_counter + 1
        if not self.started then
            self.started = true
            self.set_state(states.IDLE)
        else
            local action_func = actions[self.state]
            action_func(self.frame_counter)
        end
        -- collision hitbox
        check_collision(self, self.damage)
    end
end

function choose_move(self)
    local tiles = {}
    for i=0,3 do
        local tile = self:get_tile(math.floor(2^i),1)
        if tile and self.can_move_to_func(tile) then
            table.insert(tiles, tile)
        end
    end
    --print("Found ", #tiles, " possible tiles")
    if #tiles == 0 then 
        return self:get_tile()
    end
    return tiles[math.random(1,#tiles)]
end

function choose_move_to_row(self, dest_y)
    local tile = self:get_tile()
    if (dest_y < tile:y()) then
        tile = tile:get_tile(Direction.Up,1)
    else
        tile = tile:get_tile(Direction.Down,1)
    end
    if not tile or not self.can_move_to_func(tile) or self:is_confused() or self:is_blind() then 
        return nil
    end
    return tile
end

function create_collision_attack(user, damage, tile)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(user:get_facing())
    spell:set_hit_props(
        HitProps.new()
        :dmg(damage)
        :impact()
        :flinch()
        :flash()
        :no_counter()
        :from(user:get_context())
        :elem(user:get_element())
    )
    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end
    user:get_field():spawn(spell, tile)
    return spell
end

function check_collision(user, damage)
    local t = user:get_tile()
    if user.collision_available and check_characters(t, user) --[[or check_obstacles(t))]] then 
        create_collision_attack(user, damage, t)
    end
end

-- Checks for non-zero-health Obstacles.
function check_obstacles(tile)
    local ob = tile:find_obstacles(function(o)
        if o:get_animation():has_state("PASS_THROUGH") or o:get_name() == "CANTINTERACT" then
            return false
        else
            return true
        end
        return o:get_health() > 0
    end)
    return #ob > 0 
end

-- Checks for unfriendly Characters.
function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)
    return #characters > 0
end

-- Checks for any Characters.
function check_characters_true(tile)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0
    end)
    return #characters > 0
end

function check_characters_true_team(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_tile():get_team() == self:get_tile():get_team()
    end)
    return #characters > 0
end

return package_init