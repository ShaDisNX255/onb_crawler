local shared_package_init = include("../HeavyArei/character.lua")

function package_init(character)
    local character_info = {
        name = "HeavyArei",
        name_on_spawn = false,
        health = 100,
        damage = 30,
        element = Element.None,
        damage_waindo = 30,
        frames_speed = 25,
        attack_speed = 0,
    }
    if character:get_rank() == Rank.V2 then
        character_info.name = "HeavyAreiz"
        character_info.name_on_spawn = true
        character_info.health = 150
        character_info.damage = 60
        character_info.damage_waindo = 60
        character_info.frames_speed = 20
        character_info.attack_speed = 1
    elseif character:get_rank() == Rank.V3 then
        character_info.name = "HeavyAreid"
        character_info.name_on_spawn = true
        character_info.health = 200
        character_info.damage = 90
        character_info.damage_waindo = 90
        character_info.frames_speed = 15
        character_info.attack_speed = 2
    elseif character:get_rank() == Rank.SP then
        character_info.health = 300
        character_info.damage = 150
        character_info.damage_waindo = 150
        character_info.frames_speed = 10
        character_info.attack_speed = 3
    end
    shared_package_init(character,character_info)
end