local shared_package_init = include("../Kiorushin/character.lua")

function package_init(character)
    local character_info = {
        name = "Kiorushin",
        name_on_spawn = false,
        health = 90,
        damage = 30,
        element = Element.None,
        damage_tosshin = 30,
        damage_honoo = 30,
        dashes = 2,
        frames_move = 32,
        frames_atk = 10,
    }
    if character:get_rank() == Rank.V2 then
        character_info.name = "Badraft"
        character_info.name_on_spawn = true
        character_info.health = 150
        character_info.damage = 60
        character_info.element = Element.Fire
        character_info.damage_tosshin = 60
        character_info.damage_honoo = 60
        character_info.dashes = 1
        character_info.frames_move = 32
        character_info.frames_atk = 7
    elseif character:get_rank() == Rank.V3 then
        character_info.name = "HellCondor"
        character_info.name_on_spawn = true
        character_info.health = 240
        character_info.damage = 90
        character_info.damage_tosshin = 90
        character_info.damage_honoo = 90
        character_info.dashes = 3
        character_info.frames_move = 32
        character_info.frames_atk = 6
    elseif character:get_rank() == Rank.SP then
        character_info.health = 300
        character_info.damage = 150
        character_info.damage_tosshin = 150
        character_info.damage_honoo = 150
        character_info.dashes = 5
        character_info.frames_move = 28
        character_info.frames_atk = 5
    end
    shared_package_init(character,character_info)
end