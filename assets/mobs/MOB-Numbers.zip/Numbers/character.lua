--[[
    TODO:
    - Removing the observer on battle end causes DOUBLE DELETE.
    OPTIONAL GLITCHES:
    - On 31st attack, it doesn't spawn a hitbox.
    - On 32nd attack, it doesn't spawn a thunderbolt.
    - On 33rd and later, it doesn't do any attack.
]]
local print_debug = false
local is_glitchy = false

local CHARACTER_TEXTURE = Engine.load_texture(_folderpath.."gfx/battle.grayscaled.png")
local CHARACTER_ANIMPATH = _folderpath.."gfx/battle.animation"
local SHINE_TEXTURE = Engine.load_texture(_folderpath.."gfx/shine.grayscaled.png")
local SHADOW_TEXTURE = Engine.load_texture(_folderpath.."gfx/battle_shadow.png")

local AREASTEAL_TEXTURE = Engine.load_texture(_folderpath.."gfx/areasteal.grayscaled.png")
local AREASTEAL_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/areasteal.png")
local AREASTEAL_ANIMPATH = _folderpath.."gfx/areasteal.animation"
local AREASTEAL_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE3_99.ogg", true)

local THUNDERBOLT_TEXTURE = Engine.load_texture(_folderpath.."gfx/thunderbolt.grayscaled.png")
local THUNDERBOLT_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/thunderbolt.png")
local THUNDERBOLT_ANIMPATH = _folderpath.."gfx/thunderbolt.animation"
local THUNDERBOLT_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE3_223.ogg", true)

local EFFECT4_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect4.grayscaled.png") -- flip for Player 2?
local EFFECT4_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect4.png")
local EFFECT4_ANIMPATH = _folderpath.."gfx/effect4.animation"

local FLASH_TEXTURE = Engine.load_texture(_folderpath.."gfx/flash.png")
local FLASH_ANIMPATH = _folderpath.."gfx/flash.animation"

function debug_print(id,str)
    if print_debug then
        print("[Numbers] (ID: "..id:get_id()..") "..str)
    end
end

--possible states for character
local states = { IDLE = 1 }

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or Playback.Once
    facing = facing or user:get_facing()
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and facing == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function create_screenshake(user, facing, field, team, tile)
    local spell = Battle.Spell.new(team)
    spell:set_facing(facing)
    spell.frames = 1
    spell.update_func = function(self)
        self:shake_camera(10, 0.05)
        if self.frames >= 48 then
            self:delete()
        end
        self.frames = self.frames + 1
    end
    field:spawn(spell,tile)
    return spell
end

local function create_thunderbolt(user, facing, field, team, tile, has_hitbox)
    local function create_hitbox(user, facing, field, team, tile)
        local spell = Battle.Spell.new(team)
        spell:set_facing(facing)
        spell:set_hit_props(
            HitProps.new()
            :dmg(1000)
            :impact()
            :flinch()
            :flash()
            :breaking()
            :pierce()
            :pierce_ground()
            :retangible()
            :no_counter()
            :elem2(Element.Sword)
            :from(user:get_context())
        )
        spell.update_func = function(self)
            tile:attack_entities(self)
            self:delete()
        end
	    spell.attack_func = function(self, other, judge)
	    	debug_print("attacked tile ("..self:get_tile():x()..";"..self:get_tile():y()..")")
            if not judge:hint_spawn_gfx() then return end
            local offset_y = math.random(-6,7)
            local offset_x = math.random(-7,6)
            local hit_fx = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT4_TEXTURE, EFFECT4_PALETTE, EFFECT4_ANIMPATH, -999, "0", Playback.Once, user, facing, true, true, true)
            field:spawn(hit_fx, self:get_tile())
	    end
        field:spawn(spell,tile)
    end
    local spell = graphic_init("spell", 0, 0, THUNDERBOLT_TEXTURE, THUNDERBOLT_PALETTE, THUNDERBOLT_ANIMPATH, -3, "0", Playback.Once, user, facing, true, true, true)
    spell.on_spawn_func = function(self)
        Engine.play_audio(THUNDERBOLT_AUDIO, AudioPriority.Immediate)
        if has_hitbox then create_hitbox(user, facing, field, team, tile) end
    end
    field:spawn(spell,tile)
    return spell
end

local function create_areasteal(user, facing, field, team, tile)
    local spell = graphic_init("spell", 0, 0, AREASTEAL_TEXTURE, AREASTEAL_PALETTE, AREASTEAL_ANIMPATH, -3, "0", Playback.Once, user, facing, false, false, true)
    spell:set_elevation(44*2)
    spell.frames = 0
    spell.on_spawn_func = function(self)
        Engine.play_audio(AREASTEAL_AUDIO, AudioPriority.Immediate)
    end
    spell.update_func = function(self)
        if self.frames > 0 then
            if self.frames < 21 then
                self:set_elevation(self:get_elevation()+12*2)
            else
                self:delete()
            end
        end
        self.frames = self.frames + 1
    end
    field:spawn(spell,tile)
    return spell
end

local function create_erroranddelete(user, ref)
    debug_print("in create_erroranddelete()!")
    debug_print("user ID: "..user:get_id())
    local facing = user:get_facing()
    local field = user:get_field()
    local team = user:get_team()
    local action = Battle.CardAction.new(user, "")
	action:set_lockout(make_sequence_lockout())
	action.execute_func = function(self)
        debug_print("in custom card action execute_func()!")
        local actor = self:get_actor()
        --actor:never_flip(true)
		local step1 = Battle.Step.new()
		local a_frames = 1
        ref.ead_uses = ref.ead_uses + 1
        --print("ead_uses: "..ref.ead_uses)
        local do_act = true
        if ref.ead_uses >= 32 and is_glitchy then do_act = false end
		step1.update_func = function(self)
            if do_act then
			    if a_frames == 1 then
                    create_areasteal(user, facing, field, team, user:get_tile())
                    user:sprite():set_color_mode(ColorMode.Additive)
                    user:sprite():set_color(Color.new(255,255,255,255))
                end
			    if a_frames == 2 then
                    user:sprite():set_color_mode(ColorMode.Additive)
                    user:sprite():set_color(Color.new(0,0,0,255))
                end
			    if a_frames == 20 then
		            local targets = field:find_characters(function(t)
		            	return t and t:get_health() > 0 and not t:is_team(team)
		            end)
			    	if #targets>0 then
                        local has_hitbox = true
                        if ref.ead_uses >= 31 then has_hitbox = false end
			    		for i=1, #targets do
                            create_thunderbolt(user, facing, field, team, targets[i]:get_tile(), has_hitbox)
			    		end
                        local flash_fx = graphic_init("artifact", 0, 0, FLASH_TEXTURE, nil, FLASH_ANIMPATH, 999, "0", Playback.Once, user, Direction.Right, true, false, true)
                        field:spawn(flash_fx, 0, 0)
                        create_screenshake(user, facing, field, team, user:get_tile())
			    	end
                end
            end
			if a_frames >= 101 then
				self:complete_step()
			end
			a_frames = a_frames + 1
		end
		self:add_step(step1)
	end
	local meta = action:copy_metadata()
	meta.shortname = "Error&Delete"
	meta.damage = 0
	meta.time_freeze = true
	action:set_metadata(meta)
	user:card_action_event(action, ActionOrder.Voluntary)
end

function respawn_numbers(character_info, field, team, rank, tile)
    local package_id = "com.OFC.char.EXE3-040-"..character_info.palette
    local chara = Battle.Character.from_package(package_id, team, rank)
    chara:toggle_hitbox(false)
    field:spawn(chara,tile)
    local frame = 1
    local alpha = 0
    Engine.play_audio(AudioType.Appear, AudioPriority.Immediate)
    local spawn_component = Battle.Component.new(chara, Lifetimes.Battlestep)
    spawn_component.update_func = function(self)
        alpha = alpha + 255/30
        if alpha > 255 then alpha = 255 end
        chara:set_color(Color.new(0,0,0,math.floor(alpha)))
        if frame > 30 then
            chara:toggle_hitbox(true)
            --chara.state = states.IDLE
            --chara.frame_counter = 0
            self:eject()
        end
        frame = frame + 1
    end
    spawn_component.battle_end_func = function(self)
        self:eject()
    end
    chara:register_component(spawn_component)
    return chara
end

function package_init(self, character_info)
    -- Required function, main package information
    self.texture = CHARACTER_TEXTURE
    self.anim = self:get_animation()
    self.anim:load(CHARACTER_ANIMPATH)
    -- Load extra resources
    -- Set up character meta
    -- Common Properties
    self:set_name(character_info.name)
    self:set_health(character_info.health)
    self:set_element(Element.None)
    self:set_texture(self.texture, true)
    self:set_height(69)
    self:set_float_shoe(true)
    self:set_air_shoe(true)
    self:share_tile(false)
    self:set_explosion_behavior(2, 1, false)
    self:set_offset(0,0)
    --self:never_flip(true)
    local palette_n = Engine.load_texture(_modpath.."/battle-n.png")
    --print(_modpath..character_info.palette.."/battle-n.png")
    local palette_y = Engine.load_texture(_modpath.."/battle-y.png")
    --print(_modpath..character_info.palette.."/battle-y.png")
    self:store_base_palette(palette_y)
    self:set_shadow(SHADOW_TEXTURE)
    self:show_shadow(true)
    self.damage = character_info.damage
    -- Other Setup
    self.collision_available = true
    -- entity will spawn with this animation.
    self.anim:set_state("SPAWN")
    --self.anim:refresh(self:sprite())
    self.frame_counter = 0
    self.started = false
    self.is_deleting = false
    self.attack_counter = 0
    -- This defense rule is added to prevent enemy from gaining invincibility after taking damage.
    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)
    self.defense_rule = Battle.DefenseRule.new(1, DefenseOrder.Always)
    self.can_be_hit = false
    local ref = self
    self.defense_rule.filter_statuses_func = function(statuses)
        local damage = statuses.damage
        if (self:get_tile():get_state() == TileState.Grass and statuses:has_element(Element.Fire)) or (self:get_tile():get_state() == TileState.Sea and statuses:has_element(Element.Elec)) or (self:is_frozen() and statuses:has_flags(Hit.Breaking)) then
            damage = damage*2
        end
        if damage < self:get_max_health() or not self.can_be_hit then
            statuses.damage = 0
        end
        if not self.can_be_hit then
		    statuses.flags = statuses.flags & ~Hit.Flinch
		    statuses.flags = statuses.flags & ~Hit.Flash
		    statuses.flags = statuses.flags & ~Hit.Stun
		    statuses.flags = statuses.flags & ~Hit.Freeze
		    statuses.flags = statuses.flags & ~Hit.Bubble
		    statuses.flags = statuses.flags & ~Hit.Confuse
		    statuses.flags = statuses.flags & ~Hit.Blind
		    statuses.flags = statuses.flags & ~Hit.Root
        end
		return statuses
	end
    self.defense_rule.can_block_func = function(judge, attacker, defender)
		local hit_props = attacker:copy_hit_props()
        if not self.can_be_hit then
            judge:set_hit_sfx(nil)
        end
		if not hit_props:has_flags(Hit.Drag) and hit_props:has_flags(Hit.Impact) and self:can_attack() and hit_props.damage < self:get_max_health() and not self.can_be_hit then
            local gotit = self:get_field():tile_at(0,0):find_entities(function(c)
                return c:get_name() == "NumbersWatcherGO" and c:is_team(self:get_team())
            end)
            if #gotit<=0 then
                local spellgo = Battle.Spell.new(self:get_team())
                spellgo:set_name("NumbersWatcherGO")
                spellgo:set_hit_props(
                    HitProps.new()
                    :dmg(self:get_id())
                    :from(self:get_context())
                )
                spellgo.on_spawn_func = function(self)
                    debug_print("create spellgo")
                end
                spellgo.battle_end_func = function(self)
                    self:erase()
                end
                self:get_field():spawn(spellgo,0,0)
            end
        end
	end
    self:add_defense_rule(self.defense_rule)

    local query = function(c)
        return c:get_health()>0 and c:get_animation():has_state("IS_NUMBERS") and c:get_rank() < self:get_rank()
    end
    self.numbers_list = nil

    local rank = tonumber(self:get_rank())+1
    self.number = self:create_node()
    self.number:set_texture(Engine.load_texture(_folderpath.."gfx/number"..rank..".grayscaled.png"))
    self.number:set_layer(-1)
    self.number:enable_parent_shader(true)
    self.number_anim = Engine.Animation.new(CHARACTER_ANIMPATH)
    self.number_anim:copy_from(self.anim)
    self.number_anim:set_state(self.anim:get_state())
    self.number_anim:refresh(self.number)

    self.shine = self:create_node()
    self.shine:set_texture(SHINE_TEXTURE)
    self.shine:set_layer(-1)
    self.shine:enable_parent_shader(true)
    self.shine_anim = Engine.Animation.new(CHARACTER_ANIMPATH)
    self.shine_anim:copy_from(self.anim)
    self.shine_anim:set_state(self.anim:get_state())
    self.shine_anim:refresh(self.shine)

    self.animate_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.animate_component.update_func = function(self, dt)
        ref.number_anim:update(dt, ref.number)
        ref.shine_anim:update(dt, ref.shine)
    end
    self:register_component(self.animate_component)

    self.slide_component = nil
    self.prev_tile = nil
    self.next_tile = nil

    self.can_move_to_func = function(tile)
        --if self:is_rooted() then return false end
        if not tile or tile:is_hole() then
            return false
        end
        if tile:get_team() ~= self:get_team() then
            return false
        end
        -- Can't move to reserved tiles.
        if tile:is_reserved({self:get_id()}) then
            return false
        end
        if tile == self:get_tile() then
            return true
        end
        return not check_obstacles(tile) and not check_characters_true(tile)
    end

    -- Code that runs in the default state
    ---@param frame number
    self.action_idle = function(frame)
        local facing = self:get_facing()
        local field = self:get_field()
        local team = self:get_team()
        local id = self:get_id()
        if frame == 1 then
            local new_state = "PLAYER_IDLE"
            self.anim:set_state(new_state)
            self.anim:set_playback(Playback.Loop)
            self.shine_anim:set_state(new_state)
            self.shine_anim:set_playback(Playback.Loop)
            self.number_anim:set_state(new_state)
            self.number_anim:set_playback(Playback.Loop)
            --self.shine_anim:refresh(shine)
        end
        if not self.can_be_hit then
            --if #self.numbers_list <= 0 then return end
            self.numbers_list = field:find_characters(query)
            --[[
            local new_numbers = {}
            for i=1,#self.numbers_list do
                if not self.numbers_list[i] or self.numbers_list[i]:is_deleted() or self.numbers_list[i]:get_health() <=0 then
                    table.insert(new_numbers, self.numbers_list[i])
                end
            end
            self.numbers_list = new_numbers]]
            if #self.numbers_list <= 0 then
                self:set_palette(self:get_base_palette())
                self.can_be_hit = true
            end
        end
        --[[
        if active_mob_id == id then
            if self.attack_timer < self.frames_between_actions then
                self.attack_timer = self.attack_timer + 1
            end
        end]]
    end
    --utility to set the update state, and reset frame counter
    ---@param state number
    self.set_state = function(state)
        self.state = state
        self.frame_counter = 0
    end
    -- actions for states
    local actions = { [1] = self.action_idle }
    self.on_spawn_func = function(self)
        debug_print(self,"on_spawn_func called")
        local field = self:get_field()
        self.numbers_list = field:find_characters(query)
        if #self.numbers_list>0 then
            self:set_palette(palette_n)
        else
            self:set_palette(palette_y)
        end
    end
    self.battle_start_func = function()
        debug_print(self,"battle_start_func called")
        local field = self:get_field()
        local team = self:get_team()
        local watchers = field:tile_at(0,0):find_characters(function(c)
            return c:get_name() == "NumbersWatcher" and c:is_team(team)
        end)
        if #watchers<=0 then
		    local obs_watcher = Battle.Character.new(team, Rank.V1)
		    --obs_watcher:get_animation():load(_folderpath.."gfx/watcher.animation")
		    --obs_watcher:get_animation():set_state("0")
		    obs_watcher:set_name("NumbersWatcher")
		    obs_watcher:set_health(9999)
		    obs_watcher:share_tile(true)
		    obs_watcher:set_air_shoe(true)
		    obs_watcher:toggle_hitbox(false)
		    obs_watcher:set_float_shoe(true)
            obs_watcher.ead_uses = 0 -- used for glitchy behavior
            obs_watcher.update_func = function(self)
                local my_numbers = field:find_characters(function(c)
                    return c:get_health()>0 and c:get_animation():has_state("IS_NUMBERS") and c:is_team(team)
                end)
                if #my_numbers<=0 then
                    self:erase()
                    return
                end
                local gotit = field:tile_at(0,0):find_entities(function(c)
                    return c:get_name() == "NumbersWatcherGO" and c:is_team(team)
                end)
                --[[
                attacker:copy_hit_props()
                local my_numbers2 = field:find_characters(function(c)
                    return c:get_animation():has_state("IS_NUMBERS") and c:get_id() == gotit[1]:copy_hit_props().damage
                end)]]
                if #gotit>0 then
                    for i=1,#gotit do
                        gotit[i]:delete()
                    end
                    if is_glitchy and self.ead_uses >= 32 then return end
                    for i=1,#my_numbers do
                        if my_numbers[i]:get_id() == gotit[1]:copy_hit_props().damage then
                            debug_print("calling create_erroranddelete()")
                            create_erroranddelete(my_numbers[i], self)
                            break
                        end
                    end
                end
            end
            obs_watcher.battle_end_func = function(self)
                self:erase()
            end
            field:spawn(obs_watcher,0,0)
        end
    end
    self.battle_end_func = function(self)
        debug_print(self,"battle_end_func called")
    end
    local ref = self
    self.delete_func = function()
        debug_print(self,"delete_func called")
        local field = self:get_field()
        local team = self:get_team()
        local rank = self:get_rank()
        local tile = self:get_tile()
        self.is_deleting = true
        local current_numbers = field:find_characters(function(c)
            return c:get_animation():has_state("IS_NUMBERS") and c:get_rank() == rank and c:get_health()>0
        end)
        if #current_numbers>0 then
            local spawner = Battle.Spell.new(team)
            spawner.update_func = function(self)
                if ref:will_erase_eof() then
                    respawn_numbers(character_info, field, team, rank, tile)
                    self:delete()
                end
            end
            spawner.battle_end_func = function(self)
                self:delete()
            end
            field:spawn(spawner,tile)
        end
    end
    self.update_func = function()
        self.frame_counter = self.frame_counter + 1
        if not self.started then
            self.started = true
            self.set_state(states.IDLE)
        else
            local action_func = actions[self.state]
            action_func(self.frame_counter)
        end
        -- collision hitbox
        check_collision(self, self.damage)
    end

end

function choose_move(self)
    local tiles = {}
    for i=0,3 do
        local tile = self:get_tile(math.floor(2^i),1)
        if tile and self.can_move_to_func(tile) then
            table.insert(tiles, tile)
        end
    end
    --print("Found ", #tiles, " possible tiles")
    if #tiles == 0 then 
        return self:get_tile()
    end
    return tiles[math.random(1,#tiles)]
end

function choose_move_to_row(self, dest_y)
    local tile = self:get_tile()
    if (dest_y < tile:y()) then
        tile = tile:get_tile(Direction.Up,1)
    else
        tile = tile:get_tile(Direction.Down,1)
    end
    if not tile or not self.can_move_to_func(tile) or self:is_confused() or self:is_blind() then 
        return nil
    end
    return tile
end

function create_collision_attack(user, damage, tile)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(user:get_facing())
    spell:set_hit_props(
        HitProps.new()
        :dmg(damage)
        :impact()
        :flinch()
        :flash()
        :no_counter()
        :elem(user:get_element())
        :from(user:get_context())
    )
    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end
    user:get_field():spawn(spell, tile)
    return spell
end

function check_collision(user, damage)
    local t = user:get_tile()
    if user.collision_available and check_characters(t, user) --[[or check_obstacles(t))]] then 
        create_collision_attack(user, damage, t)
    end
end

-- Checks for non-zero-health Obstacles.
function check_obstacles(tile)
    local ob = tile:find_obstacles(function(o)
        if o:get_animation():has_state("PASS_THROUGH") or o:get_name() == "CANTINTERACT" then
            return false
        else
            return true
        end
        return o:get_health() > 0
    end)
    return #ob > 0 
end

-- Checks for unfriendly Characters.
function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)
    return #characters > 0
end

-- Checks for any Characters.
function check_characters_true(tile)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0
    end)
    return #characters > 0
end

function check_characters_true_team(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_tile():get_team() == self:get_tile():get_team()
    end)
    return #characters > 0
end

return package_init