local shared_package_init = include("../Numbers/character.lua")

function package_init(character)
    local character_info = {
        name = "G-Numbrs",
        palette = "Numbers3",
        health = 650,
    }
    if character:get_rank() == Rank.V1 then
        character_info.name = "G-Numbrs1"
    end
    shared_package_init(character,character_info)
end