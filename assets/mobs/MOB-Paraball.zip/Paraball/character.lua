--[[

    CUSTOM BEHAVIOR:
    If Rooted, can't move but can still attack.
    If Confused or Blind, becomes slower and can't find the player.

]]
local is_counterable = true
local print_debug = false

local CHARACTER_TEXTURE = Engine.load_texture(_folderpath.."gfx/battle.grayscaled.png")
local CHARACTER_ANIMPATH = _folderpath.."gfx/battle.animation"

local PLASMABALL_TEXTURE = Engine.load_texture(_folderpath.."gfx/plasmaball.grayscaled.png")
local PLASMABALL_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/plasmaball.png")
local PLASMABALL_ANIMPATH = _folderpath.."gfx/plasmaball.animation"

local PLASMABALL_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE3_198.ogg", true)

local WindPush = include("libs/WindPush.lua")

function debug_print(id,str)
    if print_debug then
        print("[Paraball] (ID: "..id:get_id()..") "..str)
    end
end

--possible states for character
local states = { IDLE = 1, MOVE = 2, ATTACK = 3}

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or Playback.Once
    facing = facing or user:get_facing()
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and facing == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function move_slide(self, direction, frames1, frames2)
    local res_tile = self:get_tile(direction,1)
    if res_tile:get_team() == team then
        --res_tile:reserve_entity_by_id(self.reserving_obstacle:get_id())
    end
    WindPush.make_entity_immune_to_status(self)
    self.slide_component = Battle.Component.new(self, Lifetimes.Local)
    local cur_tile = 1
    local self_tile = self:get_tile()
    local tileWidthO = self_tile:width()
    local tileHeightO = self_tile:height()
    local tileHeightE = self_tile:height()-12
    local tileWidth = tileWidthO/2
    local tileHeight = tileHeightO/2 - tileHeightO/10
    local offset_x = self:get_offset().x
    local offset_y = self:get_offset().y
    local wait_delay = 0
    local round = function(val)
        if facing == Direction.Right then
            return math.floor(val)
        else
            return math.ceil(val)
        end
    end
    local cancel_move = function()
        WindPush.remove_immunity(self)
        self.slide_component:eject()
        self.slide_component = nil
        self:set_offset(0,0)
        self.moving_to_enemy = false
        --res_tile:remove_entity_by_id(self.reserving_obstacle:get_id())
    end
    self.slide_component.update_func = function()
        if self:is_bubbled() then
            cancel_move()
            return
        end
        if self:is_stunned() or self:is_frozen() or self:is_rooted() or self.is_deleting then return end
        ----
        local frames = frames1
        if self:is_confused() or self:is_blind() then
            frames = frames2
        end
        local round_x = 0
        local round_y = 0
        if direction == Direction.UpLeft then
            offset_x = offset_x - tileWidthO/frames
            offset_y = offset_y - tileHeightE/frames
            round_x = round(offset_x)
            round_y = round(offset_y)
            if round_x < 0 and round_y < 0 and cur_tile == 2 then
                round_x = 0
                round_y = 0
                cur_tile = 3
            end
            if round_x < -tileWidth and round_y < -tileHeight and cur_tile == 1 then
                self:teleport(self:get_tile(Direction.UpLeft,1), ActionOrder.Immediate)
                round_x = (tileWidth+(round_x+tileWidth))
                round_y = (tileHeight+(round_y+tileHeight))
                offset_x = round_x
                offset_y = round_y
                cur_tile = 2
            end
		elseif direction == Direction.UpRight then
            offset_x = offset_x + tileWidthO/frames
            offset_y = offset_y - tileHeightE/frames
            round_x = round(offset_x)
            round_y = round(offset_y)
            if round_x > 0 and round_y < 0 and cur_tile == 2 then
                round_x = 0
                round_y = 0
                cur_tile = 3
            end
            if round_x > tileWidth and round_y < -tileHeight and cur_tile == 1 then
                self:teleport(self:get_tile(Direction.UpRight,1), ActionOrder.Immediate)
                round_x = -(tileWidth-(round_x-tileWidth))
                round_y = (tileHeight+(round_y+tileHeight))
                offset_x = round_x
                offset_y = round_y
                cur_tile = 2
            end
		elseif direction == Direction.DownLeft then
            offset_x = offset_x - tileWidthO/frames
            offset_y = offset_y + tileHeightE/frames
            round_x = round(offset_x)
            round_y = round(offset_y)
            if round_x < 0 and round_y > 0 and cur_tile == 2 then
                round_x = 0
                round_y = 0
                cur_tile = 3
            end
            if round_x < -tileWidth and round_y > tileHeight and cur_tile == 1 then
                self:teleport(self:get_tile(Direction.DownLeft,1), ActionOrder.Immediate)
                round_x = (tileWidth+(round_x+tileWidth))
                round_y = -(tileHeight-(round_y-tileHeight))
                offset_x = round_x
                offset_y = round_y
                cur_tile = 2
            end
		elseif direction == Direction.DownRight then
            offset_x = offset_x + tileWidthO/frames
            offset_y = offset_y + tileHeightE/frames
            round_x = round(offset_x)
            round_y = round(offset_y)
            if round_x > 0 and round_y > 0 and cur_tile == 2 then
                round_x = 0
                round_y = 0
                cur_tile = 3
            end
            if round_x > tileWidth and round_y > tileHeight and cur_tile == 1 then
                self:teleport(self:get_tile(Direction.DownRight,1), ActionOrder.Immediate)
                round_x = -(tileWidth-(round_x-tileWidth))
                round_y = -(tileHeight-(round_y-tileHeight))
                offset_x = round_x
                offset_y = round_y
                cur_tile = 2
            end
        elseif direction == nil then
            wait_delay = wait_delay + 1
            if wait_delay >= frames1 then
                self.slide_component:eject()
                self.slide_component = nil
            end
            return
        end
        self:set_offset(round_x,round_y)
        if cur_tile >= 3 then
			self:set_offset(0,0)
            cancel_move()
        end
    end
    self:register_component(self.slide_component)
end

local function get_nearest_dirs(dir)
    local new_dirs = {}
    if     dir == Direction.UpLeft then
        table.insert(new_dirs, Direction.Up)
        table.insert(new_dirs, Direction.Left)
    elseif dir == Direction.UpRight then
        table.insert(new_dirs, Direction.Up)
        table.insert(new_dirs, Direction.Right)
    elseif dir == Direction.DownLeft then
        table.insert(new_dirs, Direction.Down)
        table.insert(new_dirs, Direction.Left)
    else
        table.insert(new_dirs, Direction.Down)
        table.insert(new_dirs, Direction.Right)
    end
    return new_dirs
end

local function create_plasmaball(ref, hit_props, facing, field, tile)
    if not tile then return end
    local plasma = graphic_init("spell", 0, 0, PLASMABALL_TEXTURE, PLASMABALL_PALETTE, PLASMABALL_ANIMPATH, -3, "1", Playback.Once, ref, facing, true, true, true)
    plasma:set_hit_props(hit_props)
    plasma.on_spawn_func = function()
        Engine.play_audio(PLASMABALL_AUDIO, AudioPriority.Immediate)
    end
    plasma.update_func = function(self)
        tile:highlight(Highlight.Solid)
        tile:attack_entities(self)
    end
    plasma.battle_end_func = function(self)
        self:delete()
    end
    plasma.delete_func = function(self)
        self:erase()
    end
    field:spawn(plasma,tile)
    return plasma
end

function package_init(self, character_info)
    -- Required function, main package information
    self.texture = CHARACTER_TEXTURE
    self.anim = self:get_animation()
    self.anim:load(CHARACTER_ANIMPATH)
    -- Load extra resources
    -- Set up character meta
    -- Common Properties
    self:set_name(character_info.name)
    self:set_health(character_info.health)
    self:set_element(character_info.element)
    self:set_texture(self.texture, true)
    self:set_height(69)
    self:set_float_shoe(true)
    self:set_air_shoe(true)
    self:share_tile(true) -- you can step on it
    self:set_explosion_behavior(2, 1, false)
    self:set_offset(0,0)
    self:store_base_palette(Engine.load_texture(_folderpath.."gfx/palette/battle-"..self:get_rank()..".png"))
    self:set_palette(self:get_base_palette())
    self.damage = character_info.damage
    -- Paraball Specific
    self.damage_plasmaball = character_info.damage_plasmaball
	self.start_ver = character_info.start_ver
    self.move_speed = character_info.move_speed
    self.atk_frame = character_info.atk_frame
    self.atk_times = character_info.atk_times
    self.atk_interval = character_info.atk_interval
    -- Other Setup
    self.collision_available = true
    self.moving_to_enemy = false
    -- entity will spawn with this animation.
    self.anim:set_state("SPAWN")
    --self.anim:refresh(self:sprite())
    self.frame_counter = 0
    self.started = false
    self.is_deleting = false
    self.move_counter = 0
    -- This defense rule is added to prevent enemy from gaining invincibility after taking damage.
    self.slide_component = nil
    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)
    self.defense_rule = Battle.DefenseRule.new(1, DefenseOrder.Always)
    local ref = self
    self.defense_rule.filter_statuses_func = function(statuses)
        if not self.slide_component then
		    statuses.flags = statuses.flags & ~Hit.Drag
        end
		statuses.flags = statuses.flags & ~Hit.Flinch
		statuses.flags = statuses.flags & ~Hit.Flash
		return statuses
	end
    self:add_defense_rule(self.defense_rule)
    self.reserving_obstacle = Battle.Obstacle.new(self:get_team())

    local ref = self
    self.counterable_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.counterable_component.timer = 0
    self.counterable_component.update_func = function(self)
        if self.timer > 0 and is_counterable then
            debug_print(ref,"COUNTERABLE")
            self.timer = self.timer - 1
            ref:toggle_counter(true)
        else
            ref:toggle_counter(false)
        end
    end
    self:register_component(self.counterable_component)
    self.hit_func = function(from_stun)
        debug_print(ref,"Hit func runs")
        self.counterable_component.timer = 0
        self:toggle_counter(false)
    end
    self.on_countered = function(self)
        debug_print(ref,"Countered")
        self.hit_func(true)
    end
    self:register_status_callback(Hit.Stun, function() self.hit_func(true) end)
    self:register_status_callback(Hit.Freeze, function() self.hit_func(true) end)

    self.prev_tile = nil
    self.next_tile = nil

    self.can_move_to_func = function(tile)
        --if self:is_rooted() then return false end
        if tile:is_edge() then
            return false
        end
        if tile:get_team() ~= self:get_team() and not self.moving_to_enemy then
            return false
        end
        -- Can't move to reserved tiles.
        if(tile:is_reserved({self:get_id(),self.reserving_obstacle:get_id()})) then
            return false
        end
        if tile == self:get_tile() then
            return true
        end
		if not self.slide_component then
			return not check_obstacles(tile) --[[and not check_characters_true(tile)]] --it just goes through any charas
		end
		return true
    end

    self.move_dir = nil -- moves diagonally
    self.dirs = nil -- list of dirs clockwise
    self.dir_index = nil -- index of the list
	self.skip_searching_once = false -- becomes true after every attack

    self.action_move = function(frame)
        local facing_away = self:get_facing_away()
        local facing = self:get_facing()
        local field = self:get_field()
        local team = self:get_team()
        if frame == 1 then
            debug_print(self,"action_move()")
            if self.anim:get_state() ~= "PLAYER_IDLE" then
                self.anim:set_state("PLAYER_IDLE")
                self.anim:set_playback(Playback.Loop)
            end
        end
        if not self.slide_component then
            if not self:is_confused() and not self:is_blind() and not self.skip_searching_once then
				local dirs = {
					Direction.join(facing,Direction.Up),
					facing,
					Direction.join(facing,Direction.Down),
				}
                for i=1,#dirs do
                    if check_characters(self:get_tile(dirs[i],1), self) then
                        self.set_state(states.ATTACK)
                        return
                    end
                end
            end
            local tile = self:get_tile(self.move_dir,1)
			self.moving_to_enemy = true
			self:set_offset(0,0)
            if not self.can_move_to_func(tile) or tile:is_edge() then
                local dirs = get_nearest_dirs(self.move_dir)
                if self:get_tile(dirs[1],1):is_edge() then
                    self.move_dir = Direction.flip_y(self.move_dir)
				end
                if self:get_tile(dirs[2],1):is_edge() then
                    self.move_dir = Direction.flip_x(self.move_dir)
				end
                tile = self:get_tile(self.move_dir,1)
            end
			if self.can_move_to_func(tile) and not tile:is_edge() then
				self.skip_searching_once = false
				move_slide(self, self.move_dir, self.move_speed, 60)
			end
        end
    end
    self.action_attack = function(frame)
        local facing_away = self:get_facing_away()
        local facing = self:get_facing()
        local field = self:get_field()
        if frame == 1 then
            debug_print(self,"action_attack()")
            self.dirs = {
                [1] = Direction.Up,
                [2] = Direction.join(facing_away,Direction.Up),
                [3] = facing_away,
                [4] = Direction.join(facing_away,Direction.Down),
                [5] = Direction.Down,
                [6] = Direction.join(facing,Direction.Down),
                [7] = facing,
                [8] = Direction.join(facing,Direction.Up),
            }
            self.dir_index = {
                1,5
            }
			self.skip_searching_once = true
        end
        if frame == self.atk_frame-2 then
			self.counterable_component.timer = 8 -- makes the chara counterable for 8 frames
		end
        if frame == self.atk_frame-1 then
            self.anim:set_state("ATTACKING")
            self.anim:set_playback(Playback.Loop)
		end
        for i=0,self.atk_times-1 do
            if frame == self.atk_frame+self.atk_interval*i then
                local hit_props = HitProps.new()
                :dmg(self.damage_plasmaball)
                :impact()
                :flinch()
                :flash()
                :elem(Element.Elec)
                :from(self:get_context())
                for j=1,2 do
                    create_plasmaball(self, hit_props, facing, field, self:get_tile(self.dirs[self.dir_index[j]],1))
                    self.dir_index[j] = self.dir_index[j] + 1
                    if self.dir_index[j]>#self.dirs then self.dir_index[j] = 1 end
                end
            end
        end
        if frame == (self.atk_frame+self.atk_interval*self.atk_times)-1 then
            self.anim:set_state("PLAYER_IDLE")
            self.anim:set_playback(Playback.Loop)
        end
		if frame == (self.atk_frame+self.atk_interval*self.atk_times)+51 then
			self.set_state(states.MOVE)
		end
    end
    --utility to set the update state, and reset frame counter
    ---@param state number
    self.set_state = function(state)
        self.state = state
        self.frame_counter = 0
    end
    -- actions for states
    local actions = { [1] = self.action_idle, [2] = self.action_move, [3] = self.action_attack }
    self.on_spawn_func = function(self)
        local field = self:get_field()
        debug_print(self,"on_spawn_func called")
        if character_info.name_on_spawn then
            self:set_name(character_info.name)
        end
        self.current_name = self:get_name()
        field:spawn(self.reserving_obstacle,0,0)
    end
    self.battle_start_func = function()
        debug_print(self,"battle_start_func called")
        self.move_dir = Direction.join(self:get_facing_away(),self.start_ver)
    end
    self.delete_func = function()
        debug_print(self,"delete_func called")
        self.is_deleting = true
        self.reserving_obstacle:delete()
    end
    self.update_func = function()
        self.frame_counter = self.frame_counter + 1
        if not self.started then
            self.started = true
            self.set_state(states.MOVE)
        else
            local action_func = actions[self.state]
            action_func(self.frame_counter)
        end
        -- collision hitbox
        check_collision(self, self.damage)
    end
end

function create_collision_attack(user, damage, tile)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(user:get_facing())
    spell:set_hit_props(
        HitProps.new()
        :dmg(damage)
        :impact()
        :flinch()
        :flash()
		:breaking()
        :no_counter()
        :from(user:get_context())
        :elem(user:get_element())
    )
    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end
    user:get_field():spawn(spell, tile)
    return spell
end

function check_collision(user, damage)
    local t = user:get_tile()
    if user.collision_available and check_characters(t, user) then 
        create_collision_attack(user, damage, t)
    end
end

-- Checks for non-zero-health Obstacles.
function check_obstacles(tile)
    local ob = tile:find_obstacles(function(o)
        if o:get_animation():has_state("PASS_THROUGH") or o:get_name() == "CANTINTERACT" then
            return false
        else
            return true
        end
        return o:get_health() > 0
    end)
    return #ob > 0 
end

-- Checks for unfriendly Characters.
function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)
    return #characters > 0
end

-- Checks for any Characters.
function check_characters_true(tile)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0
    end)
    return #characters > 0
end

-- Checks for friendly Characters.
function check_characters_true_team(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_team() == self:get_team()
    end)
    return #characters > 0
end

return package_init