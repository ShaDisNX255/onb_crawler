local shared_package_init = include("../Paraball/character.lua")

function package_init(character)
    local character_info = {
        name = "Paraball",
        name_on_spawn = false,
        health = 80,
        damage = 20,
        element = Element.Elec,
        damage_plasmaball = 20,
        start_ver = Direction.Up,
        move_speed = 50,
        atk_frame = 27,
        atk_times = 8,
        atk_interval = 15,
    }
    if character:get_rank() == Rank.V2 then
        character_info.name = "Paralaika"
        character_info.name_on_spawn = true
        character_info.health = 150
        character_info.damage = 50
        character_info.damage_plasmaball = 50
        character_info.move_speed = 20
        character_info.atk_frame = 24
        character_info.atk_times = 10
        character_info.atk_interval = 12
    elseif character:get_rank() == Rank.V3 then
        character_info.name = "Paracrosr"
        character_info.name_on_spawn = true
        character_info.health = 200
        character_info.damage = 80
        character_info.damage_plasmaball = 80
        character_info.move_speed = 17
        character_info.atk_frame = 22
        character_info.atk_times = 12
        character_info.atk_interval = 10
    elseif character:get_rank() == Rank.SP then
        character_info.health = 220
        character_info.damage = 160
        character_info.damage_plasmaball = 160
        character_info.start_ver = Direction.Down
        character_info.move_speed = 13
        character_info.atk_frame = 17
        character_info.atk_times = 15
        character_info.atk_interval = 8
    end
    shared_package_init(character,character_info)
end