--[[

    CUSTOM BEHAVIOR:
    if Confused or Blind, can't find the player.
    if Rooted, spams attack.

]]
local is_counterable = true
local print_debug = false

local CHARACTER_TEXTURE = Engine.load_texture(_folderpath.."gfx/battle.grayscaled.png")
local CHARACTER_ANIMPATH = _folderpath.."gfx/battle.animation"

local MOB_MOVE_TEXTURE = Engine.load_texture(_folderpath.."gfx/mob_move.grayscaled.png")
local MOB_MOVE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/mob_move.png")
local MOB_MOVE_ANIMPATH = _folderpath.."gfx/mob_move.animation"

local RABIRING_TEXTURE = Engine.load_texture(_folderpath.."gfx/rabiring.grayscaled.png")
local RABIRING_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/rabiring.png")
local RABIRING_ANIMPATH = _folderpath.."gfx/rabiring.animation"
local RABIRING_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE3_155.ogg", true)

local EFFECT4_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect4.grayscaled.png")
local EFFECT4_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect4.png")
local EFFECT4_ANIMPATH = _folderpath.."gfx/effect4.animation"

function debug_print(id,str)
    if print_debug then
        print("[Rabiree] (ID: "..id:get_id()..") "..str)
    end
end

--possible states for character
local states = { IDLE = 1, SEEK = 2, ATTACK = 3 }

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or Playback.Once
    facing = facing or user:get_facing()
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and facing == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function create_rabiring(user, damage, facing, field)
    local spawn_tile = user:get_tile(facing,1)
    if not spawn_tile then return end
    local ring = graphic_init("spell", 0, 0, RABIRING_TEXTURE, RABIRING_PALETTE, RABIRING_ANIMPATH, -3, "0", Playback.Loop, user, facing, false, false, true)
    ring:set_elevation(16*2)
    ring:set_hit_props(
        HitProps.new()
        :dmg(damage)
        :impact()
        :stun(frames(90))
        :no_counter()
        :elem(Element.Elec)
        :from(user:get_context())
    )
    ring.on_spawn_func = function(self)
        Engine.play_audio(RABIRING_AUDIO, AudioPriority.Immediate)
    end
    ring.update_func = function(self)
        self:get_tile():attack_entities(self)
        if not self:is_sliding() then
            local tile = self:get_tile(facing,1)
            if not tile then
                self:delete()
            else
                self:slide(tile, frames(6), frames(0), ActionOrder.Voluntary)
            end
        end
    end
    ring.attack_func = function(self, other, judge)
        if not judge:hint_spawn_gfx() then return end
        local offset_y = math.random(-6,5)
        local offset_x = math.random(-7,6)
        if facing == Direction.Left then offset_x = -offset_x end
        local hit_fx = graphic_init("artifact", self:get_tile_offset().x+(offset_x*2), self:get_tile_offset().y+(offset_y*2), EFFECT4_TEXTURE, EFFECT4_PALETTE, EFFECT4_ANIMPATH, -999, "0", Playback.Once, user, facing, true, false, true)
        hit_fx:set_elevation(16*2)
        field:spawn(hit_fx,other:get_tile())
    end
    ring.collision_func = function(self)
        self:delete()
    end
    ring.can_move_to_func = function(tile)
        return true
    end
    ring.battle_end_func = function(self)
        self:delete()
    end
    ring.delete_func = function(self)
        self:erase()
    end
    field:spawn(ring, spawn_tile)
    return ring
end

function package_init(self, character_info)
    -- Required function, main package information
    self.texture = CHARACTER_TEXTURE
    self.anim = self:get_animation()
    self.anim:load(CHARACTER_ANIMPATH)
    -- Load extra resources
    -- Set up character meta
    -- Common Properties
    self:set_name(character_info.name)
    self:set_health(character_info.health)
    self:set_element(character_info.element)
    self:set_texture(self.texture, true)
    self:set_height(45)
    self:set_float_shoe(false)
    self:set_air_shoe(false)
    self:share_tile(false)
    self:set_explosion_behavior(2, 1, false)
    self:set_offset(0,0)
    self:store_base_palette(Engine.load_texture(_folderpath.."gfx/palette/battle-"..self:get_rank()..".png"))
    self:set_palette(self:get_base_palette())
    self.damage = character_info.damage
    -- Rabiree Specific
    self.damage_rabiring = character_info.damage_rabiring
    self.frames_between_actions = character_info.frames_between_actions
    self.fast_hop_frames = character_info.fast_hop_frames
    -- Other Setup
    self.collision_available = true
    -- entity will spawn with this animation.
    self.anim:set_state("PLAYER_IDLE")
    --self.anim:refresh(self:sprite())
    self.frame_counter = 0
    self.started = false
    self.is_deleting = false
    self.move_counter = 0
    -- This defense rule is added to prevent enemy from gaining invincibility after taking damage.
    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)
    self.defense_rule = Battle.DefenseRule.new(1, DefenseOrder.Always)
    local ref = self
    self.defense_rule.filter_statuses_func = function(statuses)
		statuses.flags = statuses.flags & ~Hit.Flinch
		statuses.flags = statuses.flags & ~Hit.Flash
		return statuses
	end
    self:add_defense_rule(self.defense_rule)
    self.reserving_obstacle = Battle.Obstacle.new(self:get_team())

    local ref = self
    self.counterable_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.counterable_component.timer = 0
    self.counterable_component.update_func = function(self)
        if self.timer > 0 and is_counterable then
            debug_print(ref,"COUNTERABLE")
            self.timer = self.timer - 1
            ref:toggle_counter(true)
        else
            ref:toggle_counter(false)
        end
    end
    self:register_component(self.counterable_component)
    self.hit_func = function(from_stun)
        debug_print(ref,"Hit func runs")
        self.counterable_component.timer = 0
        self:toggle_counter(false)
    end
    self.on_countered = function(self)
        debug_print(ref,"Countered")
        self.hit_func(true)
    end
    self:register_status_callback(Hit.Stun, function() self.hit_func(true) end)
    self:register_status_callback(Hit.Freeze, function() self.hit_func(true) end)

    self.slide_component = nil
    self.prev_tile = nil
    self.next_tile = nil

    self.can_move_to_func = function(tile)
        --if self:is_rooted() then return false end
        if tile:is_hole() then
            return false
        end
        if tile:get_team() ~= self:get_team() then
            return false
        end
        -- Can't move to reserved tiles.
        if(tile:is_reserved({self:get_id(),self.reserving_obstacle:get_id()})) then
            return false
        end
        if tile == self:get_tile() then
            return true
        end
        --[[
        if self:is_sliding() then
            return not check_obstacles(tile) and not check_characters_true(tile)
        end
        if self.anim:get_state() == "WARP1" or self.anim:get_state() == "WARP2" then
            return true
        else
            return not check_obstacles(tile) and not check_characters_true(tile)
        end]]
        return not check_obstacles(tile) and not check_characters_true(tile)
    end

    -- Code that runs in the default state
    ---@param frame number
    self.action_idle = function(frame)
        local facing = self:get_facing()
        local field = self:get_field()
		if frame == 1 then
			--print("IDLE",self.move_counter)
			--print("rooted:",tostring(self:is_rooted()))
		end
        if frame == self.frames_between_actions then
            self.move_counter = self.move_counter + 1
            if not self:is_rooted() then
                self.prev_tile = self:get_tile()
                local tile = choose_move(self)
                self.next_tile = tile
                self.next_tile:reserve_entity_by_id(self.reserving_obstacle:get_id())
                --self.next_tile:reserve_entity_by_id(self:get_id())
                local move_fx = graphic_init("artifact", 0, 0, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, -999, "0", Playback.Once, self, facing, true, true, true)
                move_fx:set_elevation(16*2)
                field:spawn(move_fx, self.prev_tile)
                self.anim:set_state("WARP1")
                self.anim:on_complete(function()
                    self:teleport(self.next_tile, ActionOrder.Voluntary, function()
                        local move_fx = graphic_init("artifact", 0, 0, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, -999, "1", Playback.Once, self, facing, true, true, true)
                        move_fx:set_elevation(16*2)
                        field:spawn(move_fx, self.next_tile)
                    end)
					--[[
					local all_tiles = field:find_tiles(function(t)
						return not t:is_edge() and t:is_reserved({})
					end)
					for i=1,#all_tiles do
						all_tiles[i]:remove_entity_by_id(self.reserving_obstacle:get_id())
					end]]
					self.next_tile:remove_entity_by_id(self.reserving_obstacle:get_id())
                    self.anim:set_state("WARP2")
                    self.anim:on_complete(function()
                        if (self.move_counter < 5) then
                            self.set_state(states.IDLE)
                        else
                            self.set_state(states.SEEK)
                            self.move_counter = 0
                        end
                    end)
                end)
            else
                if (self.move_counter < 5) then
                    self.set_state(states.IDLE)
                else
                    self.set_state(states.SEEK)
                    self.move_counter = 0
                end
            end
        end
    end
    --- Code that runs in the attack state.
    ---@param frame number
    self.action_seek = function(frame)
        local facing = self:get_facing()
        local field = self:get_field()
        local team = self:get_team()
		if frame == 1 then
			--print("SEEK",self.move_counter)
			--print("rooted:",tostring(self:is_rooted()))
		end
        if frame == self.fast_hop_frames then
            self.move_counter = self.move_counter + 1
            if not self:is_rooted() then
                local target_y = 0
                local targets = field:find_nearest_characters(self, function(c)
                    return c:get_id() ~= self:get_id() and not c:is_team(team)
                end)
                if #targets>0 then
                    target_y = targets[1]:get_tile():y()
                end
                if (target_y == self:get_tile():y()) or self.move_counter >= 8 then
                    self.set_state(states.ATTACK)
                    return
                end
                self.prev_tile = self:get_tile()
                local tile = choose_move_to_row(self, target_y)
                if not tile then
                    tile = choose_move(self)
                end
                self.next_tile = tile
                self.next_tile:reserve_entity_by_id(self.reserving_obstacle:get_id())
                --self.next_tile:reserve_entity_by_id(self:get_id())
                local move_fx = graphic_init("artifact", 0, 0, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, -999, "0", Playback.Once, self, facing, true, true, true)
                move_fx:set_elevation(16*2)
                field:spawn(move_fx, self.prev_tile)
                self.anim:set_state("WARP1")
                self.anim:on_complete(function()
                    self:teleport(self.next_tile, ActionOrder.Voluntary, function()
                        local move_fx = graphic_init("artifact", 0, 0, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, -999, "1", Playback.Once, self, facing, true, true, true)
                        move_fx:set_elevation(16*2)
                        field:spawn(move_fx, self.next_tile)
                    end)
					--[[
					local all_tiles = field:find_tiles(function(t)
						return not t:is_edge() and t:is_reserved({})
					end)
					for i=1,#all_tiles do
						all_tiles[i]:remove_entity_by_id(self.reserving_obstacle:get_id())
					end]]
					self.next_tile:remove_entity_by_id(self.reserving_obstacle:get_id())
                    self.anim:set_state("WARP2")
                    self.anim:on_complete(function()
                        self.set_state(states.SEEK)
                    end)
                end)
            else
                self.set_state(states.SEEK)
            end
        end
    end
    --- Code that runs in the attack state.
    ---@param frame number
    self.action_attack = function(frame)
        local facing = self:get_facing()
        local field = self:get_field()
        if frame == 1 then
            self.anim:set_state("ATTACKING")
        end
        if frame == 26 then
            self.counterable_component.timer = 12 -- Becomes counterable for 12 frames.
        end
        if frame == 27 then
            create_rabiring(self, self.damage_rabiring, facing, field)
        end
        if frame == 37 then
            self.anim:set_state("ATTACK_END")
        end
        if frame >= 45 then
            self.set_state(states.IDLE)
        end
    end
    --utility to set the update state, and reset frame counter
    ---@param state number
    self.set_state = function(state)
        self.state = state
        self.frame_counter = 0
    end
    -- actions for states
    local actions = { [1] = self.action_idle, [2] = self.action_seek, [3] = self.action_attack }
    self.on_spawn_func = function(self)
        debug_print(self,"on_spawn_func called")
        if character_info.name_on_spawn then
            self:set_name(character_info.name)
        end
        self:get_field():spawn(self.reserving_obstacle,0,0)
    end
    self.battle_start_func = function()
        debug_print(self,"battle_start_func called")
    end
    self.delete_func = function()
        debug_print(self,"delete_func called")
        self.is_deleting = true
        self.reserving_obstacle:delete()
    end
    self.update_func = function()
        self.frame_counter = self.frame_counter + 1
        if not self.started then
            self.started = true
            self.set_state(states.IDLE)
        else
            local action_func = actions[self.state]
            action_func(self.frame_counter)
        end
        -- collision hitbox
        check_collision(self, self.damage)
    end
end

function choose_move(self)
    local tiles = {}
    for i=0,3 do
        local tile = self:get_tile(math.floor(2^i),1)
        if tile and self.can_move_to_func(tile) then
            table.insert(tiles, tile)
        end
    end
    --print("Found ", #tiles, " possible tiles")
    if #tiles == 0 then 
        return self:get_tile()
    end
    return tiles[math.random(1,#tiles)]
end

function choose_move_to_row(self, dest_y)
    local tile = self:get_tile()
    if (dest_y < tile:y()) then
        tile = tile:get_tile(Direction.Up,1)
    else
        tile = tile:get_tile(Direction.Down,1)
    end
    if not tile or not self.can_move_to_func(tile) or self:is_confused() or self:is_blind() then 
        return nil
    end
    return tile
end

function create_collision_attack(user, damage, tile)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(user:get_facing())
    spell:set_hit_props(
        HitProps.new()
        :dmg(damage)
        :impact()
        :flinch()
        :flash()
        :no_counter()
        :from(user:get_context())
        :elem(user:get_element())
    )
    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end
    user:get_field():spawn(spell, tile)
    return spell
end

function check_collision(user, damage)
    local t = user:get_tile()
    if user.collision_available and check_characters(t, user) then 
        create_collision_attack(user, damage, t)
    end
end

-- Checks for non-zero-health Obstacles.
function check_obstacles(tile)
    local ob = tile:find_obstacles(function(o)
        if o:get_animation():has_state("PASS_THROUGH") or o:get_name() == "CANTINTERACT" then
            return false
        else
            return true
        end
        return o:get_health() > 0
    end)
    return #ob > 0 
end

-- Checks for unfriendly Characters.
function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)
    return #characters > 0
end

-- Checks for any Characters.
function check_characters_true(tile)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0
    end)
    return #characters > 0
end

function check_characters_true_team(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_tile():get_team() == self:get_tile():get_team()
    end)
    return #characters > 0
end

return package_init