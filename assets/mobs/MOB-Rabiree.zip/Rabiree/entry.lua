local shared_package_init = include("../Rabiree/character.lua")

function package_init(character)
    local character_info = {
        name = "Rabiree",
        name_on_spawn = true,
        health = 40,
        damage = 15,
        element = Element.Elec,
        damage_rabiring = 15,
        frames_between_actions = 34,
        fast_hop_frames = 4,
    }
    if character:get_rank() == Rank.V2 then
        character_info.name = "HiRabiree"
        character_info.health = 100
        character_info.damage = 60
        character_info.damage_rabiring = 60
        character_info.frames_between_actions = 26
        character_info.fast_hop_frames = 4
    elseif character:get_rank() == Rank.V3 then
        character_info.name = "M-Rabiree"
        character_info.health = 160
        character_info.damage = 90
        character_info.damage_rabiring = 90
        character_info.frames_between_actions = 18
        character_info.fast_hop_frames = 4
    elseif character:get_rank() == Rank.SP then
        character_info.name_on_spawn = false
        character_info.health = 220
        character_info.damage = 150
        character_info.damage_rabiring = 150
        character_info.frames_between_actions = 14
        character_info.fast_hop_frames = 4
    else
        character_info.name_on_spawn = false
    end
    shared_package_init(character,character_info)
end