--[[

    Confuse and Blind don't affect it.

]]--
local print_debug = false

local CHARACTER_TEXTURE = Engine.load_texture(_folderpath.."gfx/battle.grayscaled.png")
local CHARACTER_ANIMPATH = _folderpath.."gfx/battle.animation"

local NEEDLE_TEXTURE = Engine.load_texture(_folderpath.."gfx/needle.grayscaled.png")
local NEEDLE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/needle.png")
local NEEDLE_ANIMPATH = _folderpath.."gfx/needle.animation"

local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect.grayscaled.png")
local EFFECT_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect.png")
local EFFECT_ANIMPATH = _folderpath.."gfx/effect.animation"

local SHOOT_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE2_47.ogg", true)

local GUARD_TEXTURE = Engine.load_texture(_folderpath.."gfx/guard.grayscaled.png")
local GUARD_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/guard.png")
local GUARD_ANIMPATH = _folderpath.."gfx/guard.animation"
local GUARD_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE2_135.ogg", true)

function debug_print(str)
    if print_debug then
        print("[Shellky] "..str)
    end
end

--possible states for character
local states = { IDLE = 1, OPEN = 2, ATTACK = 3, CLOSE = 4 }

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or Playback.Once
    facing = facing or user:get_facing()
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and facing == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function create_needle(user, facing, field, damage, frame, tile, aback)
    if not tile or tile:is_edge() then return end
    local needle = graphic_init("spell", 0, 0, NEEDLE_TEXTURE, NEEDLE_PALETTE, NEEDLE_ANIMPATH, -3, "0", Playback.Once, user, facing)
    needle:set_elevation(8*2)
    if aback then
        needle:set_hit_props(
            HitProps.new()
            :dmg(damage)
            :impact()
            :flinch()
        )
    else
        needle:set_hit_props(
            HitProps.new()
            :dmg(damage)
            :impact()
        )
    end
    needle.frames = 1
    needle.update_func = function(self)
        if self:get_tile():is_edge() then
            self:delete()
            return
        end
        self:get_tile():attack_entities(self)
        self:highlight_tile(Highlight.Solid)
        if self.frames >= frame-1 then
            self.frames = 0
            self:teleport(self:get_tile(self:get_facing(),1), ActionOrder.Immediate)
        end
        self.frames = self.frames + 1
    end
    needle.attack_func = function(self, other, judge)
        if not judge:hint_spawn_gfx() then return end
        local offset_x = math.random(-6,5)
        local offset_y = math.random(-7,6)
        local hit_fx = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT_TEXTURE, EFFECT_PALETTE, EFFECT_ANIMPATH, -999, "0", Playback.Once, self, self:get_facing(), true, true, true)
        self:get_field():spawn(hit_fx, other:get_tile())
    end
    needle.collision_func = function(self)
        self:delete()
    end
    needle.battle_end_func = function(self)
        self:delete()
    end
    needle.delete_func = function(self)
        self:erase()
    end
    needle.can_move_to_func = function(tile)
        return true
    end
    field:spawn(needle, tile)
    return needle
end

function package_init(self, character_info)
    -- Required function, main package information
    self.texture = CHARACTER_TEXTURE
    self.animation = self:get_animation()
    self.animation:load(CHARACTER_ANIMPATH)
    -- Load extra resources
    -- Set up character meta
    -- Common Properties
    self:set_name(character_info.name)
    self:set_health(character_info.health)
    self:set_element(character_info.element)
    self:set_texture(self.texture, true)
    self:set_height(28)
    self:set_float_shoe(false)
    self:set_air_shoe(false)
    self:share_tile(false)
    self:set_explosion_behavior(2, 1, false)
    self:set_offset(0,0)
    self:set_palette(Engine.load_texture(_folderpath.."gfx/palette/battle-"..self:get_rank()..".png"))
    self.damage = character_info.damage
    -- Shellky Specific
    self.damage_needle = character_info.damage_needle
    self.needle_frames = character_info.needle_frames
    -- Other Setup
    self.collision_available = true
    self.shoot_frame2 = character_info.shoot_frame2
    self.delay_closed_orig = character_info.delay_closed
    self.delay_closed = self.delay_closed_orig
    self.delay_opening = character_info.delay_opening
    self.delay_attacking = character_info.delay_attacking
    self.delay_closing = character_info.delay_closing
    self.attacked = false
    -- entity will spawn with this animation.
    self.animation:set_state("PLAYER_IDLE")
    --self.animation:refresh(self:sprite())
    self.frame_counter = 0
    self.started = false
    self.is_deleting = false
    -- This defense rule is added to prevent enemy from gaining invincibility after taking damage.
    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)
    -- Can't be Dragged.
    self.guarding = true
    self.defense_rule = Battle.DefenseRule.new(1, DefenseOrder.Always)
    local ref = self
    self.defense_rule.can_block_func = function(judge, attacker, defender)
		local attacker_hit_props = attacker:copy_hit_props()
        if not ref.guarding or attacker_hit_props:has_flags(Hit.Breaking) then
        else
            local offset_x = math.random(-6,5)
            local offset_y = math.random(-7,6)
            local hit_fx = graphic_init("artifact", (offset_x*2), (offset_y*2), GUARD_TEXTURE, GUARD_PALETTE, GUARD_ANIMPATH, -999, "0", Playback.Once, self, self:get_facing(), true, true, true)
            ref:get_field():spawn(hit_fx, ref:get_tile())
            Engine.play_audio(GUARD_AUDIO, AudioPriority.Immediate)
            judge:block_damage()
        end
	end
    self:add_defense_rule(self.defense_rule)

    self.slide_component = nil

    self.can_move_to_func = function(tile)
        --if self:is_rooted() then return false end
        if tile:is_hole() then
            return false
        end
        if tile:get_team() ~= self:get_team() then
            return false
        end
        -- Can't move to reserved tiles.
        if(tile:is_reserved({self:get_id()})) then
            return false
        end
        if tile == self:get_tile() then
            return true
        end
        return not check_obstacles(tile) and not check_characters_true(tile)
    end
    -- Code that runs in the default state
    ---@param frame number
    self.action_idle = function(frame)
        if frame == 1 then
            debug_print("IDLE")
            self.animation:set_state("PLAYER_IDLE")
            self.animation:set_playback(Playback.Loop)
        end
        if frame >= self.delay_closed then
            self.set_state(states.OPEN)
        end
    end

    ---@param frame number
    self.action_open = function(frame)
        if frame == 1 then
            debug_print("OPEN")
            self.animation:set_state("OPEN")
            self.animation:set_playback(Playback.Once)
        end
        if frame == 19 then
            self.guarding = false
        end
        if frame >= self.delay_opening then
            self.set_state(states.ATTACK)
        end
    end
    
    ---@param frame number
    self.action_attack = function(frame)
        if frame == 1 then
            debug_print("ATTACK")
            self.animation:set_state("ATTACKING")
            self.animation:set_playback(Playback.Once)
            Engine.play_audio(SHOOT_AUDIO, AudioPriority.Immediate)
            create_needle(self, self:get_facing(), self:get_field(), self.damage_needle, self.needle_frames, self:get_tile(self:get_facing(),1))
        end
        if frame == self.shoot_frame2 then
            self.animation:set_state("ATTACKING")
            self.animation:set_playback(Playback.Once)
            Engine.play_audio(SHOOT_AUDIO, AudioPriority.Immediate)
            create_needle(self, self:get_facing(), self:get_field(), self.damage_needle, self.needle_frames, self:get_tile(self:get_facing(),1), true)
        end
        if frame >= self.delay_attacking then
            self.set_state(states.CLOSE)
        end
    end
    
    ---@param frame number
    self.action_close = function(frame)
        if frame == 1 then
            debug_print("CLOSE")
            self.animation:set_state("CLOSE")
            self.animation:set_playback(Playback.Once)
        end
        if frame == 12 then
            self.guarding = true
        end
        if frame >= self.delay_closing then
            self.delay_closed = self.delay_closed_orig
            self.set_state(states.IDLE)
        end
    end

    --utility to set the update state, and reset frame counter
    ---@param state number
    self.set_state = function(state)
        self.state = state
        self.frame_counter = 0
    end
    -- actions for states
    local actions = { [1] = self.action_idle, [2] = self.action_open, [3] = self.action_attack, [4] = self.action_close }
    self.current_name = self:get_name()
    self.on_spawn_func = function(self)
        debug_print("on_spawn_func called")
        if character_info.name_on_spawn then
            self:set_name(character_info.name)
        end
        local rank = self:get_rank()
        -- every next = +80f
        local shellkies_all = self:get_field():find_characters(function(c)
            return c:get_id() ~= self:get_id() and c:get_animation():has_state("IS_SHELLKY")
        end)
        if #shellkies_all > 0 then
            self.delay_closed = self.delay_closed_orig+#shellkies_all*80
        end
    end
    self.battle_start_func = function()
    end
    self.delete_func = function()
        self.is_deleting = true
    end
    self.update_func = function()
        self.frame_counter = self.frame_counter + 1
        if not self.started then
            self.started = true
            self.set_state(states.IDLE)
        else
            local action_func = actions[self.state]
            action_func(self.frame_counter)
        end
        -- collision hitbox
        check_collision(self, self.damage)
    end
end

function create_collision_attack(user, damage, tile)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(user:get_facing())
    spell:set_hit_props(
        HitProps.new()
        :dmg(damage)
        :impact()
        :flinch()
        :flash()
        --:breaking()
        :from(user:get_context())
        :elem(user:get_element())
    )
    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end
    user:get_field():spawn(spell, tile)
    return spell
end

function check_collision(user, damage)
    local t = user:get_tile()
    if user.collision_available and check_characters(t, user) then 
        create_collision_attack(user, damage, t)
    end
end

-- Checks for non-zero-health Obstacles.
function check_obstacles(tile)
    local ob = tile:find_obstacles(function(o)
        if o:get_animation():has_state("PASS_THROUGH") or o:get_name() == "CANTINTERACT" then
            return false
        else
            return true
        end
        return o:get_health() > 0
    end)
    return #ob > 0 
end

-- Checks for unfriendly Characters.
function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)
    return #characters > 0
end

-- Checks for any Characters.
function check_characters_true(tile)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0
    end)
    return #characters > 0
end

function check_characters_true_team(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_tile():get_team() == self:get_tile():get_team()
    end)
    return #characters > 0
end

return package_init