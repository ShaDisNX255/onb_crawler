local shared_package_init = include("../Shellky/character.lua")

function package_init(character)
    local character_info = {
        name = "Shellky",
        name_on_spawn = true,
        health = 100,
        damage = 30,
        element = Element.Aqua,
        damage_needle = 30,
        needle_frames = 13,
        shoot_frame2 = 14,
        delay_closed = 95,
        delay_opening = 50,
        delay_attacking = 158,
        delay_closing = 17,
    }
    if character:get_rank() == Rank.V2 then
        character_info.name = "Shellny"
        character_info.health = 140
        character_info.damage = 50
        character_info.damage_needle = 50
        character_info.needle_frames = 10
        character_info.shoot_frame2 = 11
        character_info.delay_closed = 65
        character_info.delay_opening = 47
        character_info.delay_attacking = 125
        character_info.delay_closing = 17
    elseif character:get_rank() == Rank.V3 then
        character_info.name = "Shellgy"
        character_info.health = 180
        character_info.damage = 100
        character_info.damage_needle = 100
        character_info.needle_frames = 7
        character_info.shoot_frame2 = 8
        character_info.delay_closed = 35
        character_info.delay_opening = 44
        character_info.delay_attacking = 81
        character_info.delay_closing = 17
    else
        character_info.name_on_spawn = false
    end
    shared_package_init(character,character_info)
end